#!/bin/bash
cd "$(dirname "$0")"
if [ ! -d .venv ]; then python3 -m venv .venv; fi
.venv/bin/python -m pip install -r agent/requirements.txt -q
exec .venv/bin/python -m agent.main
