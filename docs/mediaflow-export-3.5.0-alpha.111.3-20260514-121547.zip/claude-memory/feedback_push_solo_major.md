---
name: Push GitHub solo a major bump
description: Repo mediaflow su GitHub (privato, freecoat/mediaflow) — push solo ai major version bump, non a ogni commit
type: feedback
originSessionId: 4b126f6c-507b-4b34-bd8f-deba2c329ef3
---
Su `freecoat/mediaflow` (privato), pusho a `origin/main` **solo ai major version bump** (es. v3.x.x → v4.0.0). I commit intermedi (minor/patch/hotfix) restano locali fino al prossimo major.

**Why:** Matteo l'ha scelto esplicitamente al primo setup del remote (29 apr 2026). Vuole che GitHub sia uno snapshot per milestone, non un mirror continuo del lavoro locale.

**How to apply:** dopo i normali commit a fine versione (bump main.py + CHANGELOG + commit), NON eseguire `git push` se è minor/patch/hotfix. Pusho solo quando il bump è major. Se in dubbio, chiedo prima di pushare.
