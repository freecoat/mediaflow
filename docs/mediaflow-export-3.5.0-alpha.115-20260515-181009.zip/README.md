# MediaFlow — Export

Versione app: **3.5.0-alpha.115**
Cifrato: **no**

## Contenuto

- `mediaflow.db` — database SQLite (autocontenuto)
- `metadata.json` — dettagli export, opzioni usate, info macchina sorgente
- `excel/` — listino e quotazioni in formato Excel (human-readable)
- `claude-memory/` — memorie Claude della macchina sorgente (se incluse)
- `env/` — file `.env` con secrets (se incluso)
- `uploads/` — asset library (se inclusi)
- `trash/` — record soft-deleted (se inclusi)
- `listino-snapshots/` — backup del listino salvati dall'utente (se inclusi),
  uno per file `.json` + `_index.json` di sintesi

## Restore

1. Ferma il server MediaFlow
2. Vai in `/settings` → tab "Dati" → "Import"
3. Carica questo file ZIP (e password se cifrato)
4. Conferma l'overwrite

Il sistema farà un backup automatico del DB attuale prima di sostituirlo.

## ATTENZIONE

Il restore SOSTITUISCE tutti i dati attuali. Esegui un export di backup
prima di importare uno snapshot di un'altra macchina.
