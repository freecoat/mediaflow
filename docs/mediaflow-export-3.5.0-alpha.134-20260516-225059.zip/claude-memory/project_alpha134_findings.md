---
name: project-alpha134-findings
description: "Findings architetturali emersi 16 mag 2026 fine sessione: incongruenze Cost Report vs Fatturazione su Shadow Stagione 3. 3 anomalie strutturali + 1 request feature."
metadata: 
  node_type: memory
  type: project
  originSessionId: 2d02b59b-3641-44fa-b273-ba15559e468d
---

# α.134 Findings — incongruenza Cost Report vs Fatturazione (Shadow Stagione 3)

Emerso da Matteo uso reale 16 mag 2026 sera tarda. Investigazione su `project_id=12 "Shadow Stagione 3"`.

## Quadro dati raccolto

| Source | Valore | Note |
|--------|--------|------|
| Quote Q-2026-0006 total_with_vat | €44'889,66 | |
| Quote imponibile | €36'794,81 | |
| Job 2026-0004 budget_quoted | €36'794,81 | match ok |
| Σ JCL.total_accrued | €0,00 | **maturato ZERO** |
| Bookings done | 0/14 | **nessun booking executed** |
| JCL billing_status | tutte `paid` | inconsistente con accrued=0 |
| Σ Invoice.subtotal (3 fatture) | €36'794,81 | match con quote ok |
| Σ JCLBilledSlice.billed_amount | €11'975,29 | solo 14 slice da 2 batch |
| Σ Payment.amount | €44'889,66 | totale incassato |

Fatture:
- inv 22 "Acconto 20% Project Start" line €7'358,96 vs slice Σ €6'110,51 → mismatch €1'248
- inv 23 "SAL intermedio 2/3" line €9'934,60 vs slice Σ €5'864,78 → mismatch €4'069
- inv 24 "Saldo finale" line €19'501,25 → **0 slice**

**Fatturato fantasma** (no link a JCL): €24'820 = 67% del totale.

## F25 — Widget "Totale fatture vs Quote" in /finance

Matteo: "In Fatturazione mostra il totale delle fatture a fronte della quotazione".
Atteso: card/tabella per progetto con Quotato vs Fatturato vs Delta.

## F26 — Disaccoppiamento Invoice.lines vs JCLBilledSlice (BUG architetturale)

Due source disaccoppiate del fatturato:
1. `Invoice.lines` (manuale: "Acconto", "SAL", "Saldo")
2. `JCLBilledSlice` (auto da batch billing)

In Shadow le fatture manuali coprono il fatturato amministrativo (acconti/SAL/saldo) MA i batch hanno generato slice separate senza coordinare. Cost Report aggrega solo slice → "fatturato per JCL" sottostimato.

**Soluzioni candidate** (decisione design):
- **A**: pattern strict — fatture sempre da batch, no line manuali. Acconti/SAL diventano "advance payments" tabella separata.
- **B**: pattern hybrid (status quo + visibilità) — distinguere "fatturato linked-to-JCL" vs "fatturato amministrativo" in UI Cost Report. Nuova metrica "Σ Invoice.subtotal - Σ slice = amministrativo".
- **C**: pattern reconcile — quando emit invoice manuale, generare slice "amministrative" su JCL pro-quota (algoritmo distribution).

Raccomandato: **B** (no riarchitettura, solo trasparenza UI).

## F27 — Bookings done 0/14 ma JCL billing_status="paid"

Cost report mostra:
- Maturato = €0 (Σ JCL.total_accrued)
- Fatturato = €36'795 (Σ Invoice.subtotal)
- Delta enorme inspiegabile per l'utente

Stato semantico fuorviante: le JCL sono "paid" perché un batch è stato emit + invoice, ma operativamente le ore non sono mai state lavorate.

**Decisioni design candidate**:
- **A**: cost_line_sync ricomputa accrued anche da slice (se slice presente, accrued = qty_billed) → maturato non resta 0 se fatturato
- **B**: distinguere `billing_status` da `execution_status` JCL — la prima riflette se la riga è stata fatturata; la seconda se le ore sono state lavorate. Cost report mostra entrambe.
- **C**: warning UI se JCL.billing_status=paid && total_accrued=0 → flag "fatturato senza ore lavorate"

## F28 — Mismatch slice billed_amount vs Invoice.subtotal

Quando una fattura emit da batch usa line manuale (non auto-generated dalle slice), Σ slice ≠ subtotal.
Es: batch BB-2026-0002 total_approved €6'110,51 → linked invoice 22 con line MANUALE €7'358,96.

Probabile cause: utente ha modificato l'invoice line dopo emit, oppure emit ha usato wizard "manuale" disaccoppiato. Indagare flow.

## Roadmap α.134

1. **F25 (immediato)**: widget "Quotato vs Fatturato vs Pagato" per progetto in /finance. Card/tabella aggregata con breakdown.
2. **F26 + F27 (architettura)**: design discussion → decisione → implementazione. Pattern B raccomandato.
3. **F28 (debug)**: investigare flow emit invoice da batch — capire come line manuale può non corrispondere a slice.

## Stato side-effects DB sessione 16 mag (per cleanup futuro)

- Invoice 111: status overdue (da test α.114 immutability)
- Supplier invoice 131+132: soft-deleted (test smoke α.119)
- Anomaly entries 235+236: dismissed auto_resolved (test α.119)
- NumberingConfig overhead_cost: configurato esplicito `OH-{YYYY}-{NNNN}` = default
- Supplier #11 "Francesca Ferrari": creato + linkato Resource 26 (test α.127 generate-supplier)

Nessuno impatta i finding sopra (Shadow Stagione 3 era già nello stato attuale prima dei test).
