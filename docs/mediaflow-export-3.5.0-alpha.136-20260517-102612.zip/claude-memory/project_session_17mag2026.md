---
name: project-session-17mag2026
description: Sessione 17 mag 2026 mattina — chiusura bundle F26/F27/F28/F30 in α.135 pattern B (trasparenza UI no riarchitettura). Push fatto.
metadata: 
  node_type: memory
  type: project
  originSessionId: bfbe3a2b-5cad-4cca-9cf6-ba0233c6c163
---

# Sessione 17 mag 2026 mattina — α.135

Continuazione dopo α.134 maratona del 16 mag. Backlog ereditato: F26/F27/F28/F30 (coerenza CR↔Fatturazione) + F29 i18n sweep.

## Scelta strategica

Bundle F26+F27+F28+F30 in singola release (stesso dominio = visibilità fatturato slice vs admin). Pattern B raccomandato (no riarchitettura). F29 separato (lavoro pesante 500-1000 chiavi).

## α.135 deliverables (commit 462c3f9 pushato)

**F28 root cause** — debug DB Shadow:
- Inv 22 subtotal €7'358 con 1 line "Acconto 20%" + Σ slice €6'110 (7 slice batch BB-2026-0002)
- Causa: `seed_stress.py` STAGE 9 invoice manuali (pct random) + STAGE 14 batch+slice random invoice link → disaccoppiato by-seed-design
- In production reale solo se: `POST /finance/api/invoices` manuale + `emit-invoice` batch su stessa entità (2 stream validi ma scollegati)
- NON bug, Pattern B confermato

**F26 backend** `cost_report` list + job:
- `invoiced_net` = Σ Invoice.subtotal (no draft/cancelled, TD04 sottratto sign -1)
- `billed_admin_net` = invoiced_net − billed_locked (Σ slice)
- `admin_flag` = bool(|delta| > 5% quotato)

**F27 backend**:
- Job-level `fake_billing_count`
- Line-level `fake_billing` boolean
- = JCL billing_status billed/paid && total_accrued ≤ 0.001

**UI**:
- Lista CR (template): badge inline `⚠ admin ±€X` + `⚠ fake-bill N` accanto al titolo job
- Dettaglio CR KPI grid: card "Fatturato totale" (sub "di cui amministrativo: ±€X") + bordo amber se admin_flag + card `⚠ Fake billing` con bordo rosso (solo se count > 0)
- Tabella voci di costo: badge `⚠ no-work` su riga JCL fake_billing

**F30** risolto dalle stesse modifiche.

**Smoke Shadow Stagione 3** (job 9):
- invoiced_net €36'794,81 ✓
- billed_locked €11'975,29 ✓
- billed_admin_net €24'819,52 (67% fantasma) ✓
- admin_flag True ✓
- fake_billing_count 7/7 paid senza ore ✓

Tutti i numeri matchano analisi originale 16 mag.

## File toccati α.135

- `app/main.py` — bump version
- `app/routers/cost_report.py` — 2 endpoint extended
- `app/templates/pages/cost_report.html` — UI lista + dettaglio
- `CHANGELOG.md` + `docs/STATO.md` — note release
- `docs/mediaflow-export-3.5.0-alpha.135-20260517-095640.zip` — backup DB (8.4 MB)

## Backlog α.136+

- **F29** i18n sweep completo (~500-1000 chiavi) — lavoro pesante spalmato
- Test parse 14 capitolati restanti (UI 1-by-1)
- OAuth Gmail/Outlook/Drive/OneDrive
- Automazione portali consegne

## Punto ripresa

Aprire `docs/STATO.md` → versione α.135 → bullet point backlog α.136+. Probabile next: F29 i18n sweep (Matteo l'ha richiesta esplicitamente) OPPURE test parse capitolati. Da chiedere.
