---
name: project-session-17mag2026
description: Sessione 17 mag 2026 mattina — chiusura bundle F26/F27/F28/F30 in α.135 pattern B (trasparenza UI no riarchitettura). Push fatto.
metadata: 
  node_type: memory
  type: project
  originSessionId: bfbe3a2b-5cad-4cca-9cf6-ba0233c6c163
---

# Sessione 17 mag 2026 mattina — α.135

Continuazione dopo α.134 maratona del 16 mag. Backlog ereditato: F26/F27/F28/F30 (coerenza CR↔Fatturazione) + F29 i18n sweep.

## Scelta strategica

Bundle F26+F27+F28+F30 in singola release (stesso dominio = visibilità fatturato slice vs admin). Pattern B raccomandato (no riarchitettura). F29 separato (lavoro pesante 500-1000 chiavi).

## α.135 deliverables (commit 462c3f9 pushato)

**F28 root cause** — debug DB Shadow:
- Inv 22 subtotal €7'358 con 1 line "Acconto 20%" + Σ slice €6'110 (7 slice batch BB-2026-0002)
- Causa: `seed_stress.py` STAGE 9 invoice manuali (pct random) + STAGE 14 batch+slice random invoice link → disaccoppiato by-seed-design
- In production reale solo se: `POST /finance/api/invoices` manuale + `emit-invoice` batch su stessa entità (2 stream validi ma scollegati)
- NON bug, Pattern B confermato

**F26 backend** `cost_report` list + job:
- `invoiced_net` = Σ Invoice.subtotal (no draft/cancelled, TD04 sottratto sign -1)
- `billed_admin_net` = invoiced_net − billed_locked (Σ slice)
- `admin_flag` = bool(|delta| > 5% quotato)

**F27 backend**:
- Job-level `fake_billing_count`
- Line-level `fake_billing` boolean
- = JCL billing_status billed/paid && total_accrued ≤ 0.001

**UI**:
- Lista CR (template): badge inline `⚠ admin ±€X` + `⚠ fake-bill N` accanto al titolo job
- Dettaglio CR KPI grid: card "Fatturato totale" (sub "di cui amministrativo: ±€X") + bordo amber se admin_flag + card `⚠ Fake billing` con bordo rosso (solo se count > 0)
- Tabella voci di costo: badge `⚠ no-work` su riga JCL fake_billing

**F30** risolto dalle stesse modifiche.

**Smoke Shadow Stagione 3** (job 9):
- invoiced_net €36'794,81 ✓
- billed_locked €11'975,29 ✓
- billed_admin_net €24'819,52 (67% fantasma) ✓
- admin_flag True ✓
- fake_billing_count 7/7 paid senza ore ✓

Tutti i numeri matchano analisi originale 16 mag.

## File toccati α.135

- `app/main.py` — bump version
- `app/routers/cost_report.py` — 2 endpoint extended
- `app/templates/pages/cost_report.html` — UI lista + dettaglio
- `CHANGELOG.md` + `docs/STATO.md` — note release
- `docs/mediaflow-export-3.5.0-alpha.135-20260517-095640.zip` — backup DB (8.4 MB)

## Backlog α.136+

- **F29** i18n sweep completo (~500-1000 chiavi) — lavoro pesante spalmato
- Test parse 14 capitolati restanti (UI 1-by-1)
- OAuth Gmail/Outlook/Drive/OneDrive
- Automazione portali consegne

## Punto ripresa

Aprire `docs/STATO.md` → versione α.135 → bullet point backlog α.136+. Probabile next: F29 i18n sweep (Matteo l'ha richiesta esplicitamente) OPPURE test parse capitolati. Da chiedere.

## Aggiornamento 17 mag 2026 mattina (continuazione)

Matteo ha confermato **opzione B** (ledger separato AdvancePayment) e aggiunto 3 richieste:
1. i18n TUTTO (F29 confermato)
2. Valuta base nelle impostazioni
3. Quotazioni in dollari con conversione live al cambio attuale

### α.136 pushato (commit e0b4381)

Acconti Step 1 implementato:
- AdvancePayment + AdvancePaymentConsumption + InvoiceKind + AdvancePaymentStatus
- Invoice.kind + Invoice.project_id
- 3 endpoint: POST/GET advances + cancel
- UI cost-report card "💰 Acconti del progetto" + modal Crea acconto + bottone Annulla

Smoke E2E job 9 Shadow: create €5'000 → invoice 2026-00112 ✓ list ✓ cancel ✓ cleanup ✓.

### α.137 pushato (commit 6133040)

Multi-currency Quote:
- Modello FXRate (cache 1h, single row per coppia)
- Quote.currency + Quote.fx_rate_to_base + Quote.fx_rate_fixed_at
- Servizio FX provider Frankfurter (BCE, free, no key, fail-soft)
- Auto-migrate fx_rates + quotes ALTER
- Endpoint /finance/api/fx/{from}/{to}
- Quote POST/PUT accettano currency + refresh_fx (bloccato post-emit)
- UI settings dropdown 8 valute base
- UI quote card valuta + dropdown + bottone refresh (createElement)

Smoke FX live: USD→EUR 0.85999 (live BCE) ✓ cache hit ✓ convert 1000 USD = €859.99 ✓.

### Backlog α.138+

- **Acconti Step 2**: scomputo automatico nelle fatture batch successive (emit_invoice + closing auto-scompute residuo) + cost report colonna "coperto da acconto"
- **F29 i18n sweep**: TUTTA UI ~500-1000 chiavi IT/EN/FR/DE, helper `mfT()` per JS dinamico. Lavoro pesante spalmato su round
- **Conversione cross-currency** in cost report aggregati (project con quote in valuta non-base)
- OAuth Gmail/Outlook/Drive/OneDrive
- Test parse 14 capitolati restanti

## Punto ripresa (aggiornato α.137)

3 commit pushati oggi: α.135 (462c3f9 F26/27/30 + F28 root cause), α.136 (e0b4381 Acconti Step 1), α.137 (6133040 Multi-currency). Repo allineato GitHub. Next probabile: F29 i18n (richiesta esplicita) OR Acconti Step 2 (chiude scomputo). Chiedere a Matteo.

### α.138 pushato (commit 8a6a9c9) — Acconti Step 2

Chiusura ciclo acconti Pattern B end-to-end.

**Backend**:
- Helper `_parse_advance_consumptions_csv` + `_apply_advance_consumptions` in billing.py.
- `emit_invoice` + `compose_invoice_from_batches` accettano `advance_consumptions` Form CSV.
- `emit_closing_invoice` auto-scompute FIFO degli AP open + advance_overflow_open warning.
- Invoice.project_id linkato auto per batch/closing.
- Cost Report list + job estesi con advance_amount/consumed/balance/overflow_flag.

**UI**:
- Modal `/finance` emit batch: sezione "💰 Scomputo acconti" + checkbox + input + auto-suggest + recalc live.
- CR card preesistente α.136 ora mostra Σ consumi aggiornati.

**Smoke**: 2 AP €3000+€2000 → scomputo €1500+€500 ✓ status consumed ✓ over reject ✓.

### Punto ripresa α.139

4 commit pushati oggi: α.135 (462c3f9), α.136 (e0b4381), α.137 (6133040), α.138 (8a6a9c9). Repo allineato. Backlog principale:
- **F29** i18n sweep TUTTA UI (richiesta esplicita Matteo, ~500-1000 chiavi)
- Conversione cross-currency in cost-report aggregati
- OAuth integrazioni
- Test parse 14 capitolati restanti

F29 è il candidato naturale next (lavoro pesante, spalmare su round). Confermare con Matteo.

### α.139 pushato (commit 451a0a1) — Revisione architetturale acconti

**Cambio scope importante** dopo α.138: Matteo ha richiesto rifondazione del flow acconti. Nuovo workflow:
```
QUOTE definisci termini → JOB auto-create AP pending + notifica → FINANCE bozze + emit → CR fill mode
```

Piano 4 versioni: α.139 foundation quote, α.140 hook auto+notifica, α.141 UI finance bozze+emit, α.142 CR fill mode.

α.139 deliverables:
- `QuoteAdvanceSchedule` + `QuoteAdvanceAllocation` + `AdvanceDueAnchor`
- `AdvancePaymentStatus` esteso (pending/draft/confirmed/invoiced/paid/consumed, open=legacy alias)
- 4 endpoint CRUD + GET quote esposto advance_schedules
- UI quote card "💰 Termini di acconto" + modal complet (label, pct/amount, anchor, offset/date/milestone, allocazione QuoteLine)

Compat: ledger AdvancePayment α.136-138 + scomputi α.138 restano attivi. UI cost-report "Crea acconto" sarà DEPRECATO in α.141.

### Punto ripresa α.140

5 commit pushati oggi (α.135→α.139). Next: α.140 hook converti quote→job + notifica admin advance_pending. Backlog F29 i18n + α.140-142 acconti workflow + cross-currency + OAuth.

### α.140 + α.140.1 + α.141 + α.142 + α.143 pushati

α.140 (88ae88f): UX quote 5 fix
α.140.1 (cb68c40): hotfix loadQuote→reloadQuote
α.141 (43a9194): Anomalie 7 fix UX/workflow
α.142 (6b72be9): Cashflow 3 fix
α.143 (f09f4d4): Crea fattura ampliato + acconti visibili in fatturazione

### Punto ripresa α.144 (workflow acconti)

10 commit oggi 17 mag 2026 (α.135→α.143). Lavoro coordinato su 3 aree:
1. **Acconti** (α.136-139): foundation completa (modelli + ledger + Pattern B + termini quote + UI cost-report card + UI quote modal). Mancano: hook converti quote→job auto-create AP pending + Notification admin + UI /finance "Bozze" + CR fill mode.
2. **Multi-currency** (α.137): completo (FX Frankfurter + Quote.currency + UI)
3. **Cluster fix UX** (α.140-143): 5 fix quote + 7 fix anomalie + 3 fix cashflow + crea fattura ampliato + acconti visibili.

Next α.144: workflow acconti completo (hook + UI bozze + emit + fill mode CR). Backlog F29 i18n sweep + OAuth + cross-currency aggregati.

Pattern persistenti emersi oggi:
- `feedback_smoke_e2e_browser` salvato (bug loadQuote)
- Refactor in più round su feedback Matteo è normale: scope sempre più chiaro
