---
name: project_session_29mag2026
description: "Sessione 29 mag 2026 — α.124→129, 2 feature subagent-driven + corpus capitolati popolato + DeepSeek V4"
metadata: 
  node_type: memory
  type: project
  originSessionId: 58850658-748b-45ef-98c4-93797d049ab8
---

Sessione lunga (riapertura post-crash). Arco **α.172.124 → α.172.129**, tutto su `main` (2 feature via branch+merge, subagent-driven-development).

- **α.124**: `list_templates` filtra soft-deleted di default (`?include_inactive=1` admin).
- **α.125**: fix lifespan `Path` scoping (3 backfill JCL crashavano in silenzio) + `avvia_muto.bat` killa listener :8000 prima di avviare (anti-zombie). Diagnosi crash apertura = 10 processi zombie su :8000 (OneDrive rompe `--reload`), vecchio .116 rispondeva.
- **α.126**: Container taxonomy non-AV (Subtitle/KDM/ISO/Document) → fix 21 falsi positivi MISSING_CONTAINER (22→2 issue, i 2 residui finding veri). Vedi [[feedback_approccio_generico]].
- **α.127**: feature **timeline/TC/audio-config** sui DeliveryItem (9 task TDD, branch). Modelli +campi, AudioConfigPreset, effective_timeline (eredità), apply_audio_config_preset (materializza tracce), parser+UI+QC. Merged.
- **delivery-variants DEPRECATO** (Bundle L Stack 1 mai finito, rimpiazzato da DeliveryItem/Template). Nav link rimosso + banner.
- **α.128**: feature **estrazione capitolati via vision** (8 task TDD + eval gate, branch). PyMuPDF PDF→immagini, extract_head_specs vision, reconcile alias (M&E=IT), apply idempotente, endpoint+UI+batch. **Corpus popolato: 97 AudioConfigPreset su 11 broadcaster** (RAI 28 con 8T07/16T09 verificati vs tabella+legenda). Merged.
- **α.129**: DeepSeek V4 (v4-flash default/v4-pro + pricing, legacy deprecati 2026-07-24). Text-only → vision resta Claude.

**NON pushato** (main +29 su origin). Server locale gira .129.

**Follow-up aperti**: (1) aggiungere a mano `suggested_taxonomy` residue per template in `/settings/delivery-taxonomy`; (2) assegnazione `audio_config_code`→item via dropdown UI (test browser); (3) switch provider attivo a DeepSeek per testare copilot/features testuali (Matteo, prossimo round); (4) re-eval qualità TC su template con tc=None (GTM/MUBI/NBCU-LONGFORM/SKY il doc non lo specificava chiaramente).

Vedi [[feedback_claude_chat_autostream]], [[feedback_vision_cost_capitolati]].
