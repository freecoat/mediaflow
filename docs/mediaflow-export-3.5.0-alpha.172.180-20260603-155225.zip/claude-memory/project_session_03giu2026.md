---
name: project_session_03giu2026
description: Sessione 3 giu 2026 — α.172.179 booking multi-risorsa mobile + policy ore fatturabili per-booking (subagent-driven). Pushato.
metadata: 
  node_type: memory
  type: project
  originSessionId: a66f7130-7375-4da1-92e4-ac110e4d5f7a
---

Sessione 3 giugno 2026. Feature **α.172.179** chiusa subagent-driven (brainstorm→spec→plan→7 task con spec+quality review per task). Pushato origin `d19796f..4078b6f` (12 commit).

**Cosa**: booking multi-risorsa anche su mobile + policy configurabile per-booking di come contare le ORE FATTURABILI al cliente quando ci sono ≥2 risorse umane.
- Modalità `billable_hours_mode`: `max` (default = comportamento storico, override umana max), `sum` (tutte in parallelo), `specific` (una risorsa), `manual` (producer digita). 3 colonne su `Booking` (`billable_hours_mode`/`_resource_id`/`_manual`).
- **Costo interno INVARIATO**: somma sempre tutti gli assignment × rate. La modalità tocca SOLO le ore-cliente (`quantity_actual`).
- Single source of truth: `cost_line_sync.compute_billable_hours(items, mode, specific_rid, manual)`; `_booking_billable_hours` ora è thin wrapper. Endpoint `POST /planning/api/bookings/preview-billable` usa la stessa funzione → niente drift JS.
- UI inline (totale ore live + selector), visibile solo con ≥2 umane, desktop (modal `#modal-tl-booking`, fn `tlbOpenEdit`/`tlbSubmit`/`bkRefreshBillable`) + mobile (`booking_new.html`, `/m/booking/new`, checkbox multi-risorsa).
- Edit operatore = **ricalcolo silenzioso** (decisione Matteo, opzione A), no notifiche/flag stale. Booking fatturato = HARD-BLOCK 409 esistente.

**Decisioni design** (spec `docs/superpowers/specs/2026-06-03-multiresource-mobile-billable-hours-design.md`, plan `docs/superpowers/plans/2026-06-03-multiresource-mobile-billable-hours.md`): per-booking (non per-JCL/globale); controllo inline non prompt bloccante; preview server-side.

**2 bug presi in review** (subagent-driven ha pagato): (1) edit desktop sovrascriveva silenziosamente il mode salvato (serializer non esponeva i campi) → fix `_serialize_assignments` extendedProps + precompila in `tlbOpenEdit`; (2) mobile dropdown `specific` stale su swap umano a parità di conteggio → guard `data-ids` come desktop.

**Trappola server OneDrive ricorrente**: `uvicorn --reload` NON ricarica su OneDrive (file-watcher rotto, documentato in avvia_muto.bat) → accumula processi zombie su :8000 che servono codice STALE (sintomo: 405 su endpoint nuovo). Fix in sessione: kill TUTTI i python, avviare UN `uvicorn ... reload=False`. Per smoke browser affidabile lanciare sempre no-reload e restartare dopo ogni edit Python. Vedi [[feedback_smoke_e2e_browser]].

**2 minori noti non bloccanti** (per test Matteo): edit che riduce a <2 umane non resetta il mode (manual potrebbe persistere; sum/specific con 1 umana = max comunque); preview endpoint read-only senza `_enforce_planning_scope` (tenant-scoped, no leak).

Smoke browser fatto da me (Playwright, login admin@mediaflow.it/admin123): endpoint max=8/sum=14/specific=6/manual=5 room-ignorata, console 0 errori desktop+mobile. Tunnel cloudflare live su `province-denver-locate-thu.trycloudflare.com`.
