---
name: project_session_04giu2026
description: "Sessione 4 giu 2026 — α.172.185 multiselect righe quote elimina/copia/sposta, subagent-driven, pushato"
metadata: 
  node_type: memory
  type: project
  originSessionId: c5c0df09-780e-4b1a-9189-fd68c2467f63
---

Sessione 4 giugno 2026. Pushato origin **487f813** (12 commit, 221926a→487f813).

**Feature α.172.185 — multiselect righe quote (elimina/copia/sposta)**, sviluppata full subagent-driven (brainstorming→spec→plan→8 task con spec+quality review per task). Spec/plan in `docs/superpowers/{specs,plans}/2026-06-04-quote-lines-multiselect-transfer*`.
- Backend: `POST /quotes/api/{id}/lines-transfer` (mode copy|move, target existing|new, atomico) + `GET /quotes/api/transfer-targets` (picker bozze tenant) + refactor DRY `_remove_quote_lines` (estratto da batch-delete).
- Move SOLO da bozza: 422 da approvata/non-editabile, 409 se booking attivi; rollback annulla anche la copia.
- UI in `quotes.html`: checkbox per riga (dentro cella drag-handle, no colonna nuova), barra bulk flottante, modal trasferimento. `_qlEditable()` gating Sposta allineato a status==draft (fix integrazione: prima abilitava sent/superseded → 422).
- 2 bug presi in review: (1) numerazione progressiva righe copiate collideva (`dest.lines` cached stale → fix `dest.lines.append`); (2) mismatch UI/backend editabilità Sposta.
- 388 test (+13). Smoke browser E2E reale (Playwright): copia→nuova quote, zero errori console.

**Convenzioni confermate quotes.html**: `api(method, url, body)` POSIZIONALE (non fetch-style); globals `currentQuoteId`/`currentQuote` (let, NON window.*); `reloadQuote()`; helper `escapeHtml/toast/openModal/closeModal` in global.js.

**Prossimo**: test browser Matteo (serve ≥2 bozze per testare copia/sposta verso esistente). Backlog ereditato α.184: filtro proattivo capitolato editor, severità R3, QC filename, UI naming per-item, fixture client_admin→conftest. Vedi [[project_session_03giu2026]].

**Feature α.172.186 — duplica righe quote IN-PLACE** (push 1abf845). ⧉ per-riga (copia sotto l'originale) + bulk "Duplica" (selezione → fondo categoria). Suffisso " (copia)". `POST /quotes/api/{id}/lines-duplicate` (line_ids CSV, after bool). Recalc canonico `_recalc_quote` (NON `_recalc_quote_totals`: quello ignora sconti cat+pacchetto — preso in review). UI usa `currentQuoteId` diretto + gate backend 409 (NON `_ensureEditableQuoteOrVersion`: evita stale-id su nuova versione). 393 test. Smoke browser verde. Plan: `docs/superpowers/plans/2026-06-04-quote-lines-duplicate-inplace.md`.

Nota recalc: `_recalc_quote` (quotes.py:504) = canonico per mutazioni righe (sconti cat+pacchetto); `_recalc_quote_totals` (reverse_quote) = solo totali grezzi, usato da lines-transfer (potenziale gap se dest ha sconti — non fixato, follow-up).

**Feature α.172.187 — quote sorgente nella lista deliverable Planning** (push b1d9e6c). Card kanban badge `📄 Q-…` + colonna "Quote" nella lista + ricerca. `GET /jobs/api/deliverables/list` espone `quote_id`/`quote_number` (batch via `Job.quote_id`→`Quote.number`, no N+1). 395 test. Smoke browser verde (card + lista). Fatta diretta dal controller (no subagent, ~20 righe).

Fuori progetto: discussa accensione remota PC via WoL (Iliadbox ha WoL nativo + app iliadbox Connect, no Raspberry serve).
