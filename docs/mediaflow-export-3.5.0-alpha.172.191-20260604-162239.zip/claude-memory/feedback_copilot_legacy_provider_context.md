---
name: feedback_copilot_legacy_provider_context
description: "Provider copilot senza tool nativi (DeepSeek/Ollama/Perplexity) = path legacy, i TOOLS NON arrivano al modello → feature copilot vanno nel CONTESTO"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: c5c0df09-780e-4b1a-9189-fd68c2467f63
---

Il copilot ha 2 path (`ai_loop.advance_loop`): **tool-use nativo** (Claude/OpenAI/Gemini, `provider.supports_tools()==True`) vs **legacy** (`chat_with_assistant`, per DeepSeek/Ollama/Perplexity). Nel legacy i descriptor in `app/services/ai_tools.py:TOOLS` **NON vengono passati al modello** → qualsiasi tool readonly nuovo (es. `read_quote_lines`) è **invisibile**.

**Why:** l'admin di Matteo usa **DeepSeek** (`User.active_ai_provider='deepseek'`, scelto per costo testo/copilot). Aggiunsi `read_quote_lines` come tool → il modello rispose "non ho quel tool" perché legacy. La feature serviva ma non scattava.

**How to apply:** una capability del copilot deve funzionare per TUTTI i provider → mettila nel **contesto** (`ai_context.build_context`), non solo come tool. Pattern α.172.190: conteggi consegne/lavorazioni per quote aggiunti alla overview "QUOTE ESISTENTI" (batch, no N+1) → DeepSeek risponde dal contesto. Il tool readonly resta come bonus per i provider tool-capable (dettaglio on-demand da qualsiasi pagina). Verifica SEMPRE il provider attivo (`get_provider_for_user(uid,db).supports_tools()`) prima di assumere che un tool basti. Vedi [[feedback_copilot_more_capabilities]], [[feedback_vision_cost_capitolati]].
