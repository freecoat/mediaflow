---
name: feedback_ai_schema_descriptions
description: Campi tool-schema AI con nome ambiguo necessitano description esplicita; enum NON devono divergere dai dati reali
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 30c5c13a-9247-4e28-bbd9-d0794628ada6
---

Ogni campo dei tool-schema in `app/services/ai_tools.py` con nome ambiguo DEVE avere una `description`: il modello inferisce la semantica del campo da lì. Esempio reale (α.172.141): `price_list` era `{"type":"number"}` senza description → il modello credeva fosse il PK di "una price list" e chiedeva l'id, bloccandosi. È invece il prezzo numerico (livello List), non un FK. Fix = description esplicita ("NUMERO in valuta base, NON un id").

**Why:** nomi tipo `price_list`/`*_id`/`*_code` sono trappole: senza description il modello allucina un riferimento/FK.

**How to apply:** quando aggiungi/rivedi un tool, dai description a ogni campo non ovvio. NON usare `enum` se non copre i valori reali del DB: `unit` aveva `enum:["day","hour","flat"]` ma le voci reali usano `pc` (85×), `TB`, `hr`, `day`, `min`, `shot`, `allow`, `version` → enum rimosso, stringa libera + esempi. Verifica le unità/valori reali con una query group_by prima di vincolare. Le modifiche allo schema richiedono restart server (letto al boot provider). Vedi [[feedback_copilot_more_capabilities]].
