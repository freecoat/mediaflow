---
name: anthropic-streaming-threshold
description: Anthropic SDK richiede streaming per richieste che possono superare 10 min. Soglia pratica max_tokens 16K-32K Sonnet 4.6.
metadata: 
  node_type: memory
  type: feedback
  originSessionId: ef16f9fa-dede-4df4-b382-a3d2e16424d9
---

Anthropic SDK Python rifiuta `client.messages.create(max_tokens > soglia)` con `ValueError: Streaming is required for operations that may take longer than 10 minutes` quando stima tempo > 10 min.

**Why:** Sonnet 4.6 a 32K output può richiedere 200-400s ma SDK stima conservativo. Per parser DeliveryItem pass2 con PIPERFILM (DCP + 16 audio + multi-edizioni) servono 32K, quindi fallisce subito senza streaming.

**How to apply:** in `ai_provider.py` ClaudeProvider.complete() auto-switch a `client.messages.stream()` quando `max_tokens > 16000`. Concatena chunks da `stream.text_stream` e ritorna stringa. Sotto soglia mantiene path classico `messages.create` (no overhead). API esterna invariata.

Si applica anche a chat/extract_json se max_tokens alti. Per ora coperto solo `complete()` (path usato da extract_json).

Vedi commit `491ead8` α.172.118 + [[project_session_28mag2026_tier2]].
