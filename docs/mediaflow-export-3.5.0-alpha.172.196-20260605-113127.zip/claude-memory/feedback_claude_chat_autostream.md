---
name: feedback_claude_chat_autostream
description: "ClaudeProvider.chat auto-streama >16K (come complete) — senza, output vision grande troncato → JSON {}"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 58850658-748b-45ef-98c4-93797d049ab8
---

`ClaudeProvider.chat()` (vision/multimodale) ora auto-streama quando `max_tokens > 16000`, come già faceva `complete()` ([[feedback_anthropic_streaming_threshold]]).

**Why**: l'estrazione head-specs RAI via vision (50 pagine, 28 audio config codes + tracce) produce output >16K token. Senza streaming il SDK Anthropic tronca silenziosamente → JSON incompleto → `safe_json_parse` ritorna None → `{}`. Sintomo insidioso: intermittente (output corto fitta, output ricco no), sembrava un bug di parsing o credito.

**How to apply**: per qualsiasi chiamata LLM con output potenzialmente grande (estrazione strutturata ricca, vision multi-pagina) usa `max_tokens` alto (es. 32000) e assicurati che il metodo provider faccia streaming sopra 16K. `chat_with_tools` è separato (default 4000, non toccato). Tutti i caller esistenti di `chat()` usano ≤4000 → ramo non-streaming invariato (retrocompat verificata α.172.128).
