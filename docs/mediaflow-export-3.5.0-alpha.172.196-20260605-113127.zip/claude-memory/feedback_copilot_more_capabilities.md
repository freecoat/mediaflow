---
name: feedback-copilot-more-capabilities
description: Matteo vuole che ogni funzionalità gestionale sia accessibile/proponibile dal copilot AI — più tool registrati nel registry = miglior prodotto
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 145e82bb-bd2b-4c22-a087-0f5b45f7edad
---

Più funzionalità gestionali vengono concesse al copilot AI, migliore sarà il prodotto.

**Why**: il copilot è co-pilota centrale di MediaFlow (CLAUDE.md visione). Ogni funzione di business deve essere `propose_*` nel registry. Pattern "AI propone, utente dispone" copre già la safety con AIAction proposed→applied.

**How to apply**:
- Quando aggiungi/modifichi endpoint mutator (create/update/delete/transition di entità), valuta sempre se serve corrispondente capability `propose_*` in `app/services/ai_tools.py` + handler in `apply_ai_action()`.
- Se aggiungi `smart_split`/`recurrence`/policy avanzate a un endpoint, verifica che la capability AI corrispondente le esponga.
- Espandi system prompt/context per far capire al copilot quando usare la nuova capability.
- NON limitare al CRUD base: workflow stateful (anomaly actions, billing transmit, supplier scoring) sono primi candidati.
- Link a [[project_ai_cost_derivation]] e [[project_anomaly_workflow]] per esempi di capability avanzate.
