---
name: feedback-jinja-in-js-comments
description: "Mai includere sintassi Jinja letterale ({% %}) nei commenti JS dei template, anche dentro // o block comment. Parser Jinja è greedy e li interpreta come tag veri."
metadata: 
  node_type: memory
  type: feedback
  originSessionId: d07cff20-e7c9-4380-b5a7-4b5f7957c80d
---

# Non includere sintassi Jinja letterale nei commenti JS dei template

## La regola
In file template (`pages/*.html`) MAI mettere `{% if ... %}` o `{% endif %}` letterali dentro commenti JS (// o /* */). Anche dentro template literal JavaScript (backtick). Jinja parser è greedy e li interpreta come VERI tag → sbilancia if/endif → `TemplateSyntaxError: Encountered unknown tag 'endblock'`.

**Why**: lezione α.172.30.3. Avevo aggiunto un commento JS che diceva `// spostato fuori dal blocco {% if scoped_resource_id %}` per documentazione. Jinja l'ha visto come tag aperto in più, e ha fallito al primo `{% endblock %}` con "innermost block that needs to be closed is 'if'". Bug runtime invisible al developer perché in JS è solo testo.

**How to apply**:
- Se devi documentare un nome di tag Jinja in commento, PARAFRASA. Es. invece di `// fuori dal blocco {% if scoped_resource_id %}` scrivi `// fuori dal blocco condizionale scoped_resource_id`.
- Se proprio servono parentesi graffe per documentare sintassi: usa simboli alternativi tipo `<% if %>` o `[[if]]`.
- Smoke test prima del commit: `jinja2.Environment(loader=FileSystemLoader('app/templates')).get_template('pages/<file>.html')` → cattura subito errori di parsing.
- Stesso problema vale per `{{ var }}` e `{# comment #}` letterali in commenti JS.

Pattern correlato: [[feedback_smoke_e2e_browser]] (smoke E2E browser obbligatorio) — questo è un caso dove smoke server-side basta.
