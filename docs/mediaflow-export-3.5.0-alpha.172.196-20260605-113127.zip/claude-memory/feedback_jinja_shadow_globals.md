---
name: feedback-jinja-shadow-globals
description: "Mai shadoware nomi funzioni globali Jinja (is_elevated, can_*, has_*, current_user, etc.) con variabili context — causa TypeError 'bool object is not callable' o simili."
metadata: 
  node_type: memory
  type: feedback
  originSessionId: d07cff20-e7c9-4380-b5a7-4b5f7957c80d
---

# Non shadoware nomi di funzioni globali Jinja in context router

## La regola
In `TemplateResponse({"...": ...})` MAI usare come chiave nomi di funzioni Jinja registrate globalmente: `is_elevated`, `is_admin`, `can_approve_*`, `can_view_*`, `has_permission`, `current_user`, `mfIsAdmin`, etc.

## Why
α.172.33.1: `holidays_page` passava `"is_elevated": is_elevated(user)` → bool. Il template `base.html` (incluso da tutti) chiamava `{% if is_elevated(_user) %}` aspettandosi la FUNZIONE globale Jinja. Risultato runtime: `TypeError: 'bool' object is not callable` → 500 sulla pagina.

Stesso pattern di bug Python (variable shadowing global function) ma silenzioso in dev perché Jinja non lo segnala fino al render.

## How to apply
- Per booleani derivati da funzioni globali, prefissa con `user_` o `current_user_`: `user_is_elevated`, `user_is_admin`, `user_can_edit_finance`.
- Per stati: `is_*_active`, `*_visible`, `show_*`.
- Smoke test render: `env.get_template('pages/X.html').render(**ctx)` con context minimo cattura subito.
- Pattern già usato correttamente in altri router (es. `user_is_elevated` in `hr.py`).

Related: [[feedback_jinja_in_js_comments]] (Jinja parsing su commenti JS), [[feedback_smoke_e2e_browser]] (smoke E2E browser).
