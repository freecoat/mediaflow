---
name: feedback_jsonparse_col1_is_500
description: "Copilot/API \"JSON.parse unexpected character at line 1 column 1\" = unhandled server 500 (Starlette plain-text), non proxy"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 30c5c13a-9247-4e28-bbd9-d0794628ada6
---

`JSON.parse: unexpected character at line 1 column 1` lato frontend (es. `r.json()` in copilot.js) = il body NON è JSON. MediaFlow non ha exception handler custom in `app/` → un'eccezione non gestita fa ritornare a Starlette il **plain-text** `Internal Server Error` (inizia con `I`, non `{`) → parse fallisce a col 1. **Firma di un 500 server-side, non di un timeout proxy** (quello darebbe HTML `<`). Distinguere: se URL è localhost → è 500 server; se via tunnel cloudflared → potrebbe essere HTML proxy.

**Why:** advance_loop cattura gli errori provider/rete e ritorna JSON `{error:"provider_error"}` (parserebbe bene). Quindi un 500 viene da codice FUORI dai try: tipicamente `build_system_prompt`/`build_context` (ai.py:221) — gira identico per OGNI messaggio → crash prompt-indipendente, tutto il Copilot morto.

**How to apply:** repro offline a costo-API-zero: chiama `build_system_prompt(db, use_tools=True)` in uno script con la venv (`PYTHONPATH=. .venv/Scripts/python.exe`) e leggi il traceback. Caso reale α.172.139: `build_context` formattava `€{it.price_list:.0f}` su PriceItem con `price_list=None` (66/98 voci-bucket della migrazione α.172.135). Pattern: ogni `:.0f`/`:.1f`/`:.2f` su attributo modello nullable va guardato (`x if x is not None else "n/d"`), o usa helper `_short_money`. Vedi [[feedback_log_report_apertura]].

**MITIGAZIONE SISTEMICA α.172.189**: `POST /ai/api/chat` ora è wrappato (`chat` wrapper try/except + corpo in `_chat_impl`): qualsiasi eccezione non gestita → 200 JSON `{error:"internal_error", reply, actions:[], conversation_id:null}`, HTTPException passa intatta. Quindi il copilot non mostra più "Unexpected token"; il vero errore va cercato nei log server (`logging.getLogger("ai.chat").exception`). Il bug di root resta da fixare (il wrapper maschera il sintomo UI, non la causa). Caso α.172.188: `ai_context._build_planning_context` usava `UnavailabilityKind.weekend` inesistente → AttributeError su pagina /planning.
