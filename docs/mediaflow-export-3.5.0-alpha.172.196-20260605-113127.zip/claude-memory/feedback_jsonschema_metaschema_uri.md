---
name: feedback-jsonschema-metaschema-uri
description: "jsonschema 4.26+ richiede canonical draft-07 URI http://json-schema.org/draft-07/schema# altrimenti warning fallback"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 7e0c7ada-945b-4bb9-bb2a-4794a7b67c52
---

JSON Schema `$schema` URI per draft-07 deve essere esattamente `http://json-schema.org/draft-07/schema#` (con `#` finale, **http NON https**).

**Why**: jsonschema 4.26+ ha registry metaschema noti hard-coded. Variazioni (`https://...` o senza `#`) → `DeprecationWarning: metaschema not found. Using latest draft, will raise error in future`. Validator funziona via fallback ma warning persiste e potrebbe diventare fatal in future versions.

**How to apply**: ogni schema JSON nuovo nel repo (`schemas/*.json`) usa esattamente `"$schema": "http://json-schema.org/draft-07/schema#"`. Vale anche per draft-04/06/2019-09/2020-12 — verifica canonical URI specifica della draft.

Emerso α.172.94 Task 5 review: schema verbatim dal plan aveva `https://json-schema.org/draft-07/schema` (senza `#`), warning persistente. Fix 1 char → warning sparito (commit 61eea44).

Vedi [[project-session-27mag2026-bundle-l-stack1]].
