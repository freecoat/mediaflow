---
name: feedback-plugin-registry-test-isolation
description: Module-level plugin registry richiede fixture autouse snapshot/restore + importlib.reload per evitare pollution cross-test
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 7e0c7ada-945b-4bb9-bb2a-4794a7b67c52
---

Pattern plugin registry (`_REGISTRY: list[tuple[pattern, cls]]` module-level + `@register_extractor(name, mime_priority)` decorator) ha 2 trappole nei test pytest:

**Trappola 1**: registry persiste tra test (module loaded once). Se test 1 registra Dummy poi test 2 importa modulo reale → reale registrato in coda → first-match-wins (lookup ordine inserzione) può cambiare risposta inattesa.

**Trappola 2**: dopo `_REGISTRY.clear()` in fixture, ri-importare `from app.services.tech_specs_extractor import ffprobe_extractor` NON ri-esegue decorator perché Python cache `sys.modules`. Registry resta vuoto → `get_extractor` ritorna None.

**Soluzione**:

```python
@pytest.fixture(autouse=True)
def _clean_registry():
    from app.services.tech_specs_extractor import _REGISTRY
    snapshot = list(_REGISTRY)
    _REGISTRY.clear()
    yield
    _REGISTRY[:] = snapshot
```

Test che vogliono extractor "di produzione" devono `importlib.reload(extractor_module)` DENTRO test body — forza ri-esecuzione decorator:

```python
def test_ffprobe_registered():
    import importlib
    from app.services.tech_specs_extractor import ffprobe_extractor
    importlib.reload(ffprobe_extractor)  # ri-applica @register_extractor
    from app.services.tech_specs_extractor import get_extractor
    assert get_extractor("video/mp4") is not None
```

**Why**: emerso α.172.94 Task 7+8 Bundle L. Senza pattern → 2 ore debug fixture interaction inaspettata.

**How to apply**: qualsiasi nuovo plugin registry pattern nel codebase (extractor / parser / AI capability) → applica STESSO pattern fixture + reload. Documenta nel docstring del fixture.

Vedi [[project-session-27mag2026-bundle-l-stack1]].
