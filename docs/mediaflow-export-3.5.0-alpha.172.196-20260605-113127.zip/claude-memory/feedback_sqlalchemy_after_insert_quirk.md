---
name: feedback_sqlalchemy_after_insert_quirk
description: "SQLAlchemy after_insert listener problematico per modificare altre row durante flush. Mutazioni rep counters / projection field non persistite. Soluzione: chiamata esplicita dal service post-flush."
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 63897046-8e34-4fb1-9910-f4624b8f7262
---

Bug realmente incontrato α.172.98 Stack 2 QC: implementato `after_insert` listener su `QCEvent` per aggiornare `QCReport` (projection) + `JobDeliverable.qc_substatus` (back-compat Bundle I). Smoke API mostrava QCReport con `last_qc_number=0, last_event_id=NULL` invece dei valori attesi. DB query confermava persistenza event ma report mai aggiornato.

**Why**: l'after_insert listener viene chiamato DURANTE il flush dell'INSERT QCEvent. Modifiche fatte a OTHER ORM objects (QCReport, JobDeliverable) durante questo flush vengono spesso ignorate o richiedono flush successivo per persistere. La query subsequente `db.commit()` non vede le modifiche pending.

**How to apply**: per projection materializzate basate su event-sourcing, NON usare `after_insert` listener. Pattern corretto:
1. Service `_emit(event)`: `sess.add(event)`, `sess.flush()` (popola event.id), poi chiama esplicitamente `apply_projection_for_event(sess, event)` come funzione normale.
2. Listener restano solo per validation (immutability before_update/before_delete).
3. Backup option: `after_flush` listener (esegue dopo l'intero flush), ma chiamata esplicita è più predicibile e debuggabile.

Vedi `app/services/qc_event_listener.py:apply_projection_for_event` + `app/services/qc_events.py:_emit`.

Related: [[project_stack2_qc_event_sourced_decisions]].
