---
name: feedback_template_change_needs_restart
description: Modifiche a template Jinja (.html) non si caricano a runtime su OneDrive — serve restart server
metadata: 
  node_type: memory
  type: feedback
  originSessionId: c5c0df09-780e-4b1a-9189-fd68c2467f63
---

Modificare un template Jinja (es. `app/templates/pages/quotes.html`, dove sta anche il JS inline) e ricaricare il browser **NON** basta: il cambiamento non appare finché non si **riavvia il server**.

**Why**: Jinja `auto_reload` si basa su mtime del file; su OneDrive l'mtime/file-watcher è inaffidabile (stessa radice del problema [[feedback_auto_migrate_columns]]/zombie reload). Il template compilato resta in cache → si testa codice vecchio.

**How to apply**: dopo ogni edit a un template, prima dello smoke browser **riavvia uvicorn** (no-reload + restart manuale). Verificato 4 giu 2026: edit a `_qlEditable` non caricato finché restart; dopo restart `/health` mostra versione bumpata e il nuovo JS è attivo. Conferma via `browser_evaluate` che la funzione contenga il nuovo codice (`fn.toString().includes(...)`) prima di fidarsi del test. Nota: `currentQuote` in quotes.html è un `let` globale, NON `window.currentQuote` → non stubabile via `window.*` in evaluate; apri quote reali con `openEditor(id)`.
