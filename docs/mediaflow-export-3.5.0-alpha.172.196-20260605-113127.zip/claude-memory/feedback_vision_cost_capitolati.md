---
name: feedback_vision_cost_capitolati
description: Estrazione capitolati PDF via vision è cara (50pp ≈ 75k+ img token/call); DeepSeek text-only → vision resta Claude
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 58850658-748b-45ef-98c4-93797d049ab8
---

L'estrazione head-specs dai capitolati PDF usa **vision** (PyMuPDF pagine→immagini) perché `pypdf` perde le **tabelle audio** (mappatura per-traccia codici RAI 8T07/16T09 in tabella+legenda).

**Why/costo**: un capitolato RAI da 50 pagine = ~75k+ token-immagine per call (~$0.20-0.30 Sonnet). Qualche eval di fila ha **prosciugato il credito Anthropic** (errore 400 "credit balance too low"). Il batch sui 13 capitolati costa qualche $.

**How to apply**:
- Vision serve solo dove ci sono tabelle/layout (audio config). I capitolati testo (docx/xlsx/txt) usano estrazione testo (gratis/economica) — il pipeline è hybrid (`render_document_for_llm`).
- **DeepSeek è text-only** (`supports_vision=False`): NON usarlo per i PDF/vision. `extract_head_specs` ha un guard che solleva ValueError chiaro. La pipeline vision resta su **Claude**; DeepSeek va per copilot/features testuali.
- Prima di un batch costoso: avvisa Matteo del costo, fai eval su 1 (es. RAI) e mostra il risultato (gate), poi batch.
- Decisione D5: `audio_config_code`→item resta manuale (dropdown); i preset estratti sono selezionabili per richiamare layout.
