---
name: project_capitolato_audit_color
description: audit capitolati α.172.165 + decisione colore RAI rinviata
metadata: 
  node_type: memory
  type: project
  originSessionId: 190e9abe-fbdd-4aa6-b9fd-db8fe5f3198a
---

α.172.165 (2 giu 2026): `scripts/audit_capitolati.py` (read-only, riusabile) audita tutti i dati capitolati — TC fps-aware, FK dangling, enum, coerenza colore (color_space↔hdr↔primaries), segmenti, audio, code dup.

**Fix fatti**: Vision (tpl12) e Fremantle (tpl4) avevano `default_tc_start='59:59:00:00'` (HH=59 invalido, corruzione estrazione AI) → corretti a `00:59:59:00`, black out `01:00:00:00`, program `01:00:00:00`.

**DECISIONE RINVIATA (Matteo)**: 12 item UHD con `color_space='Rec.2020 PQ'` ma `hdr_format='SDR'` (PQ=curva HDR → contraddizione). 2 NBCU + 10 RAI. **Lasciati invariati**: "la RAI è un gran casino e poco affidabile, meglio tenere le varianti e correggerle a mano nelle deliveries. In futuro riaffrontiamo." NON auto-correggere a `Rec.2020` senza ok. Tecnicamente il fix sarebbe color_space `Rec.2020 PQ`→`Rec.2020` (SDR wide gamut).

Vedi [[project_capitolato_deliverable_link]], [[project_capitolati_corpus]]. Modulo TC: app/services/timecode.py.
