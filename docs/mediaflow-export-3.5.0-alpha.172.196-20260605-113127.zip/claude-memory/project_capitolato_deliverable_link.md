---
name: project_capitolato_deliverable_link
description: α.172.161 catena FK capitolato→quote→job→planning per tech specs deliverable
metadata: 
  node_type: memory
  type: project
  originSessionId: 190e9abe-fbdd-4aa6-b9fd-db8fe5f3198a
---

α.172.161 (1 giu 2026, remote-control): chiusa la catena strutturata capitolato → deliverable.

**Problema**: in `/planning/?view=deliverables` non si vedevano/selezionavano le tech specs dell'item di capitolato scelto in quotazione. **Causa radice**: `QuoteLine`/`JobCostLine` avevano solo `price_item_id`; il `DeliveryItem` (item capitolato) era tracciato solo come stringa `detail` + broadcaster `section_label`. → `JobDeliverable.delivery_item_id` sempre NULL → modal specs (α.160) cadeva nel JSON 8-blocchi vuoto.

**Fix end-to-end** (approccio B scelto da Matteo + punto-partenza in quotazione):
- `quote_lines.delivery_item_id` FK nuovo + auto-migrate.
- Picker quote: `template_bucket_options` espone `items:[{id,name}]`; un bucket = **N DeliveryItem raggruppati per `suggested_price_item_id`** (non 1:1!). Sotto-select per multi-item (`delivery_item_map`), mono-item auto-link.
- Convert quote→job propaga il FK in **3 spawn** di JobDeliverable: `quotes.py` _create_job_from_quote (L256) + _respawn_line_artifacts (L408) + `reverse_quote.py` (L234).
- Modal planning: selettore capitolato→item sempre visibile. PUT `/jobs/api/deliverables/{id}` accetta `delivery_item_id` come **str** (""/"0"=unlink, id=link). NB: `Optional[int]+Form` coercia ""→None → impossibile distinguere unlink da no-op; usa str.
- Backfill `scripts/backfill_deliverable_capitolato_link.py` idempotente (broadcaster→template, price_item→item, disambigua con detail).

**Dati GLO (Gomorra)**: erano 35 deliverable, di cui 24 orfani duplicati (12 con quote_line dangling su job GLO + 12 su `job_id=2` job inesistente, da convert ripetuti). Cestinati. Restano 11 validi: 7 auto-linkati, 4 a mano (2 senza capitolato + 2 bucket multi-item ambigui).

Vedi [[project_deliverables_pipeline_brainstorm]]. Lezione FastAPI Form: [[feedback_ai_schema_descriptions]] tipo str per sentinel unlink.
