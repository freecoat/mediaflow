---
name: project_deliverables_pipeline_brainstorm
description: "Pipeline deliverables capitolato→listino→quote→planning→asset: COMPLETA F1+F2+F3 (α.135-138), non pushata, test browser Matteo pendente"
metadata: 
  node_type: memory
  type: project
  originSessionId: 7fe1223e-a4ae-4121-be19-f92aeeecb15b
---

Brainstorming (skill superpowers:brainstorming) di una feature grossa: collegare capitolato (`DeliveryItem`, specs complete) → listino → quote → planning deliveries → asset. Interrotto 29 mag 2026.

**Design WIP completo in** `docs/superpowers/specs/2026-05-29-deliverables-pipeline-design.md`. Leggilo alla ripresa.

Decisioni prese:
- Voce listino = **bucket tecnico generico** `(package|container)+codec+risoluzione`, molti-a-uno, match-or-create, **minimo numero voci + uniformità**.
- Specifiche capitolato → **campo `detail` di riga in quote** (non nella voce). Voce desc = sunto tecnico generico.
- Categoria "Deliveries"; legame capitolato N:N (vive in quote via section/label+detail), NON FK 1:1.
- Planning = JobDeliverable **snapshot editabile dal DeliveryItem** in `spec_json` (affini audio layout/lingua/tracce opzionali per-file).
- Asset = specs **attese**, file dopo, QC confronta (riusa `qc_expected_for_deliverable`).
- Quote = solo commerciale (picker a spunte migliora `load-from-template`); JobDeliverable+affinamento solo in planning.
- Booking modal mostra container/package + nome item.
- `JobDeliverable` ha già tutti i campi (nessun campo nuovo). Da aggiungere/verificare `DeliveryItem.price_item_id` (oggi solo `suggested_price_item_id`).

**OPEN risolta (29 mag, ripresa)**: scelta = **B consolida** (rischio dati accettato, "possiamo sbagliare"). Decisioni finali aggiunte alla spec:
- 8: chiave bucket = `(package|container)+codec+risoluzione+HDR` (HDR/colorspace nel nome solo se ≠SDR; framerate/aspect NO).
- 9: link via `suggested_price_item_id` riusato (no colonna nuova).
- 10: picker quote derivato dai DeliveryItem del template (N:N live), non `template.suggested_items`.
- 11: audio NON usa tripla video (gap reale: 61 item audio collassavano in "WAV"); ramifica per media_kind → audio=mix_type+channel da traccia primaria, sidecar=tipo container.

**F1+F2 FATTI** (commit `53e4b1a` α.172.136, NON pushato):
- F1: `app/services/delivery_bucket.py` (`compute_bucket`+`match_or_create_bucket`), migrazione `scripts/migrate_deliveries_buckets.py` eseguita sul DB live → 211 item → 66 bucket, 13 legacy soft-deprecate. Snapshot pre in db_snapshots.
- F2: `template_bucket_options()` + endpoint `GET /quotes/api/template-buckets/{tid}` + `POST /quotes/api/{qid}/load-from-template-items`. UI `quotes.html` bottone "🎯 Picker capitolato" + modal checkbox. Fix bug latente PriceLevel (`list_price`→`list`, 422). Smoke Playwright OK. 14 test.

**F3.1 FATTO** (commit `42a833f` α.172.137, NON pushato): `app/services/delivery_snapshot.py` `snapshot_delivery_item()` congela specs DeliveryItem in `spec_json` (nomi taxonomy, video/audio/subtitle/timeline ered./extra). Wire in `jobs.py` create deliverable (auto-snapshot se delivery_item_id + no spec_json). `DeliveryItem` in `app/models/__init__`. 5 test, smoke E2E OK. F3 spezzato in F3.1(fatto)/F3.2/F3.3.

**F3.2+F3.3 FATTI** (commit `8c96e01` α.172.138, NON pushato):
- F3.2: booking modal planning mostra badge tipo file (package|container da spec_json) per deliverable; endpoint bookings/deliverables arricchito.
- F3.3 **lazy bridge** (scelto vs placeholder: Asset è file-centrico, no righe vuote): `app/services/qc_specs_compare.py` `build_expected()` (attese live da DeliveryItem: risoluzione w×h, codec family, HDR, audio channel-count) + `compare_to_actual()` (report per-campo, codec fuzzy, audio multiset) + `run_deliverable_qc_compare()` salva qc_report_json. Auto-run al link asset + endpoint `POST /jobs/api/deliverables/{id}/qc-compare`.

**PIPELINE COMPLETA. RIPRENDI DA**: (1) push 4 commit + ZIP export; (2) test browser Matteo end-to-end (picker capitolato in quote → convert→job → planning badge tipo file → upload file reale → qc-compare). Possibili estensioni future: UI report QC diff nel modal deliverable (oggi solo JSON in qc_report_json), prezzatura delle 66 voci-bucket (price_list null su tutte), suggested_taxonomy residue.

(orig) JobDeliverable **precompilato via snapshot dal DeliveryItem** (container/package/codec/audio/timeline/lingue) in `JobDeliverable.spec_json` → affinamento per-file (audio layout, lingua, tracce `is_optional`). Conferma → nasce/collega **Asset** con specs "attese" (`digital_asset_id`/`physical_asset_id`); file reale dopo → QC confronta (riusa `qc_expected_for_deliverable`). Booking modal mostra tipo file (container/package)+nome item. `JobDeliverable` (models.py:3270) ha già tutti i campi, nessuna colonna nuova. Esiste `jcl_to_deliverable_migrator.py` + `deliverable_cost_sync.py` da consultare.

Vedi anche [[project_session_29mag2026]] [[feedback_approccio_generico]] [[feedback_log_report_apertura]].
