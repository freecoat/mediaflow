---
name: project_hosting_decisions
description: "decisioni hosting backend (VPS+SQLite, Postgres trigger, isolamento tenant)"
metadata: 
  node_type: memory
  type: project
  originSessionId: 190e9abe-fbdd-4aa6-b9fd-db8fe5f3198a
---

Decisioni hosting backend (2 giu 2026, α.172.171-172). Artefatti in repo: Dockerfile, docker-compose.yml (semplice), docker-compose.prod.yml (Caddy+TLS), deploy/Caddyfile, scripts/docker-entrypoint.sh + bootstrap_admin.py, .env.production.example, docs/DEPLOY.md.

**Linea confermata Matteo**:
- **VPS EU + SQLite singola istanza** su volume `/data` (WAL). NON PaaS.
- **Self-hosted sempre supportato** (clienti con prerequisiti sicurezza straordinari).
- **Postgres = milestone con TRIGGER, non ora**: 2° tenant in 1 istanza · "database is locked" sotto carico · servono più worker · cliente enterprise che lo impone. Migrazione comporta: `Float→Numeric`, adozione **Alembic** (le `_auto_migrate_columns` in main.py sono DDL SQLite-shaped, es. `BOOLEAN DEFAULT 0` rompe su PG), retest su PG. SQLite-WAL regge ~10-20 scrittori concorrenti → team post-house OK a lungo.
- **Isolamento cliente sicurezza = deployment-per-tenant** (istanza Docker + DB dedicati, anche self-host loro). Zero codice nuovo, già pronto.
- **DB-per-tenant in 1 istanza = Fase 7** (SaaS): serve connection-registry (engine/SessionLocal per tenant; `_resolve_tenant_from_request` già c'è), migrazioni ×N, dashboard platform-admin a fan-out. Con SQLite un `.db` per tenant aggira il single-writer.
- **Dominio**: col rebrand (Claqo non confermato) → primo deploy IP/sottodominio provvisorio.
- **Accesso locale dev resta attivo** (env-driven: APP_ENV=development, AUTH_REQUIRED=false, echo on).
- **App nativa (React/Capacitor) rimandata** post-hosting (Matteo: React sarebbe meglio ma prematura).

Cookie auth/portal: `secure` condizionale `APP_ENV==production` (α.172.172). Caddy aggiunge HSTS+header sicurezza. Build Docker NON validabile in ambiente dev (no docker) → da fare sull'host.

**3 vie hosting pronte** (α.172.173): A) VPS+Caddy `docker-compose.prod.yml` · B) self-host ufficio/casa `docker-compose.tunnel.yml` (cloudflared named via TUNNEL_TOKEN, no port-forward, CGNAT-ok) · C) `docker-compose.yml` semplice. docs/DEPLOY.md + docs/SELF-HOST.md.

**PRINCIPIO ASSET (decisione 2 giu 2026)**: il SaaS conserva SOLO metadato + reference; i binari restano fisicamente sui server/storage del tenant. Già implementato: `/dam/api/fs-scan` (indicizza) + `/dam/api/fs-import` (registra Asset.file_path come reference, NON copia il file — resta sul NAS). `Project.storage_backend/storage_root/s3_bucket/fs_scan_paths`. Upload diretto = via secondaria. Roadmap: integrazione MAM + AWS S3 (vars AWS_* già in config) per stream on-demand. NON forzare upload fisico nel SaaS.

Vedi [[project_rebrand_claqo]], [[project_capitolato_deliverable_link]]. Multi-tenant soft attuale (CURRENT_TENANT=1).
