---
name: project-rebrand-claqo
description: MediaFlow → Claqo rebrand parziale α.172.59. Mascot robot-claquette per copilot AI. Icona app finale = diversa dal mascot (decisione Matteo 24 mag). Finalizzare in beta.
metadata: 
  node_type: memory
  type: project
  originSessionId: 8a8a644c-fd5b-4aac-b936-881fbcab08ff
---

**Rebrand status (24 mag 2026, α.172.59)**:
- Nome: MediaFlow → **Claqo** (claquette/ciak, KLA-ko, 5 lettere)
- Wordmark: minuscolo `claqo` sempre
- Palette: claqo-red #D85A30, stage-black #1A1A1A, take-cream #FAECE7, cue-amber #EF9F27, studio-grey #5F5E5A
- Brand brief Google Doc: https://docs.google.com/document/d/16rPrBzcIw9Fo6yki6CXcw5GxQYPLvNL2cDiH27237Vs
- Mascot brief: https://docs.google.com/document/d/1yRkQmHRGGORD9RwzFHVbSNkp74ZApNCcqufIvuESGiU

**Fatto α.172.59**:
- 48 file templates/static UTF-8 no-BOM sostituiti (PS .NET WriteAllText)
- branding.py: DEFAULT_BRAND_COLOR + fallback name → Claqo/#D85A30
- main.css: --indigo* → #D85A30 (alias preservato 100+ ref), token Claqo aggiunti
- 4 SVG mascot in app/static/img/: claqo-mascot{,-wink,-focus,-alert}.svg
- FAB copilot, drawer header, favicon, sidebar logo, login = mascot SVG inline
- .env APP_NAME=Claqo, config.py, main.py FastAPI title
- data_import.py accetta ZIP legacy "MediaFlow" per compat

**NON toccato** (decisione conservativa):
- mediaflow.db filename (path DB, rename rotto migrations)
- mediaflow_fase1bis/ project folder
- Email demo @mediaflow.it
- Commenti/docstring Python
- /static/css/sleek.css (override theme — solo varianti, no brand color)

**Decisione 24 mag — DEFER beta**:
- Icona app/sidebar/favicon ≠ mascot copilot. Mascot resta SOLO per copilot AI. App icon va diversa (logo claquette più asettico/professionale, no robot face). Da disegnare in beta.
- Asset legacy (favicon.ico raster, apple-touch-icon.png 180px, manifest 192/512) → fase beta
- Loader animato (clapper che si chiude + wink) → fase beta
- Sticker pack, OpenGraph 1200×630, pitch deck → fase beta
- Trademark USPTO/EUIPO classe 9+42, domini, social handles → pre-launch

Vedi [[project-rebrand-required]] (decisione iniziale: rebrand obbligatorio pre-lancio).
