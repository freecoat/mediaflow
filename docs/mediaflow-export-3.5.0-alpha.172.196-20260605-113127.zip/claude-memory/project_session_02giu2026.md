---
name: project_session_02giu2026
description: "sessione 2 giu 2026 — capitolato/TC/mobile/hosting/finance-fix, α.160→178"
metadata: 
  node_type: memory
  type: project
  originSessionId: 190e9abe-fbdd-4aa6-b9fd-db8fe5f3198a
---

Sessione 2 giu 2026 (remote-control, tunnel :9000). Maratona α.172.160→178. **.160-.173 pushati** (origin 6ee5377), **.174-.178 pushati a fine sessione**. 319 test.

**Temi**:
- **Capitolato↔deliverable** (.161): catena FK capitolato→quote→job→planning per tech specs. Vedi [[project_capitolato_deliverable_link]]. +cleanup orfani GLO.
- **Tech specs UI** (.162-164): aspect/color_space tendine + campo color_primaries + scan 122 item. **Timecode SMPTE** modulo `app/services/timecode.py` (drop-frame) + validazione save + auto-mask + fix dati Vision/Fremantle (59:59:00:00 invalido).
- **Audit capitolati** (.165): `scripts/audit_capitolati.py`. 12 item UHD Rec.2020 PQ+SDR lasciati (RAI inaffidabile). Vedi [[project_capitolato_audit_color]].
- **MOBILE** (.166-170): force-view (UA mobile→/m, escape prefer_desktop) + Fasi A-D complete: Progetti/Clienti/Quote/Finance(+cost report)/Cerca/Nuovo booking/**Copilot AI**/Agenda settimanale. Editor pesanti restano desktop.
- **HOSTING** (.171-173): Docker+Caddy+Cloudflare-Tunnel artefatti. Vedi [[project_hosting_decisions]] (VPS+SQLite, Postgres con trigger, deployment-per-tenant, asset metadata-only).
- **FINANCE FIX** (.174-178): acconto/fatture orfane GLO (project 1 purgato non-cascade) → cleanup + **cascade purge** in `soft_delete._purge_project_dependents`. new-version preservava section_label/delivery_item_id/is_optional. **Guard quote immutabile**: picker/carica-template/drag&drop → warning+nuova-versione; revert su annulla. **Reject approved+job** → prompt 3-vie (progetto-perso mode=lost guardato / nuova-versione v1-superseded).

**App nativa React/Capacitor: rimandata** (prima hosting, poi valuta).

**RIPRESA 3 giu**: Matteo test flussi reject + mobile da telefono. Follow-up noti: cascade purge anche a livello **job-standalone** (stessa classe bug .174); deploy reale su VPS quando sceglie provider/dominio (col rebrand Claqo). Server :8000 di Matteo da restart per backend recente.
