---
name: project_session_04giu2026
description: "Sessione 4 giu 2026 — α.172.185 multiselect righe quote elimina/copia/sposta, subagent-driven, pushato"
metadata: 
  node_type: memory
  type: project
  originSessionId: c5c0df09-780e-4b1a-9189-fd68c2467f63
---

Sessione 4 giugno 2026. Pushato origin **487f813** (12 commit, 221926a→487f813).

**Feature α.172.185 — multiselect righe quote (elimina/copia/sposta)**, sviluppata full subagent-driven (brainstorming→spec→plan→8 task con spec+quality review per task). Spec/plan in `docs/superpowers/{specs,plans}/2026-06-04-quote-lines-multiselect-transfer*`.
- Backend: `POST /quotes/api/{id}/lines-transfer` (mode copy|move, target existing|new, atomico) + `GET /quotes/api/transfer-targets` (picker bozze tenant) + refactor DRY `_remove_quote_lines` (estratto da batch-delete).
- Move SOLO da bozza: 422 da approvata/non-editabile, 409 se booking attivi; rollback annulla anche la copia.
- UI in `quotes.html`: checkbox per riga (dentro cella drag-handle, no colonna nuova), barra bulk flottante, modal trasferimento. `_qlEditable()` gating Sposta allineato a status==draft (fix integrazione: prima abilitava sent/superseded → 422).
- 2 bug presi in review: (1) numerazione progressiva righe copiate collideva (`dest.lines` cached stale → fix `dest.lines.append`); (2) mismatch UI/backend editabilità Sposta.
- 388 test (+13). Smoke browser E2E reale (Playwright): copia→nuova quote, zero errori console.

**Convenzioni confermate quotes.html**: `api(method, url, body)` POSIZIONALE (non fetch-style); globals `currentQuoteId`/`currentQuote` (let, NON window.*); `reloadQuote()`; helper `escapeHtml/toast/openModal/closeModal` in global.js.

**Prossimo**: test browser Matteo (serve ≥2 bozze per testare copia/sposta verso esistente). Backlog ereditato α.184: filtro proattivo capitolato editor, severità R3, QC filename, UI naming per-item, fixture client_admin→conftest. Vedi [[project_session_03giu2026]].

**Feature α.172.186 — duplica righe quote IN-PLACE** (push 1abf845). ⧉ per-riga (copia sotto l'originale) + bulk "Duplica" (selezione → fondo categoria). Suffisso " (copia)". `POST /quotes/api/{id}/lines-duplicate` (line_ids CSV, after bool). Recalc canonico `_recalc_quote` (NON `_recalc_quote_totals`: quello ignora sconti cat+pacchetto — preso in review). UI usa `currentQuoteId` diretto + gate backend 409 (NON `_ensureEditableQuoteOrVersion`: evita stale-id su nuova versione). 393 test. Smoke browser verde. Plan: `docs/superpowers/plans/2026-06-04-quote-lines-duplicate-inplace.md`.

Nota recalc: `_recalc_quote` (quotes.py:504) = canonico per mutazioni righe (sconti cat+pacchetto); `_recalc_quote_totals` (reverse_quote) = solo totali grezzi, usato da lines-transfer (potenziale gap se dest ha sconti — non fixato, follow-up).

**Feature α.172.187 — quote sorgente nella lista deliverable Planning** (push b1d9e6c). Card kanban badge `📄 Q-…` + colonna "Quote" nella lista + ricerca. `GET /jobs/api/deliverables/list` espone `quote_id`/`quote_number` (batch via `Job.quote_id`→`Quote.number`, no N+1). 395 test. Smoke browser verde (card + lista). Fatta diretta dal controller (no subagent, ~20 righe).

**Hotfix α.172.188 — copilot 500 su /planning** (push 15fc450). Matteo: copilot → "Unexpected token 'I'… not valid JSON" = il classico 500-plain-text [[feedback_jsonparse_col1_is_500]]. Root cause: `ai_context._build_planning_context` (riga ~519) usava `UnavailabilityKind.weekend` (membro enum INESISTENTE; reali: vacation/sick/holiday/permit_rol/recovery/other) → AttributeError nella label-map. Fix mappa. +2 test regressione (seed unavailability approvata → triggera il dict). Verificato `POST /ai/api/chat page=planning` → 200 JSON. **Follow-up offerto NON fatto**: wrap try/except sistemico su `/ai/api/chat` per JSON pulito su qualsiasi eccezione (la classe ricorre).

**Feature α.172.191 — TOOL-USE UNIVERSALE copilot** (push b8f95f7, subagent-driven 4 task). Prima solo Claude aveva tool-use. Ora adapter generico OpenAI-compatible: `app/services/openai_tools.py` (conversioni pure canonico Anthropic↔OpenAI: tools/messages/response, round-trip stabile, args via safe_json_parse) + `OpenAICompatToolsMixin` in `ai_provider.py` (richiede `_post_chat(payload)→dict` + self.model). Applicato a DeepSeek/Perplexity (httpx), OpenAI (SDK model_dump), Ollama (`/api/chat` normalizzato a {choices:[{message}]}). Loop `advance_loop` resta canonico (appende raw_assistant_message canonico + tool_result canonici). Claude invariato; Gemini+no-function-calling restano legacy markdown. 421 test (+18). **Smoke live DeepSeek**: copilot ha chiamato read_quote_lines e dato dettaglio righe consegna con qty di Q-2026-008-v4. Spec/plan in docs/superpowers/*/2026-06-04-universal-tool-use*. Catena del giorno: α.187 quote-in-deliverables → α.188 fix copilot 500 weekend → α.189 hardening chat JSON → α.190 conteggi consegne contesto + read_quote_lines → α.191 tool-use universale.

**Feature α.172.192 — FIX DELIVERABLE ORFANI** (push bafc902, subagent-driven 4 task). Matteo: lista planning deliverable GLO mostrava 82 vs quote v4=20 righe → 20 orfani (`quote_line_id` NULL). Diagnosi approfondita (code-explorer) 3 cause: **RC1** `migrate_job` (quotes.py:~4043) faceva soft-detach `quote_line_id=None` su riga rimossa in nuova versione invece di rimuovere → orfani accumulati a ogni migrazione + duplicati per-nome; **RC2** deliverable pre-restructure (<α.172.2, col quote_line_id aggiunta 20mag) NULL + backfill parziale; **RC3** `jobs.py:create_deliverable` manuale non setta mai quote_line_id. Fix: (1) migrate_job → `_deliverable_safe_to_remove` + **soft-delete guardato** (no NULL-detach, no duplicati) + filtro deleted_at sulla query; (2) `scripts/cleanup_orphan_deliverables.py` (guardato, dry-run default) → 20 orfani GLO rimossi 82→62, snapshot pre; (3) `link_deliverable_to_ghost` + `POST /jobs/api/deliverables/{id}/link-ghost` → collega manuali a phantom/Consuntivo quote (riusa _get_or_create_phantom). Invariante: ogni deliverable attivo → riga quote corrente o phantom. 434 test. Decisioni Matteo: riga rimossa→soft-delete; manuali→ghost-link. Spec/plan docs/superpowers/*/2026-06-04-orphan-deliverables-fix*.

NOTA copilot: il copilot vede solo le RIGHE QUOTE (read_quote_lines), NON la lista JobDeliverable del planning → ha dato numeri quote (15/20) mentre Matteo guardava i JobDeliverable. Backlog: tool copilot per leggere la lista planning deliverable.

**Feature α.172.193 — copilot legge+rinomina deliverable HUB** (push 83868d1). Matteo voleva che il COPILOT (non io a mano) rinominasse i deliverable GLO con suffissi episodio + feature generica. Costruite 2 capability: `read_job_deliverables` (readonly: lista deliverable job/progetto, colma gap "copilot vedeva solo righe quote") + `propose_rename_deliverables` (mutation gated Apply: rinomino batch via mapping {deliverable_id,new_name}). Il modello calcola i nomi, l'utente applica. apply_action dispatcha l'handler col payload. Verificato live DeepSeek: chiesto rinomino episodi GLO → copilot ha letto 62, proposto 60 rename CORRETTI (batch-6 NBCU+Sky CS→ep.101-106, CD→coppie 101+102/103+104/105+106, NC→dispari 101/103/105, Data mgmt+LTO esclusi), gated (AIAction #94 in attesa Apply di Matteo). 440 test. Pattern confermato: ogni mutator→propose_* + read tool readonly; copilot DeepSeek esegue tutto via tool-use universale α.191.

GLO struttura deliverable (job GLO-J007, quote→v5 id19, 62 deliverable post-cleanup): 2 singletons (Data mgmt 120TB, LTO 20TB) + NBCU 4 gruppi×6 + Sky CS 3×6 + Sky CD 3×3 + Sky NC 3×3. Suffisso CS/CD/NC nel name; section_label="NBCUniversal…"/"Sky Italia" sulla QuoteLine.

**α.172.193** — capability copilot `read_job_deliverables` + `propose_rename_deliverables` (push 83868d1). Il copilot ora legge la lista deliverable del HUB e propone rinomini batch (gated Apply). Matteo ha applicato il rinomino episodi GLO (60 nomi: batch-6→ep.101-106, CD→coppie, NC→dispari).

**α.172.194 — FIX guardia cleanup + restore capitolato** (push 94be517). Matteo: "dopo rinomina perse info capitolato". Diagnosi: il **rename era INNOCENTE** (0 delivery_item_id persi, verificato id-per-id vs snapshot). Vero colpevole = il mio **cleanup orfani α.172.192**: aveva soft-deleted 20 orfani (quote_line_id NULL), 13 con delivery_item_id, di cui **8 UNICI** (capitolato non più su nessun deliverable attivo: Subtitle EBU-STL/TTML, Dialogue/Music/DME Stem, ProRes varianti). LEZIONE: `quote_line_id IS NULL` NON basta come criterio orfano — un deliverable con `delivery_item_id` (link capitolato) è un requisito di consegna reale, va preservato. Fix: `_deliverable_safe_to_remove` ritorna False se `delivery_item_id` valorizzato (protegge cleanup E migrate_job soft-delete). Gli 8 ripristinati (deleted_at→NULL) + ghost-linkati a phantom quote #20. 441 test. GLO 70 deliverable.

Catena 4 giu COMPLETA: α.184→194 (11 versioni, tutte pushate). Multiselect quote+duplica, quote-in-deliverables, fix copilot 500+hardening, conteggi consegne, tool-use UNIVERSALE OpenAI-compat, fix orfani migrate_job+cleanup+ghost-link, copilot read+rename deliverable, fix guardia capitolato. Maratona subagent-driven.

Fuori progetto: discussa accensione remota PC via WoL (Iliadbox ha WoL nativo + app iliadbox Connect, no Raspberry serve).
