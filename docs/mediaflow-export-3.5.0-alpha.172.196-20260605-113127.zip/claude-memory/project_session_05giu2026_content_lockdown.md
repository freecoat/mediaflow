---
name: project_session_05giu2026_content_lockdown
description: α.172.195 Content Lockdown megaswitch egress cloud TPN — design + build + push
metadata: 
  node_type: memory
  type: project
  originSessionId: f44fde4f-54a1-47ad-81f3-aa311d6ca9d5
---

5 giu 2026. Discussione TPN (MPA Content Security v5.3.1) → costruito **Content Lockdown**, v3.5.0-alpha.172.195. Commit `be0f238` PUSHATO (origin main).

**Architettura discussa (decisioni di principio):**
- Cifratura NON aggira la confidenzialità: l'LLM deve leggere il chiaro; resta la clausola contrattuale "dati in infrastruttura approvata". Homomorphic = non produzione.
- Tokenizzazione SCARTATA come soluzione generale: degrada la conoscenza di dominio AI (Netflix→CLIENT-7 perde gli standard), mapping table = nuovo crown jewel, rehydration fragile, web enrichment incompatibile. Utile solo dove l'AI fa logica/matematica senza identità.
- Scelta = **LLM locale (Ollama) + megaswitch attivabile**, come da piano iniziale. Cloud = management-zone con zero-retention; content-zone = lockdown.
- Caveat audit-gaming (flip switch per audit): lo stato dello switch è loggato (lockdown_at/by) → il giro a vuoto è autodocumentato. Framing corretto = postura di deployment, non trucco peri-audit. Matteo informato, sua scelta.

**Implementazione (3 decisioni Matteo): 1=solo API locali (force-Ollama, copilot resta vivo), 2=default tenant esistenti OPEN, 3=master + sub entrambi.**
- `Tenant`: `lockdown_master` (OPEN|LOCKDOWN) + `cloud_ai_enabled`/`web_search_enabled`/`enrichment_enabled` + `lockdown_at`/`by`/`reason`. Master vince sui sub. Default OPEN+True = retrocompat.
- `app/services/egress_guard.py` chokepoint unico, **fail-closed** (tenant None→locked). Funzioni pure + `*_current(db)` (CURRENT_TENANT=1) + backstop `web_search_positively_locked()` per tavily.
- Wiring: `get_provider_for_user` forza Ollama se cloud_ai off; `_h_web_search` gate; `tavily_search` backstop; 6 endpoint enrich/crosscheck/filmografia (clients.py + projects.py) `assert_enrichment_allowed_current`.
- UI `/settings → 🔒 Sicurezza` admin-only (pane-security, JS lockdownLoad/Save/MasterToggle). RBAC `manage_cloud_lockdown`. `GET/POST /settings/api/lockdown`. `EgressLocked`→403 handler in main.py.
- Migrazione auto-boot (`_auto_migrate_columns` blocco tenants) + `scripts/migrate_cloud_lockdown.py`.

**460 test (+19: test_egress_guard 13 + _integration 6).** Smoke TestClient live: render pane+JS, round-trip toggle, force-Ollama (provider attivo deepseek→Ollama verificato), 401 unauth. **1 bug colto dallo smoke: User.full_name non .name** (fixato).

**PENDENTE**: Matteo restart :8000 + **browser smoke** del pane (toggle/banner/save/copilot→Ollama) — il TestClient conferma JS *presente* ma non l'esecuzione runtime browser (lezione [[feedback_smoke_e2e_browser]]).

**Backlog futuro**: self-test che TENTA davvero ogni egress (non solo config); registrare fs-scan + integrazioni future al guard; split content-plane (indexer read-only one-way) vs management-plane. Vedi [[project_hosting_decisions]] (deployment-per-tenant combacia).
