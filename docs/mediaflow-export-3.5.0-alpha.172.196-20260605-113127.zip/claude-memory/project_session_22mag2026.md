---
name: project-session-22mag2026
description: Maratona 22 mag 2026 — α.172.28 → α.172.34 (15+ commit). Tech sheet editabile + assenze ore + festività + multi-preset WHP + dropdown scheda tecnica + graphify.
metadata: 
  node_type: memory
  type: project
  originSessionId: d07cff20-e7c9-4380-b5a7-4b5f7957c80d
---

# Sessione 22 mag 2026 — Maratona α.172.28 → α.172.34

15+ commit pushati. Tunnel cloudflared `recall-audio-beautiful-recycling.trycloudflare.com` attivo. Server uvicorn locale vivo.

## Commit principali

| Ver | Tema |
|---|---|
| α.172.28 | Scheda tecnica progetto: link pubblico **editabile** (PUT/GET, identity nome+email, polling 30s concorrenza, log audit) + bug fix print α cp1252 |
| α.172.29 | Assenze a ore (start/end_time, hours_duration, kind +permit_rol/recovery) + festività custom (`Holiday` per-resource/location scope) + WorkingHoursPolicy accrual (annual_leave/rol/permit) + 2 AI capability (propose_ccnl_params, propose_holiday_set) |
| graphify install | knowledge graph codebase 3808 nodi via pipx + tree-sitter + claude-cli backend, PreToolUse hook Bash su grep/find |
| α.172.30 | PUT unavailability + UI edit ferie/permessi approvate + cashflow loadFilters difensivo |
| α.172.30.1/.2/.3 | Hotfix: click row permesso + cashflow JS load order + Jinja in commenti JS (1 file template OFFLINE due a `{% if %}` letterale) + admin shadow scope blocker |
| α.172.31 + .31.1 | HARD-BLOCK emit acconto senza JCL + NC stato `approved` init + cascade NC→AP draft + UI dropdown status |
| α.172.32 + .32.1/.2 | Multi-preset WorkingHoursPolicy UI (CRUD + duplicate + set-default) + accrual fields editabili + override per-resource + restriction person_internal + hide CCNL dropdown per non-umane |
| α.172.33 + .33.1/.2 | Refactor Holiday scope → policy (drop resource/location coupling) + delete+duplicate cascade festività + fix is_elevated shadow bug |
| α.172.34 | TechSheetFieldOption (dropdown campi scheda tecnica) + admin pannello /settings + ~250 valori seed Netflix Delivery Specs + editor pubblico usa `<select>` strict quando opzioni configurate |

## Lezioni / Memory create

- [[feedback_jinja_in_js_comments]] — α.172.30.3: `{% if x %}` letterale dentro commento JS rompe template parser. Parafrasa.
- [[feedback_jinja_shadow_globals]] — α.172.33.1: passare `is_elevated: bool` in TemplateResponse shadow funzione globale Jinja → TypeError 'bool not callable'. Usa `user_is_elevated`.
- [[reference_graphify]] — knowledge graph installato, 3808 nodi, comandi cli + setup.

## Stato lista Matteo (richiesta inizio sessione)

**Facili (6/6)**:
- ✅ #5 Edit permessi/malattia (α.172.30)
- ✅ #6 Cashflow dropdown (α.172.30)
- ✅ #2 HARD-BLOCK JCL acconto (α.172.31)
- ✅ #3 NC approved init (α.172.31)
- ✅ #4 Cascade NC→Acconto draft (α.172.31)
- ⚠️ #1 Quote-side preset acconto: solo backend ready (modal-advance-schedule), UI helper preset non implementato (rinviato).

**Complessi (3/3)**:
- ✅ B Multi-preset WHP (α.172.32)
- ✅ C Holidays scope policy (α.172.33)
- ✅ A Dropdown scheda tecnica + seed Netflix (α.172.34)

## DB stato post-sessione

- WorkingHoursPolicy: 2 preset (default)
- Holiday: 0 (resolver scope_policy_id pulito, legacy fields preservati)
- TechSheetFieldOption: 0 fino a quando Matteo non lancia "🎬 Seed Netflix"
- Tech sheet pubblico: enabled solo se Matteo genera link via UI

## Prossima sessione (Matteo voleva test intensivi)

1. **Test α.172.28-.34** prima di nuove feature. Punti caldi:
   - `/projects/{id}` scheda tecnica → genera link editabile → apri public editor → modifica → polling banner
   - `/finance` emit NC → status `approved` → transizione → sent
   - NC su acconto → AP torna draft
   - `/settings` → Orari lavorativi: crea/duplica/elimina preset → vedi cascade festività
   - `/settings` → Scheda tecnica → "🎬 Seed Netflix" → ~250 opzioni
   - `/hr/holidays` con scope policy CCNL
   - Modal risorsa per type=studio → no Orario lavorativo + no override accrual
   - Card 📊 Saldo nascosta per freelance/non-umane

2. **#1 Quote-side preset acconto** (rimanente facile): aggiungere preset selector in modal-advance-schedule (quote). Logica client-side compute (no endpoint server). Effort ~30min.

3. Backlog precedente (memory `project_session_21mag2026`):
   - Sconti CR audit
   - Deep test CR Deliverables + Assets
   - MAM init
   - PhysicalAsset logistics in/out + spedizioni

## File chiave toccati

- `app/models/models.py` — UnavailabilityKind +permit_rol/recovery, Resource +location_tag+overrides, Tenant +use_national_holidays, WorkingHoursPolicy +accrual, Holiday +scope_policy_id, ProjectTechSheet +edit_token, TechSheetEditLog, TechSheetFieldOption, InvoiceStatus +approved
- `app/routers/billing.py` — NC status=approved + cascade AP draft
- `app/routers/finance.py` — HARD-BLOCK emit acconto + transitions approved
- `app/routers/holidays.py` — CRUD festività + scope_policy_id + bulk import CSV
- `app/routers/settings.py` — Multi-preset WHP CRUD + cascade duplicate/delete festività
- `app/routers/tech_sheet_options.py` — NEW: CRUD options + seed Netflix
- `app/routers/tech_sheets.py` — edit_token publish/save granulare/polling/options pubbliche
- `app/routers/planning_unavailabilities.py` — PUT update + GET single + intra-day partial
- `app/routers/resources.py` — location_tag + overrides accrual
- `app/services/holidays_service.py` — get_effective_holidays via policy
- `app/services/leave_balance.py` — compute_leave_balance + _is_employee_eligible
- `app/templates/pages/tech_sheet_public_edit.html` — NEW: editor pubblico
- `app/templates/pages/holidays.html` — UI festività con scope policy
- `app/templates/pages/settings.html` — tab Scheda tecnica + Orari lavorativi multi-preset
- `app/templates/pages/hr.html` — modal timbratura unav + saldo + edit unavailability
- `app/templates/pages/resources.html` — override accrual + hide per non-umane
