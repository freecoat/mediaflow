---
name: project-session-23mag2026-sprint1
description: "23 mag 2026 — Audit multi-agent 5 paralleli, 131 finding, 37 P0. Sprint 1 chiuso (tenant scope). Sprint 2-5 backlog"
metadata: 
  node_type: memory
  type: project
  originSessionId: 6aa8c5c6-b1fb-4f0a-bebe-9271e39fc1eb
---

23 mag 2026 — Matteo lancia audit profondo dopo installazione plugin maestro+playwright. Sessione strategica + chiusura Sprint 1.

**Fase 1 — Audit (5 agent paralleli, ~150 finding totali)**:
- Agent 1 (DB models): ~40 finding — Float monetary 70+ campi, JCLBilledSlice solo router-level, FK senza ondelete, JSON no validation, unique+soft-delete bypass, 22 modelli senza tenant_id
- Agent 2 (Routers): 26 finding (10 P0) — tenant scope leak planning/finance/jobs/cost_report
- Agent 3 (UI/JS): ~50 finding — JSON.stringify in onclick (4 spot), helper redefiniti (fmtCurrency/fmtDate/fmtSize), setSelection bypass `_tlSetSel` in 9 spot planning.html, stack:true freeze, raw `${var}` innerHTML 25+ template, no CSRF, hardcoded colors
- Agent 4 (Cross-ref): 3 endpoint UI 404 (project_detail dam delivery-templates + job_detail resources/api/list), 8 AI capability missing legacy parser, 9 missing copilot labels, web_search documented senza handler
- Agent 5 (Finance): ~20 finding — slice-lock violato in quotes.py:1645/3105/1840/2028, Float vs Numeric, weighted_revenue DEAD CODE in cost_line_sync.py:320-401, Invoice.number UNIQUE globale, anomaly reopen non rimuove LossEntry/OverheadCost (double-count P&L), overtime brackets duplicate source divergente HR vs cost report, no validatori P.IVA/CF/SDI/natura

**Strategia 5 sprint α.172.35 → α.172.30+**:
1. Sprint 1: tenant scope (BLOCCO 1) ✅ CHIUSO α.172.35
2. Sprint 2: slice-lock symmetric + UI 404 (BLOCCHI 2+3)
3. Sprint 3: weighted_revenue + Float→Numeric + IVA per-riga + Invoice.number multi-tenant (BLOCCO 4)
4. Sprint 4: UI antipattern JSON.stringify + escapeHtml innerHTML + setSelection wrapper + CSRF (BLOCCO 5)
5. Sprint 5: DB integrity (FK ondelete) + immutability event listener + P.IVA/CF/SDI/natura validators + FatturaPA XML (BLOCCO 6 + P2 italian compliance)

**Fase 2 — Sprint 1 eseguito (α.172.35)**:
- Nuovo `app/services/tenant_guard.py` (scoped/fetch_or_404/fetch_invoice_or_404)
- Nuovo permesso RBAC `edit_cost_lines` (Finanza, assegnato admin/manager/producer/accounting)
- 23 query patchate in 4 router (planning/finance/jobs/cost_report)
- 2 endpoint deprecati rimossi (planning create_client + create_job, avevano bug tenant_id)
- Smoke import OK, app boota 512 routes

**Decisioni Matteo durante sessione**:
- Endpoint deprecati planning: rimuovi (non patch conservativo)
- Permission gate JCL update: nuovo permesso `edit_cost_lines` (non riusare `edit_invoices`)
- Approvato kickoff Sprint 1 immediato

**Stato in pausa**: commit unico Sprint 1 da fare. Vedi [[project-sprint1-tenant-guard]] per architettura helper.

**Next**: Sprint 2 = `assert_slice_lock_safe()` shared service estratto da planning.py + applicato a quotes.py 4 spot + fix 3 endpoint UI 404. Bump α.172.36+.
