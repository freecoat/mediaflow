---
name: project-session-25mag2026
description: Checkpoint α.172.75 chiusa 25 mag — smart_split a posteriori + propose_split_booking. Prossima sessione remoto via tunnel cloudflared. Test AI copilot + fase 5.
metadata: 
  node_type: memory
  type: project
  originSessionId: 145e82bb-bd2b-4c22-a087-0f5b45f7edad
---

**Stato**: chiusa sessione 25 mag 2026 mattina. Tunnel cloudflared per riapertura remota.

**Versione corrente**: v3.5.0-alpha.172.75 (push fatto, commit `3cb6335` su main).

**Lavoro completato α.172.75**:
- `PUT /api/bookings/{id}` accetta `smart_split: bool` (replace-all espande via `_expand_assignments_smart`).
- Nuova capability AI `propose_split_booking(booking_id, new_start_datetime?, new_end_datetime?)` — ri-splitta assignment correnti su WHP+ferie+festivi correnti, replace-all atomico + recompute + audit `ai_split`.
- Memo durevole salvato: `feedback_copilot_more_capabilities.md`.
- Export ZIP creato + push.

**Prossima sessione (remoto via tunnel)**:

1. **Test AI copilot** sul nuovo flusso split a posteriori:
   - Booking esistente multi-risorsa → "ri-splitta saltando pausa pranzo" → verifica replace-all + envelope aggiornato + recompute cost line.
   - Booking con WHP cambiata → "ricalcola questo booking" senza override → verifica nuovi segmenti.
   - Booking con override `new_start/new_end` → estensione + split.
   - Conflict edge case: range che invade booking di altra risorsa.
   - Slice-lock: tentare split su booking dentro JCLBilledSlice → ValueError leggibile.
   - Booking single-resource senza policy → fallback monolitico (non crashare).

2. **Trafila Fase 5** (capitolato → quote auto):
   - Vedi `deliverables_parser.match_deliverables_to_pricelist` (già esistente, da cablare in UI).
   - 17 capitolati reali in `docs/capitolati_esempio/` per test corpus.
   - Schema 8 blocchi `DeliveryTemplate` già stabile.
   - Cablare: upload capitolato → parser → preview deliverable + match listino → conferma utente → genera quote A/B/C.

3. **Restart server PRIMA del test** (memo standard) — schema invariato ma codice AI cambiato.

**Memorie chiave da consultare al riavvio**:
- `feedback_copilot_more_capabilities.md` — direttiva: ogni mutator → capability AI
- `feedback_smoke_e2e_browser.md` — smoke browser obbligatorio per JS
- `feedback_cache_buster_static.md` — bump version invalida static
- `feedback_log_report_apertura.md` — diagnostica + piano + conferma prima di toccare codice
