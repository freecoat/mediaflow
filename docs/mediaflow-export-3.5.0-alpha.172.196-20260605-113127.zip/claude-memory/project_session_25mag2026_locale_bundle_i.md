---
name: session-25mag2026-locale-bundle-i
description: "Ripresa sessione locale 25 mag. K backloggata. Chiusi 4 bundle: I (α.172.89) + J (α.172.90) + H2 (α.172.91) + H3 (α.172.92). 4 commit locali non pushati. Roadmap completa. Test live + report rinviati a 26 mag."
metadata: 
  node_type: memory
  type: project
  originSessionId: c42c25f8-590b-44dd-a57a-f2cb243860a2
---

Sessione 25 mag 2026 sera — ripresa locale post-tunnel cloudflared.

**Why**: continua roadmap K→I→J→H2→H3 da `project_session_25mag2026_pomeriggio.md`. K rimandata su richiesta utente ("metti in backlog"), saltato direttamente a I.

**How to apply**: vedi `docs/STATO.md` α.172.89 + CHANGELOG per dettaglio. Prossima ripresa parte da J (Planning HUB deliverable).

## Bundle I chiuso (α.172.89, commit e4b88aa)

Stati nested + cascade QC reject. Restructure systemic, NON tappa-buchi (memo [[feedback_approccio_generico]] rispettata).

| Componente | File | Note |
|------------|------|------|
| Enum modelli | `app/models/models.py` | DeliverableStatus 5 main, QCSubstatus nullable, AssetStatus nuovo, NotificationKind.deliverable_qc_rejected |
| Migrazione | `app/main.py::_auto_migrate_bundle_i` + `scripts/migrate_phase_i_deliverable_status.py` | Mapping legacy CONSERVATIVO (no auto-cascade su dati storici) |
| Cascade service | `app/services/qc_cascade.py` (nuovo) | `cascade_qc_reject()` idempotente: status reset + asset rejected + spawn placeholder + notify_permission view_finance |
| Router jobs | `app/routers/jobs.py` | update_deliverable esteso (qc_substatus + cascade trigger), nuovo `/close`, nuovo `/qc-report` upload |
| Hook planning | `app/routers/planning.py` | Booking→Deliverable auto-bump in_progress (idempotente, audit-log) |
| AI capability | `app/services/ai_assistant.py` | `propose_qc_report_summary`: legge PDF via pypdf, JSON {passed,issues,notes}, salva su DeliverableAsset.notes |
| Endpoint AI | `app/routers/ai.py` | `/ai/api/deliverables/{id}/qc-report-summary` invoca capability inline |
| UI | `app/templates/pages/cost_report.html` | 5 badge main + sub-badge QC, 5 bottoni azione per-stato, upload PDF + AI summary background |

522 routes (+1). 1000+/57- lines. 14 file modificati, 2 nuovi.

## Decisioni discussion-driven

| Domanda | Risposta scelta |
|---------|-----------------|
| Mapping legacy | Conservativo (no auto-cascade) |
| Asset.status field | Sì, enum nuovo (planned/uploaded/rejected/accepted) |
| QC reports M:N | Riuso DeliverableAsset con `source='qc_report'` |
| Trigger booking→deliv | Hook esplicito in router (no SQLAlchemy listener) |
| K label forecast | Rename "Quotato vs Maturato + Da Fare" (poi BACKLOG) |
| K2 scope toggle | Solo Quotato + Maturato (poi BACKLOG) |

## Push NON fatto

Memo policy [[feedback_push_solo_major]]: locale = push solo major bump. α.172.89 patch.
Memo [[feedback_export_zip_at_push]]: nessun export ZIP (no push).
Decisione utente futura: push manuale quando vorrà sync remoto.

## Roadmap residua

1. ~~K — CR cleanup + ore toggle~~ → BACKLOG (parcheggiato 25 mag)
2. ~~I — Stati nested Deliverable~~ ✅ α.172.89
3. ~~J — Planning HUB Deliverable~~ ✅ α.172.90
4. ~~H2 — Jobs page modal READ-ONLY~~ ✅ α.172.91
5. ~~H3 — Asset Library status + metadata~~ ✅ α.172.92
6. **Test live + report Matteo** TUTTI rimandati a domani 26 mag

## Bundle H3 chiuso (α.172.92, commit f2db474)

Asset Library: metadata tecnici via ffprobe + delivery linked status.

| Componente | File | Note |
|------------|------|------|
| Service metadata | `app/services/asset_metadata.py` (nuovo) | ffprobe subprocess + Pillow fallback. Shape `{tool, video, audio[], container, errors}` |
| Endpoint metadata | `app/routers/dam.py` | `GET /dam/api/assets/{id}/metadata` |
| Endpoint delivery | `app/routers/dam.py` | `GET /dam/api/assets/{id}/delivery-info` (aggrega FK legacy + pivot) |
| Helper | `app/routers/dam.py` | `_serialize_deliv_for_asset` |
| UI modal asset | `app/templates/pages/dam.html` | showAssetDetail refactor DOM API + 2 sezioni async (Delivery + Specifiche file) |

526 routes (+2). Schema DB invariato. 6 file modificati (+582/-13).

**Stack metadata**: ffprobe esterno (assente OK, fallback Pillow per image/*). Timeout 8s, no eccezioni. Cache: nessuna (re-estrazione idempotente). Per S3 paths skip gracefully.

## Bundle H2 chiuso (α.172.91, commit dcb142b)

Allineamento /jobs/{id} a Bundle I + separazione editing → Planning HUB (Bundle J).

| Componente | File | Note |
|------------|------|------|
| Enum status JS | `app/templates/pages/job_detail.html` | DLV_STATUS_LABEL/COLOR 5 valori + DLV_QC_SUB_LABEL nested |
| Kanban 5 colonne | job_detail.html | Footer link a /planning, click card → read-only modal |
| Card list + kanban | job_detail.html | Sub-badge QC, status closed 🔒, event.stopPropagation su bottoni interni |
| Modal #modal-jd-specs | job_detail.html | 8 blocchi `<pre>` JSON pretty, banner "Read-only", footer link Modifica in /planning |
| Helper JS | job_detail.html | jdOpenSpecsReadonly(id) + JDSM_BLOCK_DEFS |

524 routes invariato. Schema DB invariato. 4 file modificati (+216/-32).

Risolve bug spec H2 "non posso modificare consegne": editing avviene SOLO da Planning HUB, /jobs/{id} è overview operativo. Conferma consegna resta funzionante (atto operativo, non workflow).

## Bundle J chiuso (α.172.90, commit f2bc21e)

Planning HUB Deliverable + modal tech specs 8 blocchi + AI propose_specs. Riusa schema `DeliveryTemplate` (no schema DB change).

| Componente | File | Note |
|------------|------|------|
| Endpoint list tenant-wide | `app/routers/jobs.py` | `GET /jobs/api/deliverables/list` join Job+Project, filtri opzionali |
| Tab + view Planning | `app/templates/pages/planning.html` | `📦 Deliverable` + view-deliverables con kanban/lista toggle |
| Kanban 5 colonne | planning.html JS | Draggable, drop su QC default sub=in_progress, drop closed=`POST /close` |
| Modal tech specs | `#modal-deliverable-specs` | 8 textarea JSON + dropdown template + 📋 Applica + 🤖 AI |
| AI capability | `app/services/ai_assistant.py` | `propose_deliverable_specs` category=readonly adatta 8 blocchi template a deliverable |
| Endpoint AI | `app/routers/ai.py` | `POST /ai/api/deliverables/{id}/propose-specs` form template_id |

524 routes (+2). Schema DB invariato. 7 file modificati (+629/-12).

Spawn N deliverable da QuoteLine quantity>1: già esistente da α.172.14 in `jcl_to_deliverable_migrator.py`. Requirement Bundle J coperto senza modifiche.

## Test plan I (post-restart server, da fare con Matteo)

1. Verifica console log `[auto-migrate-bundle-i]` se DB ha enum legacy
2. /cost-report progetto con deliverable → badge stato corretto
3. Workflow: ▶ Avvia → 🔍 QC → 📎 Upload PDF QC → toast "🤖 PASS/REJECT" → ✓ Pass o ✗ Reject (con cascade)
4. Verifica spawn placeholder in /dam dopo reject
5. Verifica notifica `deliverable_qc_rejected` in drawer notifiche
6. /jobs/{id} → 🔒 Chiudi → 409 su update successivo
7. Booking linkato a deliverable planned → bump execution_status=in_progress → deliverable auto in_progress
8. Idempotenza: ripeti cambio stato booking, no double-spawn placeholder
