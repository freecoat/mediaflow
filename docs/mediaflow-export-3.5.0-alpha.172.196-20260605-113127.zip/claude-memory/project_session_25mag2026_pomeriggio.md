---
name: session-25mag2026-pomeriggio
description: Maratona 25 mag pomeriggio. 13 commit α.172.76→α.172.88. Bundle E (log azioni)→B (smart_split fix)→A (bulk AI+404)→C (timeline UX)→D (chat naming)→F (P0 capitolato/smart_split/Ctrl+Z/badge)→G (Deepseek+unit)→H1 (anomaly warning booking). Roadmap K→I→J→H2→H3 concordata prossima sessione locale.
metadata: 
  node_type: memory
  type: project
  originSessionId: 00ee029d-7e15-45f5-85e8-2d35f17032fc
---

Sessione 25 maggio 2026 pomeriggio. Matteo prosegue da remoto via tunnel cloudflared (`cook-lenses-desired-motorcycles.trycloudflare.com`) finché chiude per riprendere in locale da casa la sera.

**Why**: maratona test + fix successivi dopo chiusura α.172.75 mattina. Bundle organizzati per scopo, ognuno con commit dedicato.

**How to apply**: vedi [[project_session_25mag2026]] per la sessione mattutina e `docs/STATO.md` per roadmap dettagliata K→I→J→H2→H3.

## Bundle pushati locale

| Ver | Bundle | Sintesi |
|-----|--------|---------|
| α.172.76 | E | Log azioni Ctrl+Shift+L, verbose mode, ring buffer localStorage |
| α.172.77 | B | smart_split AI fallback policy default tenant |
| α.172.78 | A | propose_bulk_split/delete_booking + fix 404 pricelist + itemsDS scope |
| α.172.79 | C | auto-refresh timeline post-Apply AI + milestone (poi rivisto) + sidebar ellipsis |
| α.172.80 | D | AI chat rename/delete + auto-title `<Project>·<msg40>` |
| α.172.81 | F P0 | capitolato provider per-utente, smart_split edit, milestone className, Ctrl+Z capture, stato quote badge |
| α.172.82 | F7+F8+F9 | AI quote naming convention + milestone def-fix + project mode parent rows |
| α.172.83 | hotfix | revert F8 + scope F9 `[data-group-by="project"]` |
| α.172.84 | flat project | tlBuildGroupsByProject rimuove nestedGroups, header inline |
| α.172.85 | fix | Client.code (no exists) → Client.name sanitizzato + run_in_threadpool per AI |
| α.172.86 | split capitolato | parse + match in due endpoint per evitare cloudflare 524 |
| α.172.87 | G1+G2 | DeepSeek provider (deepseek-chat V3 + deepseek-reasoner R1), unit select width |
| α.172.88 | H1 | anomaly warning booking single-type (umani-only o studio-only) + force_single_type override |

## Roadmap concordata prossima sessione

Ordine: **K → I → J → H2 → H3**

- **K** CR cleanup: rimuovi "Stima vs Quotato" obsoleta + toggle "Cassa €" ↔ "Ore" su colonne JCL
- **I** Stati nested Deliverable: main (planned→in_progress→qc→delivered→closed) + qc_substatus nullable (in_progress|pass|rejected). QC rejected cascade: deliverable→planned + asset rejected + spawn nuovo asset placeholder + notifica in-app. delivered→closed manuale. QC report uploads M:N + AI propose_qc_report_summary. Email notification: backlog (no SMTP)
- **J** Planning HUB Deliverable centrale: panel kanban DRAGGABLE (drag change status) + lista, click apre modal DETTAGLI TECNICI 8 blocchi (riusa schema DeliveryTemplate). Quote line generica (3× DCP) spawn 3 JobDeliverable rinominabili. Capability AI `propose_deliverable_specs` legge capitolati
- **H2** Jobs page: kanban/lista READ-ONLY overview, click apre stesso modal di Planning ma READ-ONLY. Bug "non posso modificare consegne" risolto via Planning (edit lì)
- **H3** Asset Library: status delivery linked + metadata tecnici letti da file (ffprobe/mediainfo). NO modal edit. Asset rejected via cascade I3. Possibile force-pass manuale

## Backlog aperti

- Booking duplicati Filmetto Dailies (3/data invece di 2 — frutto test iterativi). Pulire via `propose_bulk_delete_booking` + ricreare con smart_split=true.
- CR Filmetto 24300 vs quote 16200 → matematicamente corretto, sintomo dei booking duplicati sopra.
- H1.bis: anomaly check su capability AI `_h_propose_booking` + `_h_propose_recurring_bookings`.

## Punto di ripresa

Server stoppato + tunnel chiuso. Prossima sessione locale: `python run.py` standard senza tunnel. Riprende dal punto K.
