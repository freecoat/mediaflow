---
name: project-session-27mag2026-bundle-l-stack1
description: "Sessione 27 mag 2026 — Bundle L Stack 1 chiuso completo (Task 4-17), 19 commit pushati α.172.96"
metadata: 
  node_type: memory
  type: project
  originSessionId: 7e0c7ada-945b-4bb9-bb2a-4794a7b67c52
---

Sessione 27 maggio 2026. Bundle L Stack 1 COMPLETO e pushato.

**Versione finale**: v3.5.0-alpha.172.96 (commit 2fec573, pushato origin/main).

**Riepilogo**: 19 commit (1 cleanup + 17 task + 3 milestone bump). 17/17 task Stack 1 done. 24 test pytest verdi. 532 routes (+5). Pattern subagent-driven task-by-task con review code-reviewer per task sostanziali (Task 4, 5, 7).

**Why**: chiusura cantiere Bundle L Stack 1 (foundation tech specs unified Asset↔Deliverable↔QC). Prerequisito per Stack 2-5.

**How to apply**: prossima sessione = Stack 2 (QC event-sourced). Prima scrivere plan tipo `docs/superpowers/plans/2026-XX-XX-bundle-l-stack2-qc-eventsourced.md` poi esecuzione subagent-driven stesso pattern. Schema DB Stack 1 pronto, no breaking changes futuri attesi.

**Artefatti committati**:
- Modelli: VariantSchemaVersion + DeliveryVariant + DeliveryVariantCategory enum (app/models/variant.py)
- Estensioni: JobDeliverable.variant_id + 3 snapshot, Asset.tech_specs_json + 3 metadata (app/models/models.py)
- JSON Schema: schemas/variant_v1.json (draft-07 canonical URI)
- Service: app/services/variant_schema.py (load_active_schema, validate_variant_spec)
- Plugin registry: app/services/tech_specs_extractor/ (ABC + FFProbe + Pillow)
- Wrapper legacy: app/services/asset_metadata.py -180/+25 righe
- Boot helpers: _auto_migrate_bundle_l_stack1 + _seed_variant_schema_v1 + _auto_backfill_jd_variant_match (app/main.py)
- Script: scripts/parse_capitolati.py (17 corpus → 200 stub) + scripts/import_parsed_variants.py
- Router: app/routers/delivery_variants.py (5 endpoint CRUD listing)
- UI: app/templates/pages/delivery_variants.html + sidebar link in base.html
- Tests: tests/{conftest,test_variant_model,test_variant_schema,test_tech_specs_extractor,test_parse_capitolati}.py

**Lezioni operative emerse**:
1. Fixture autouse snapshot/restore _REGISTRY in test extractor — pattern critico per evitare pollution Task 8/9 quando FFProbe/Pillow registrati al boot vincerebbero first-match-wins su Dummy test extractor. Pattern `importlib.reload(extractor_module)` DENTRO test body riattiva @register_extractor decorator dopo clear.
2. Canonical draft-07 metaschema URI per jsonschema 4.26+ = `http://json-schema.org/draft-07/schema#` (con `#` finale + http NON https). Altrimenti DeprecationWarning su fallback metaschema unknown.
3. asset_metadata.py wrapper compat: firma identica `extract_asset_metadata(file_path, mime_type=None)` evita modifiche a dam.py consumer. Refactor da 190→15 righe via delegation a extract_tech_specs registry.
4. _R REGISTRY pollution + `out.setdefault("tool", cls.name)` + `logger.exception` su catch-all = 3 fix preventivi MEDIUM emersi da code review Task 7. Applicati subito.

**Edge cases corpus capitolati**:
- 2 file .txt 0-byte (Amazon MGM + Netflix) — da popolare con contenuto reale
- 1 file .doc legacy (Veterans Sales Agent) — python-docx supporta solo .docx
- 1 PDF scannerizzato (Beta Film, 13 char estratti) — richiede OCR fallback (defer Stack 5)
- Top chunk contributor: XLSX NBCU TechOps metadata template (66 chunk / 1.5M char)

**TODO Matteo prossima sessione**:
1. Test E2E browser `/delivery-variants/` (counter, filtri, soft-delete)
2. Popolare 2 file 0-byte se possibile
3. Decidere se eseguire `scripts/import_parsed_variants.py --input docs/superpowers/specs/capitolati-parsed/` (importa 200 stub — molti invalidi contro schema reale, OK per smoke)
4. Brainstorm Stack 2 (QC event-sourced)

Vedi [[user-matteo]] [[project-alpha120-backlog]] [[project-session-26mag2026]].
