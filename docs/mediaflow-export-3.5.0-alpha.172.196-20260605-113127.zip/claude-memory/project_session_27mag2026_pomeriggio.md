---
name: project-session-27mag2026-pomeriggio
description: "Sessione 27 mag pomeriggio — 4 fix verificati per Matteo (smart_split, duplicate, bin-prefix, versioni inline) + 1 backlog tree-view lista quote. Tutto in working tree non committed, α.172.97 da chiudere prossima sessione."
metadata: 
  node_type: memory
  type: project
  originSessionId: 8aaa65b8-4ed3-458c-854b-4f74d57e890f
---

Sessione test Matteo su `Filmetto Test 01-J004 · Cattleya`. Lavoro in WIP α.172.97.

**Fix verificati end-to-end (4):**

1. `app/services/cost_line_sync.py:149` — `_booking_billable_hours` aggregazione per resource_id PRIMA del max. Smart_split (Luca AM 4h + Luca PM 4h) ora somma a 8h come atteso (era max=4h). Bug riproduceva 144h vs 288h attese.
2. `app/services/numbering.py:74` — `next_progressive_code` ora scan ALL match + max(N), no ORDER BY id.desc(). Risolve 500 IntegrityError su duplicate quando esistono versioning `-vN`.
3. `app/services/soft_delete.py` — Quote soft-delete rinomina `number` a `~B<id>~<orig>` per liberare UNIQUE. Restore strippa prefisso, se collision suffix `_R<id>`. Auto-backfill al boot via `_auto_bin_prefix_deleted_quotes` (`app/main.py`).
4. `app/templates/pages/quotes.html` — `loadVersionsArea` ora inietta dentro card "Stato & azioni" (era card separata). Bottone migrate-job spostato dentro. Card `versions-area` rimossa.

**Backlog prossima sessione (1):**

5. Tree-view `/quotes/` lista quotazioni. Tentativo scaffolded in template (gruppi per root_quote_id, children indentati con ↳, ghost-row se filtri nascondono root). Backend endpoint `/quotes/api?include_superseded=true` ora include `parent_quote_id` + `created_at`. Matteo dichiarato "fuorviante" ma non ha ancora validato il nuovo render in browser — decide se tenere tree o revert flat.

**Stato DB**: bin-prefix backfill già applicato (3 quote cestinate). Dailies J004 qty_actual=18→36 patched via `scripts/backfill_jcl_billable_hours_alpha172_97.py`.

**Punto ripresa**:
- App running su localhost:8000 (lifespan = sessione)
- Tunnel cloudflared `https://load-achieved-jerry-indicators.trycloudflare.com` (lifespan = browser open)
- Login: `admin@mediaflow.it / admin123`
- Da fare: Matteo verifica tree-view in browser → decide tenere/revert → bump α.172.97 + CHANGELOG + commit bundle unico.

Vedi [[project-session-27mag2026-bundle-l-stack1]] per contesto sessione mattina.
