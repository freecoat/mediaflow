---
name: project_session_27mag2026_sera_stack2
description: Sessione 27 mag sera + 28 mag mattino. α.172.97 (folder-view + guard versioning + UI fix) + α.172.98 (Bundle L Stack 2 milestone 1/3 QC event-sourced foundation). 2 commit locali NON pushati. Server up.
metadata: 
  node_type: memory
  type: project
  originSessionId: 63897046-8e34-4fb1-9910-f4624b8f7262
---

**Versione locale**: α.172.98 (b5a5104). 2 commit pendenti push (fac2cad α.172.97 + b5a5104 α.172.98).

**Sessione 27 mag sera**:
- α.172.97 amended con tutti i fix di giornata: folder-view `/quotes/` (raggruppa per base_code, stacked status cards Approvata>Inviata>Bozza>Scaduta>Rifiutata, accordion expand/collapse, localStorage persistence, filtri preservati), numbering uniforme -v1 (helpers `with_v1_suffix` + `split_version_suffix`), backfill -v1 al boot, guard versioning (409 se approvi v2 direttamente quando v1 has Job), z-index `.topbar` 50→100 (fix popover sotto al-side listino), font scale topbar (🔍 6 step 100→150%, `body { zoom }`, localStorage `mf_font_scale`).
- Bug DB residuo Q-2026-005: 2 quote approved (v1+v2) + 2 Job (Filmone-J005 attivo + Filmone-J006 duplicato con 111 deliverable spawn-per-unit). Pulizia deferred. Guard preventivo applicato.

**Sessione 28 mag mattino — Stack 2 milestone 1/3 (α.172.98)**:
Bundle L Stack 2 foundation event-sourcing QC. 9 file +1523/-9. Models QCEvent append-only + QCReport projection + 13 event types (9 orig + qc_reopened, note_added, correction_requested, signoff_added). Service `qc_events.py` 11 funzioni. Router `qc.py` 13 endpoint REST. Listener immutability (NOT after_insert per projection — chiamata esplicita `apply_projection_for_event` dal `_emit`, evita SQLAlchemy flush-quirk). Sostituzione path Bundle I `update_deliverable` → delega a `qc_events.start_qc/pass_qc/fail_qc`. Cascade reject preservato. Backfill auto al boot per legacy `qc_substatus`. Tenant.tech_specs_refresh_days configurabile (default 30).

**Decisioni A/B/C/D Stack 2** confermate:
- A = per-asset granularity (QCEvent.asset_id)
- B = 13 event types enumerati, payload_json dict libero (no jsonschema runtime)
- C = projection sync sincrona dal service (no after_insert listener)
- D = listener sincronizza JobDeliverable.qc_substatus per back-compat Bundle I

**Smoke E2E API verificato** (DB pulito): start → log video err → pass → reopen → start v2. Tutti i 5 step OK.

**Stack 2 prossimi milestone**:
- α.172.99 Stack 2 milestone 2/3 — UI rich modal QC (timeline events loggabili, Storia QC tab, 6 bottoni esiti, integrazione `/planning` HUB Bundle J).
- α.172.100 Stack 2 milestone 3/3 — tests pytest (immutability, projection correctness, backfill idempotency, reopen flow, qc_number progression).
- Stack 3+ — ingest Excel FbF + capability AI `propose_qc_from_asset_diff` + export PDF.

**Test browser Matteo pendenti (per domani)**:
1. `/quotes/` folder-view + filtri stato + zoom topbar + popover theme/lang sopra side panel.
2. Q-2026-004-v4 (id=10): bottone "Approvata" disabilitato grigio + hint giallo "Usa Migra Job".
3. Migrate-job funzionante su Q-2026-004-v4 (parent v1 ha Job J004).
4. Nuova quote dal modal → numero `Q-2026-NNN-v1`.
5. Endpoint QC: smoke browser su `/qc/api/deliverables/{id}/start` (curl via console).

**Server**: up su `127.0.0.1:8000` v3.5.0-alpha.172.98. Tunnel cloudflared NON attivo (lifespan locale).

Login dev: `admin@mediaflow.it / admin123`.
