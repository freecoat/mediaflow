---
name: project_session_28mag2026
description: Sessione 28 mag 2026 maratona. 11 commit pushati α.172.97→α.172.108. Stack 2 CLOSE + 5 fix test browser + cashflow bug Cattleya + i18n auto-swap DOM 80 stringhe.
metadata:
  type: project
  originSessionId: 2026-05-28-full
---

**Versione finale**: α.172.108 (3d4a70c). Tutto pushato.

**Sequenza 11 commit pushati**:
- fac2cad α.172.97 — folder-view quote + guard versioning + UI fix (era locale, pushato)
- b5a5104 α.172.98 — Bundle L Stack 2 m1/3 foundation (era locale, pushato)
- e8df8ed α.172.99 — Fix test browser 3 punti (CR qty respawn + folder ventaglio + TB doc)
- 40c3a1d α.172.100 — Stack 2 m2/3 UI rich modal QC
- e0213ac α.172.101 — Stack 2 m3/3 CLOSE pytest QC (28/28 green)
- 52ea35c α.172.102 — Folder badge orizzontale (poi rifatto verticale)
- e2970ee α.172.103 — Cashflow cancelled orfane bug Cattleya (88650 → 18025.50)
- a1aa0e4 α.172.104 — Cashflow filtro project denorm + NC re-include
- a96a451 α.172.105 — Stacked vertical strips + tech specs modal human-readable
- 79513e3 α.172.106 — i18n aggiunto ES + audit report 477 stringhe / 40 file
- bbe99cd α.172.107 — i18n auto-swap DOM 61 stringhe common live IT→EN/FR/DE/ES
- 3d4a70c α.172.108 — i18n round 2: dict +50 parole (80/200 unique tradotte)

**Stack 2 Bundle L = COMPLETO**: foundation (α.172.98) + UI (α.172.100) + 28 pytest (α.172.101).

**Pulizia DB Q-2026-005** (fatto pre-α.172.103): Quote v2 (id=9) + Job J006 (id=3, 111 deliverable spawn-per-unit bug) eliminati. Snapshot pre-cleanup in `db_snapshots/snapshot-3.5.0-alpha.172.99-pre-cleanup-q2026005-*.db`. Stato finale: Quote v1 (id=2) + Job J005 (3 JCL, 12 deliv legit).

**Cashflow bug Cattleya (root cause + fix)**:
- 8 TD01 cancelled stesso giorno + 1 NC TD04 (no FK NC→TD01 nel modello).
- Logica α.114 contava cancelled SEMPRE come +sign assumendo NC contropartita.
- 7 TD01 cancelled ORFANE (no NC matching) → +68950 fantasma.
- Fix 1 (α.172.103): matching heuristico NC→TD01 (client+total+date+greedy 1:1) → skip cancelled orfane.
- Fix 2 (α.172.104): filtro project_id ora supporta `Invoice.project_id` denormalizzato (era solo Job.project_id) + re-include NC TD04 con project_id=NULL quando TD01 stornata è nel filtro.
- Verifica: tutti 3 scenari (no-filter, filter project=1, filter client=2) convergono a invoiced=18025.50.

**Stacked folder cards** (α.172.105 finale): verticale, top card chip standard con label, sotto N strisce orizzontali sottili (~4px, 80% width, color solido) con tooltip nativo. NO animation, NO ventaglio (rifatto post-screenshot Matteo "non mi piace").

**Modal Tech Specs deliverable** (α.172.105): rendering pretty default (tabella key-value, chiavi humanized, valori scalar editable inline) + toggle "📝 Modifica JSON" ↔ "👁 Vista leggibile" per power user. `_dsmCurrentSpec` cache globale del modal. Type coercion al save.

**i18n setup (α.172.106-108)**:
- 5 lingue: it (sorgente) + en + fr + de + es (aggiunto).
- `tools/i18n_audit.py`: scansiona templates+JS, identifica stringhe IT hardcoded non coperte (477 totali, 200 unique, 40 file).
- `tools/i18n_generate_entries.py`: dictionary statico IT→target → emette 200 entries (80 tradotte + 120 TODO_TRANSLATE).
- `app/static/js/i18n.js` `MF_I18N_AUTO_SWAP` dict (80 entries common.* + auto.*) + `applyAutoSwap()` brutale DOM scan al cambio lingua. WeakMap `_MF_ORIG_TEXT` per round-trip cambio lingua.
- Cambio lingua testabile via popover topbar 🇮🇹🇬🇧🇫🇷🇩🇪🇪🇸.
- Coverage stimato: 70-75% delle stringhe più ricorrenti.

**Server**: down per reboot Matteo. Al riavvio: `avvia_muto.bat` o `python -m uvicorn app.main:app --reload`.

**Test browser pendenti Matteo** (post-reboot):
1. Edit voce LTO LTFS Archive TB qty=100 → pc qty=10 → CR mostra 10 row pc.
2. Folder /quotes/ con 3+ stati diversi → stack verticale + strisce sottili sotto top card.
3. Click su card deliverable in /planning HUB → modal Tech Specs vista pretty (table key-value editable). Toggle "Modifica JSON" passa a textarea raw.
4. Cambio lingua popover topbar → swap immediato DOM "Annulla/Salva/Cliente/etc" in EN/FR/DE/ES + round-trip ritorno IT funzionante.
5. Bottone QC su card deliverable (job_detail + planning) → modal QC event-sourced funzionante (start/log/pass/fail).
6. Cashflow 2026-05: solo 18025.50 invoiced (no più 88650 fantasma). Filtri progetto/cliente non azzerano.

**Prossimi step post-reboot** (in ordine probabile):
- Test browser dei 6 punti sopra.
- Hotfix di eventuali bug emersi nel test.
- i18n round 3: traduzione 120 TODO restanti (manual top-30 OR capability AI `propose_i18n_translations` da costruire).
- Bundle L Stack 3+: ingest Excel QC FbF, capability AI `propose_qc_from_asset_diff`, export PDF QCReport.

**Login dev**: admin@mediaflow.it / admin123.

**Versione app HEAD**: 3.5.0-alpha.172.108.

Vedi anche: [[project_session_27mag2026_sera_stack2]] (sessione precedente, α.172.97+α.172.98 locali), [[project_tb_ammontare_rendicontativo]], [[feedback_no_jsonstringify_in_onclick]].
