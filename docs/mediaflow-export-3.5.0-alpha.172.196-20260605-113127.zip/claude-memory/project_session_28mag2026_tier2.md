---
name: project-session-28mag2026-tier2
description: "Maratona 28 mag 2026 — i18n round 3, batch parse 17 capitolati, big rearchitecture delivery taxonomy Tier 1+2"
metadata: 
  node_type: memory
  type: project
  originSessionId: 9cf93d2a-562a-49b6-bf7b-8874af43cd59
---

Sessione lunga 28 mag 2026, 8 commit pushati origin/main: α.172.109 → α.172.116.

**i18n round 3** (α.172.109)
- Audit tool patchato: filtri false positive (CSS hex, JS template literal, expressions, data-* attr) + AUTO_SWAP coverage check. 477 → 64 uncovered.
- MF_I18N +43 entries (5 lingue) per pagine specifiche.
- data-i18n esplicito in 15 template + copilot.js con mfT() runtime.
- Risultato: 477 → 15 (di cui 7 doc utente scelta + 6 falsi pos residui + 2 placeholder). 575 chiavi MF_I18N + 80 AUTO_SWAP.

**Batch parse 17 capitolati** (α.172.110, α.172.111)
- Fix `parse-sample` 503 cieco: `extract_json` salva diagnosi reale in `provider.last_extract_diag`.
- Fix `/pricelist/api` 404 (era `/pricelist/api/items`).
- Audit 17 file: 14 estraibili, 3 degenerati (2 .txt 0-byte + BETA FILM PDF image-only).
- Tool `scripts/batch_parse_capitolati.py` (bypass HTTP timeout).
- Root cause A24/IRDA "JSON malformato": `max_tokens=4000` truncava risposta Claude. Fix `deliverables_parser.py` 4000 → 8000.
- 13 DeliveryTemplate creati (id 2-14, conf media 0.79) via parser legacy 8-block JSON.

**Big rearchitecture delivery taxonomy Tier 1+2** (α.172.113 → α.172.116)
- Brainstorm con Matteo: DCP/IMF = packages, MXF = container, J2K = codec (Wikipedia sources verified).
- Indagine audio 6 fonti: stems DME, EBU R128, ATSC A/85, Atmos, surround channel configs, loudness normalization. Multi-dim: Content × Channels × Mix Standard.
- Indagine video 6 fonti: aspect ratio cinema, frame rates NTSC/PAL/HFR, DCI 2K/4K containers, UHD-1/2, HDR formats, chroma subsampling.
- Modello finale: 9 taxonomy entities + DeliveryItem + AudioTrackSpec M2M.

**Tier 1**: schema 11 modelli + seed 135 record sistema (Wikipedia/SMPTE/Davinci) + parser AI 2-pass (extract vocab → map FK). Smoke MUBI 25 items conf 0.88 media.

**Tier 2**:
- 2.1 router REST CRUD DeliveryItem + AudioTrackSpec + taxonomy lookup
- 2.2 UI tab Items in modal /delivery-templates con AI extract + editor inline
- 2.3 pagina /settings/delivery-taxonomy admin CRUD 9 entity + import/export JSON
- 2.4 batch re-parse 13 templates in run (3/13 fatti al momento interruzione, 62 items in DB)
- 2.5 JobDeliverable.delivery_item_id FK + UI cascading template→item in job_detail.html con auto-fill specs

**Fix collaterali**:
- Encoding char α in print auto-migrate (cp1252 fail su Windows console) → replace `α172` → `a172`.

**Punto interruzione**: batch Tier 2.4 in run background, server :8000 e tunnel cloudflared up.
Riprende stasera da locale.

[[reference_capitolati_corpus]] [[project_dialogo_cliente]] [[project_session_28mag2026]]
