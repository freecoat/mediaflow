---
name: project_session_30mag2026_multiaudit
description: "Sessione 30 mag 2026 — multiaudit + fix batch A→E + export capitolati + audit UI + test estensivo finance + fix note Matteo. α.172.142→146, 6 commit PUSHATI. Ripresa 31 mag."
metadata: 
  node_type: memory
  type: project
  originSessionId: b95ac460-4054-4049-aff2-cebd5bf5594a
---

Sessione lunga 30 mag 2026. Tutto **PUSHATO** (origin/main = e28e455, allineato; inclusi anche i 3 commit pre-sessione 906e25e/a463f1f/181764f). 146/146 pytest.

**API leak**: Matteo decide NO rotazione ora (repo private, 1 collaboratore GitHub, $15 cap API). **Reset completo key in fase beta**. .env era stato committato (history origin/main) → key Anthropic/OpenAI/Tavily/SECRET_KEY/Fernet trapelate ma accesso limitato. Vedi [[feedback_env_untracked]].

**Workflow**: bg-isolation guard disattivato via `.claude/settings.local.json` `worktree.bgIsolation=none` (worktree fresh branchava da origin = indietro + no .env/.venv; Matteo lavora in-place su main).

## Commit della sessione (6, tutti pushati)
- **b87da18 α.172.142** multiaudit fix batch A→E: A igiene segreti (.env.backup del+gitignore) · B cross-tenant (3 endpoint cost_report gate+scoped, projects.create_project valida client_id+tenant_id, Project/Job.code+Quote.number UNIQUE composito, 6 indici FK, scripts/migrate_tenant_unique.py) · C config.assert_production_security() boot-guard · D invoice acconto Decimal HALF_UP, SDI 6-char PA, fx round, price_list None warning · E 21 test.
- **f841028 α.172.143** export/import capitolati ZIP + multiselect (/delivery-templates: export-zip?ids=, import-zip conflict→-IMP, checkbox+select-all) + audit UI Playwright (zero errori JS) + 4 fix UI (export double-fire→fetch+blob, login hint @mediaflow.it, /resources money IT, emittente ellipsis).
- **a544497 α.172.144** fix cosmetici: /jobs→redirect /cost-report, titolo tab progetto, /favicon.ico→redirect SVG.
- **a852b1e α.172.145** fix numerazione quote: base-collision (contatore NumberingConfig disallineato + check solo stringa esatta) → dedup sul BASE + scan autoritativo. Trovato in test estensivo finance (flusso A-G verificato: P.IVA 422, quote 3350→IVA737→4087, job auto, cost report Quotato 3350, acconto 1005→IVA221.10→1226.10 Decimal, SDI XML FatturaPA valido).
- **e28e455 α.172.146** fix note Matteo (analisi quotazioni + copilot): vedi sotto.

## Note Matteo risolte (α.172.146) — verificate LIVE su capitolati reali
Picker capitolato: Bug1 detail riga eredita da PriceItem.description · Bug2 `template_bucket_options` detail_suggestion ricco (specs+nomi+note, era solo note→vuoto; 21/21 bucket Fremantle ok) · Bug3a dedup per (voce+capitolato) non solo price_item_id (pid 58 da Fremantle+Vision = 2 righe) · Bug3b `section_label`=broadcaster (Sky vs NBCU non confondibili).
Copilot: truncation max_tokens 2000/4000→8000 · `_coerce_price` robusto + reject id-like (`ai_assistant.py`) · `tavily_search` timeout+depth basic+errore visibile.

## Playwright MCP instabile
Si pianta (subagent E diretto). Per test funzionali → **pivot API/curl** (deterministico, vedo i numeri). Cookie login: admin@mediaflow.it/admin123 (303). Endpoint require auth anche in dev.

## RIPRESA 31 mag
1. **Matteo deve riavviare il SUO server** (fix copilot = cambi Python) e ri-testare la conversazione Gomorra col copilot (price_list + propose_quote 9 righe + web_search).
2. **Test estensivi rimanenti** del piano (pivot API): planning/pass-through OT, anomalie cascade, DAM/TPN, filmografia AI. Vedi [[project_test_plan_24mag2026]] (fasi 7-12).
3. **Debito audit non fixato** (post-60%, beta): rebuild UNIQUE composito su DB esistente (`migrate_tenant_unique.py --rebuild-unique`), datetime.utcnow ×110, gap TPN/DAM P1 (dam metadata no-auth-check, MFA upload/delete, secure-delete default, watermark non-image, uploaded_by spoof), `delivery_portals.py` orphan = feature roadmap da cablare.
4. DB di lavoro = snapshot pre-test ripristinato (10 quote, 10 fatture, 3 progetti, 14 template). Server test era su :8765 (fermato).
