---
name: project_session_31mag2026
description: "Sessione MARATONA 31 mag 2026 — TPN/DAM + utcnow + deliveries prezzi + turno + CONVERSIONE VALUTA + backlog 7 punti + MOBILE PWA v1 + mobile v2 Fase A. α.172.147→159, TUTTO PUSHATO (origin 8baa01e). Test Matteo 1 giugno."
metadata: 
  node_type: memory
  type: project
  originSessionId: 907399af-bd29-41f5-b11e-30ea15876521
---

## FINE GIORNATA 31 mag 2026 — stato finale
**TUTTO PUSHATO** (origin/main = `8baa01e`, ahead 0). Range **α.172.147 → α.172.159**. Tunnel+server di test spenti. Matteo testa l'1 giugno.
Arco giornata: (1) chiusura debito TPN/DAM P1 [.147] + test fasi 7-12 [.148] + sweep utcnow→now_utc [.149] + prezzi/reparti deliveries [.150] + unità turno/trn 3h [.151-.154] · (2) **CONVERSIONE VALUTA COMPLETA** [.155-.156] (base-anchored, 12 task subagent, verifica legale, vedi sotto) · (3) **BACKLOG 7 punti** [.157] (listino duplica/categorie/cancellazione, dettaglio AI, episodi serie, copilot new-conv, source-map; multiagent) · (4) **MOBILE PWA v1** [.158] (area /m staff) + **Fase A look/nav** [.159] (drawer + design system) — vedi [[project_mobile_port]].
**DA TESTARE (Matteo, 1 giu)**: restart :8000 (auto-migrate Invoice/Project/booking_assignments) → currency quote→fattura, backlog, turno; mobile via tunnel (ricreare: `tunnel.bat`/cloudflared → :9000 col codice nuovo, URL ephemeral nuovo). 290/290 pytest.
**PARCHEGGIATO**: colori/temi mobile, app nativa Capacitor/nav avanzata (Matteo "lascia stare per ora"). Prossimo sviluppo mobile: Fase B consultazione entità.
**Debito beta ancora aperto**: rebuild UNIQUE composito DB esistente · `/openapi.json`+`/docs` 500 (AssertionError "A response class is needed" — NON tocca app/route reali, solo dev-docs; route incriminata da trovare) · gap TPN/DAM minori · delivery_portals orphan.

---

Sessione 31 mag 2026. Ripresa da [[project_session_30mag2026_multiaudit]] punti 2 (test fasi 7-12) + 3 (debito audit beta). 3 commit **LOCALI non pushati** (Matteo ha scelto "tieni locale"). **161/161** pytest.

## Commit (3, NON pushati — HEAD locale 781346c, origin fermo a e28e455)
- **a83af70 α.172.147** — chiusura 5 gap audit TPN/DAM P1 (sicurezza, basso rischio). +12 test (`tests/test_dam_tpn_audit.py`).
  - #1 `get_asset_metadata`+`get_asset_delivery_info` (`dam.py`): erano solo tenant+exists → leak codec/res/delivery di asset altrui. Ora `user_can_access_asset()`+`request:Request`.
  - #2 MFA: `check_project_mfa_required` era solo download → esteso a upload+delete.
  - #3 secure-delete: `DELETE /dam/api/assets/{id}` ora `secure=1` default (DOD wipe), `?secure=0` opt-out.
  - #4 watermark: nuovo `dam_security.apply_watermark_pdf()` (PyMuPDF) + branch PDF in `download_asset`, forzato non-admin. Video/DCP fuori scope (gated+loggati).
  - #5 `uploaded_by` da utente autenticato (era `Form(...)` falsificabile); risolve TODO hardcoded `uploaded_by=1` in dam.html.
- **72bfc20 α.172.148** — verifica fasi 7-12 (API/curl, server :8770 su mediaflow.db snapshot) + 3 test regressione `tests/test_anomaly_reopen_cascade.py` (F10 cascade: LossEntry hard-delete, OverheadCost soft-delete, reopen-open noop — mancava copertura su invariante P&L double-count).
- **781346c α.172.149** — sweep `datetime.utcnow`→`now_utc`. Helper `app/services/clock.py` (`now_utc()=datetime.now(UTC).replace(tzinfo=None)`, naive, zero deps app→no cicli con models). 45 file (39 sweep `datetime.utcnow` + 6 alias locali `_dt/_dtm/_dt2.utcnow()`). Import via AST. Warning pytest 1362→15.
- **e10cf0d α.172.151** — nuova unità **"turno" = 3 ore** (generica, utile Suono). Source of truth `cost_line_sync.HOURS_PER_UNIT` + `hours_per_unit()` (turno/turni/trn/shift=3.0). `_qty_from_hours`/`is_time_based_unit`/`_UNIT_TO_NATURE` derivano dalla mappa. Dedup: `reverse_quote.compute_quantity_from_hours` + `cost_report` OT-pending usano `hours_per_unit()` (prima day/else hardcoded → turno=1h errato). UI dropdown+badge+price-convert JS (`HOURS_PER_UNIT_JS`) in /pricelist+/quotes. AI enum/validazione/docs. **Clash terminologico risolto**: copy usava "turno"=8h giornata → corretta "giornata" (pricelist tooltip + quotes "day (turno 8h)"). 27 test → 217/217. JS servito node --check OK. NB: aggiungere unità temporali = solo in HOURS_PER_UNIT (+ mirror JS HOURS_PER_UNIT_JS).
- **0243597 α.172.150** — reparti + prezzi 66 voci-bucket cat "Deliveries" (erano dept+prezzo None). Audio→Suono(3) 19, Video+Sottotitoli+altro(KDM/ISO/Document)→DI(1) 47. Prezzi media-IT 3 livelli (mastering/delivery fee, NON grading/mix): DCP 2K 1200/4K 1800, IMF 1500, MXF HD 450/UHD 700, MP4 180, ProRes 422 350/UHD 550/4444 750/XQ 900, ImgSeq 900, SD 250, Subtitle 120, KDM 80, ISO 150, Document 0; FullMix 600, stem 250, M&E 450, StemsBundle 700, OptAudio 350, DM&E 18/min. Script idempotente `scripts/migrate_deliveries_pricing.py` (riusabile dopo reset) + 29 test `classify()`. Snapshot `snapshot-3.5.0-alpha.172.149-pre-deliveries-pricing.db`. **DB live aggiornato** (mediaflow.db gitignored). 190/190.

## Esiti test fasi 7-12 (pivot API/curl, Playwright resta instabile)
- **F7 pass-through OT** ✓ `PUT /cost-report/api/job/{id}/weighted-revenue` toggle ON/OFF.
- **F10 anomaly cascade** ✓ logica corretta + ora coperta da test. Live N/A (0 anomalie sul DB, detect→0).
- **F11 HARD-BLOCK** ✓ schedule Σpct>100%→409 (`/quotes/api/{id}/advance-schedules`); AP>budget→409 (`/finance/api/projects/{id}/advances`, budget 44750 da quote approved). Msg con bullet/€.
- **F9 filmografia** pagina `/clients/{id}/works` 200; AI call = key Matteo (test live suo).
- **F8 cashflow Fandango** SKIP (no Fandango nel DB).
- Smoke 11 pagine: zero 500. `/anomalies` standalone 404 atteso (UI tab in `/finance`, router prefix `/finance`).
- DB lavoro senza residui (schedule creato+rimosso, weighted ripristinato, AP-block non crea).

## Stato DB lavoro (mediaflow.db)
3 progetti (1 Filmetto, 2 Filmone, 3 Gomorra), 2 job (1→proj1, 2→proj2, approved, 3 JCL each), 10 quote, 10 invoice, 2 AP su proj1 (id1 invoiced 14775, id2 draft 9850). Login curl admin@mediaflow.it/admin123 (303). Cookie jar logs/cookies_test.txt.

## Debito #3 ANCORA APERTO (scelta Matteo/beta)
- rebuild UNIQUE composito su DB esistente (`scripts/migrate_tenant_unique.py --rebuild-unique`).
- `app/services/delivery_portals.py` = service orphan (no router) → feature roadmap "automazione portali consegne" da cablare.

## CONVERSIONE VALUTA (α.172.155→156) — feature grossa subagent-driven, 13 commit LOCALI non pushati
Spec+piano in `docs/superpowers/` (2026-05-31-currency-conversion). Modello **base-anchored**: importi DB sempre in valuta base (EUR); conversione $/£/CHF **live indicativa** su quote + **congelata all'emissione fattura** (tasso BCE del giorno, art.13 c.4 DPR 633/72, verificato legalmente conforme). XML SDI sempre EUR (Divisa=EUR, imponibile da base). 12 task TDD via subagent (implementer + review a 2 stadi su integrazione). **255/255 test**. E2E: quote USD→tasso live 0.859→riga 1000 USD salvata 858.81 base ✅.
File chiave: `app/services/currency.py` (to_display/to_base/symbol/format_money/disclaimer/freeze_invoice_fx, SUPPORTED EUR/USD/GBP/CHF) · `fx.get_fx_rate_on` (BCE storico per-data) · quote `currency_block` payload + `from_listino` (anti double-convert) · `mfFormatMoney` in global.js · Invoice +3 colonne (currency/fx_rate_to_base/fx_rate_fixed_at) + auto-migrate boot · NC copia tasso originale.
Decisioni: tasso quote=live non congelato; fattura=congelato all'emissione; 5 siti invoice project-level default base EUR (valuta ambigua multi-quote, documentato). Disclaimer assume tenant IT, adattamento estero futuro (currency.disclaimer centralizzato).
**Restart :8000 OBBLIGATORIO** (Matteo) per attivare backend + auto-migrate Invoice. Server :8000 NON killabile dalla mia sessione (cross-session perms).

## BACKLOG MATTEO 31 mag (post-valuta, ancora da fare)
LISTINO: duplica voce · vista categorie troncata · cancellazione voci rotta (bug). QUOTE: dettaglio voci vuoto se via AI copilot (bug). PROGETTI: campo n° episodi se serie + leggibile da copilot ovunque. COPILOT: nuova conversazione mostra chat precedente (bug). MISC: source-map lucide.min.js.map 404 (innocuo).

## RIPRESA prossima
1. **PUSH** di TUTTI i commit locali (.147→.156) quando Matteo OK → ricordare ZIP export in docs/ prima ([[feedback_export_zip_at_push]]).
2. Test copilot Gomorra lato Matteo (fix α.146 live sul SUO server) — price_list + propose_quote 9 righe + web_search.
3. Eventuale cablaggio `delivery_portals.py` (feature) o rebuild UNIQUE (prereq beta).
