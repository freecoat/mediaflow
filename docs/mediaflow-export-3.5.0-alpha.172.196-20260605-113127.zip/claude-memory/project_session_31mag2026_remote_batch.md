---
name: project_session_31mag2026_remote_batch
description: "α.172.160 batch remote-control 5 fix (listino/picker/deliverables), commit e423e1e NON pushato"
metadata: 
  node_type: memory
  type: project
  originSessionId: 3df3f868-f367-46e7-b1e0-3011becc99aa
---

Sessione 31 mag 2026 sera (remote-control). Chiusa **α.172.160**, commit `e423e1e` locale **NON pushato** (policy: locale=solo major bump). 5 issue remote-control, tutti testati (boot 200, endpoint girati, force-delete funzionale):

1. **Episodi serie AI**: il campo `episodes_count` esisteva già end-to-end (model/form/display); mancava solo nel tool-schema AI → aggiunto a `propose_project` + `propose_project_metadata` (ai_tools.py + ai_assistant.py handler).
2. **Cancella categoria listino**: era bloccato (400) se voci collegate. Ora **force-delete soft**: nuova colonna `price_categories.is_active` (+ auto-migrate main.py), `delete_category` disattiva categoria + voci (`is_active=False`, recuperabili). Evita cascade all,delete-orphan che romperebbe QuoteLine. Vedi [[feedback_soft_delete_unique_bypass]].
3. **Viz categorie**: Matteo "metti filtri sopra / togli sidecar" → rimossa sidebar, categorie come **chips filtro sopra la tabella** (pricelist.html `renderCats` → chips).
4. **Picker capitolato sconto %**: listino prezzi FISSI. Tolto dropdown fasce list/media/basso, messo input **% sconto** con preview live (barrato→scontato). Backend `load-from-template-items`: `price_level`→`discount_pct`, salva in `line_discount_pct` (recalc già applica). Vedi [[feedback_ai_schema_descriptions]].
5. **Deliverables /planning?view=deliverables**: Bug A = mostrava progetti cestinati → query `/jobs/api/deliverables/list` filtra `Project.deleted_at IS NULL`. Bug B = modal specifiche solo JSON 8-blocchi → ora se `delivery_item_id` set mostra **selettori taxonomy strutturati** (parità openItemEditor delivery_templates.html), salva `PUT /delivery-items/api/{id}`; serializer deliverable espone `delivery_item_id`. Fallback JSON se non linkato.

File toccati: models.py, main.py, pricelist.py, quotes.py, jobs.py, ai_tools.py, ai_assistant.py, pricelist.html, quotes.html, planning.html, CHANGELOG.md.

Test pendente Matteo browser (restart :8000): copilot crea serie→episodi compilati; elimina categoria con voci; sconto% picker live; deliverables no-cestinati + modal specs capitolato.
