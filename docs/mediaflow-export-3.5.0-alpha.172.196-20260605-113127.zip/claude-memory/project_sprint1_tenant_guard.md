---
name: project-sprint1-tenant-guard
description: "Sprint 1 audit chiuso α.172.35 — tenant_guard.py centralizza scope check, 23 fix in 4 router, 2 endpoint deprecati rimossi"
metadata: 
  node_type: memory
  type: project
  originSessionId: 6aa8c5c6-b1fb-4f0a-bebe-9271e39fc1eb
---

α.172.35 (23 mag 2026) chiude BLOCCO 1 audit multi-agent: cross-tenant data leak.

**Architettura nuova**: `app/services/tenant_guard.py` con:
- `scoped(query, Model)` applica `tenant_id == current_tenant_id()` automaticamente
- `fetch_or_404(db, Model, id)` generic by-ID + scope + 404 uniforme
- `fetch_invoice_or_404(db, id)` specializzato (Invoice scope via Client JOIN — no tenant_id diretto)
- `_INDIRECT_VIA_CLIENT = {Invoice}` set per modelli con scope indiretto
- Solleva `RuntimeError` se Model nuovo non ha strategia (no leak silente futuro)

**Why**: 23 query erano vulnerabili a enumeration cross-tenant. Multi-tenant SOFT compromesso. Helper riusabile invece di patch puntuali = future query nuove automaticamente protette.

**How to apply**: per nuovo router/endpoint by-ID, usa `fetch_or_404(db, Model, id)` invece del pattern `db.query(Model).filter(Model.id == x).first()`. Per query con filtri custom, usa `scoped(db.query(Model)..., Model).filter(...).all()`.

**Endpoint rimossi** (avevano bug + erano deprecated):
- `POST /planning/api/clients` (creava Client senza `tenant_id`)
- `POST /planning/api/jobs` (creava Job senza `tenant_id` + check unicità code cross-tenant)

**Permesso nuovo RBAC**: `edit_cost_lines` (Finanza). Gate su `cost_report.py:update_cost_line`. Modifica campi forecast/notes/external_outsourced JCL. Quantity_actual/total_accrued restano lock dai booking (derivati da cost_line_sync).

Vedi [[project-session-23mag2026-sprint1]] per sessione completa con report consolidato 131 finding / 37 P0.
