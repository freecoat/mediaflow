---
name: project-sprint2-slice-lock-symmetric
description: Sprint 2 audit chiuso α.172.36 — slice-lock simmetrico (JCL-driven API) + 3 endpoint UI 404 fix
metadata: 
  node_type: memory
  type: project
  originSessionId: 6aa8c5c6-b1fb-4f0a-bebe-9271e39fc1eb
---

α.172.36 (23 mag 2026) chiude BLOCCO 2 + BLOCCO 3 audit multi-agent.

**BLOCCO 2 — Slice-lock asimmetrico**: planning/AI lato già chiamavano `assert_slice_lock_safe(booking)` ma `quotes.py` modificava direttamente i campi della JCL senza guard. Una JCL già fatturata poteva essere rinominata/riprezzata/cancellata silenziosamente dal lato Quote → divergenza fra JCL e snapshot fattura emessa.

**Nuova API in `app/services/billing_slice_guard.py`** (JCL-driven, complementare a booking-driven esistente):
- `find_any_active_slice_for_jcl(db, jcl_id)` — slice non-voided più antica, NO filtro periodo
- `jcl_lock_message(slice_, action)` — messaggio IT uniforme
- `assert_jcl_lock_safe(db, jcl_id, action="modificare")` — HTTPException 409 con `{message, lock: {slice_id, period_start, period_end, invoice_id, invoice_number, billed_amount}}` riusabile dalla modale UI rettifica

**Why**: esistenza di slice attiva (anche solo una) blocca STRUTTURALMENTE la JCL, indipendente dal periodo. Differente da booking-driven dove il periodo del booking deve sovrapporsi a quello della slice.

**How to apply**: chiamare `assert_jcl_lock_safe(db, jcl.id, action="<verbo IT>")` PRIMA di:
- UPDATE su `description`, `unit`, `unit_price`, `quantity_quoted`, `total_quoted`
- `db.delete(jcl)`
- Rebind `quote_line_id` durante versioning quote

NON serve per campi soft (notes, total_expected, external_outsourced) — vedi `cost_report.update_cost_line`.

**4 callsite patchati in quotes.py**:
- `update_quote_line` (1645+)
- `delete_quote_line` (1840)
- `batch_delete_quote_lines` (2028)
- `migrate_job` versioning re-bind (3105)

**BLOCCO 3 — UI 404 fix**:
- `project_detail.html:1283-1285` chiamava `/dam/api/delivery-templates` + fallback `/api/delivery-templates` (entrambi inesistenti) → corretto `/delivery-templates/api/list`. Tech-sheet template select restava vuoto silenziosamente.
- `job_detail.html:1011` chiamava `/resources/api/list` (inesistente) → corretto `/resources/api`. Dropdown risorse del modal "Nuova consegna" restava vuoto.

Cross-ref audit (Agent 4) ha identificato entrambi. Bug class: doppio `try/catch(e) {}` a vuoto + select vuota = bug silente sintomatico ma non diagnosticato.

Vedi [[project-session-23mag2026-sprint1]] per overview audit + roadmap completa 5 sprint.
