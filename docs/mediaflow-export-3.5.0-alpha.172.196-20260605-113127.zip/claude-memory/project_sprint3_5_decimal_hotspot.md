---
name: project-sprint3-5-decimal-hotspot
description: Sprint 3.5 chiuso α.172.38 — Decimal solo in invoice_totals hotspot. Big Float→Numeric migration rinviato a Postgres porting (opzione C)
metadata: 
  node_type: memory
  type: project
  originSessionId: 6aa8c5c6-b1fb-4f0a-bebe-9271e39fc1eb
---

α.172.38 (23 mag 2026) chiude BLOCCO 4 audit (Float vs Numeric).

**Decisione architetturale (opzione C)**: 
- SQLite stores REAL nativamente = float64 IEEE 754, ~15 cifre significative
- Scale MediaFlow (centinaia di righe/fattura, non milioni) non soffre errori float
- Migrazione full ~70 campi Float → Numeric(15,2) = high-risk, basso ROI ora
- Rinviata a porting Postgres futuro: lì si converte in blocco con type adapter SQLAlchemy che restituisce Decimal nativo, eliminando indirezione

**Sprint 3.5 minimale**: Decimal SOLO nell'hotspot di aggregazione critica.

**Nuovo `app/services/money.py`**:
- `to_decimal(value)` — float/str/None → Decimal stabile (str() repr per evitare binary float)
- `money_round(d)` — quantize 2 dec HALF_UP (convenzione SDI/fiscale)
- `money_to_float(d)` — Decimal → float per persistenza Float legacy
- HALF_UP NON banker's HALF_EVEN: SDI/FatturaPA usa HALF_UP standard

**`invoice_totals.compute_invoice_totals_from_lines` refactored**:
- Subtotal/vat_amount/total/by_rate calcolati come Decimal interni
- Boundary output: `float(money_round(d))` per back-compat
- Garantisce Σ(round(x, 2)) ≡ round(Σ(x), 2) anche su 200+ righe
- Bucket per-rate usa Decimal come chiave per stabilità

**Why qui e basta**: invoice_totals è il punto dove convergono N InvoiceLine in subtotal+vat+total. È il SOLO posto realistico dove la deriva centesimi può manifestarsi. Tutti gli altri calcoli monetari (cost_line_sync recompute, booking_cost breakdown, ecc) lavorano su importi singoli o piccoli aggregati < 10 righe — float è OK.

**How to apply**: per nuovi punti che aggregano > 50 importi monetari, usare pattern `to_decimal → ops → money_round → float`. Per single-value ops, float resta accettabile.

**Roadmap Postgres**: a porting:
1. Cambiare colonne Float → Numeric(15, 2) su ~70 campi monetari (Quote/Invoice/JCL/Booking/Resource/...)
2. SQLAlchemy ORM restituisce Decimal direttamente
3. Rimuovere indirezione in money.py — solo helper di rounding HALF_UP resta utile
4. Trigger DB-level CHECK constraints per rounding consistency

Vedi [[project-sprint3-finance-invariants]] per il resto del BLOCCO 4.
