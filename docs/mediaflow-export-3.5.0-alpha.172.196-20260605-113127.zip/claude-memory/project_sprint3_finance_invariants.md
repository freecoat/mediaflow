---
name: project-sprint3-finance-invariants
description: "Sprint 3 audit chiuso α.172.37 — finance domain BLOCCO 4: weighted_revenue funzionante + anomaly cascade + overtime brackets unify + IVA per-riga + Invoice.tenant_id"
metadata: 
  node_type: memory
  type: project
  originSessionId: 6aa8c5c6-b1fb-4f0a-bebe-9271e39fc1eb
---

α.172.37 (23 mag 2026) chiude BLOCCO 4 audit multi-agent. 5 bug finance critici corretti.

**3.A — `weighted_revenue` ora funziona**: `cost_line_sync.recompute_cost_line_actual` ora applica `_booking_hours_weighted` (CCNL brackets + multiplier) quando `Job.weighted_revenue=True`. Pre-α.172.37 era DEAD CODE: il flag esisteva, l'API lo accettava, ma il calcolo lo ignorava → pass-through OT al cliente non funzionante. Vedi [[project-pass-through-ot]] per perché Matteo "non vedeva differenza".

**3.B — Anomaly reopen cascade**: cleanup automatico del target (LossEntry hard-delete / OverheadCost soft-delete) al reopen. Previene P&L double-count su re-handle. Audit trail in `entry.notes`.

**3.C — Overtime brackets unify**: `overtime.py` ora importa `_weighted_overtime_with_brackets` da `booking_cost.py`. Pre-α.172.37 HR e CR avevano due fonti di verità divergenti su CCNL con scaglioni (Cinema Doppiaggio prime 2h +30% poi +60%).

**3.D — IVA per-riga** (nuovo `app/services/invoice_totals.py`):
- `compute_invoice_totals_from_lines(lines)` → `{subtotal, vat_amount, total, by_rate}`
- `apply_totals_to_invoice(invoice, totals)` setta subtotal/total
- `by_rate` array `[{rate, subtotal, vat_amount, lines}]` riusabile da emissione FatturaPA `<DatiRiepilogo>` Sprint 5
- 3 callsite: `billing.emit_invoice`, `billing.compose_invoice_from_batches`, `finance.add_invoice_line`
- Bonus: fix P1 audit `subtotal += total` rompeva su `subtotal=None`

**3.E — `Invoice.tenant_id` denormalizzato**:
- Colonna nuova FK tenants(id), default=1
- `__table_args__ = (UniqueConstraint("tenant_id", "number"),)` 
- `_auto_migrate_columns()` in `app/main.py` lifespan: ALTER TABLE + backfill da `Client.tenant_id` + UNIQUE INDEX composto + INDEX
- 7 callsite `Invoice(...)` (billing.py + finance.py) ora settano `tenant_id=current_tenant_id()`
- `tenant_guard._INDIRECT_VIA_CLIENT` ora vuoto: Invoice scope diretto (no JOIN Client, più veloce)

**Caveat α.172.37**: il vecchio `UNIQUE(number)` globale sopravvive sui DB pre-α.172.37 (SQLite non drop facilmente). Convive col composito. Single-tenant: nessun impatto. Multi-tenant HARD richiede rebuild table → Sprint 5 roadmap.

**Why questi 5 finding sono prioritari**: tutti P0 dell'audit multi-agent BLOCCO 4. weighted_revenue era una feature dichiarata muta — Matteo notava da settimane. Gli altri 4 erano latent bug che si attivano in scenari edge ma compromettono integrità finanziaria.

Vedi [[project-session-23mag2026-sprint1]] per audit overview + [[project-sprint1-tenant-guard]] + [[project-sprint2-slice-lock-symmetric]] per sprint precedenti.
