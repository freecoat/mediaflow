---
name: project-sprint4-ui-antipattern
description: "Sprint 4 audit chiuso α.172.39 — BLOCCO 5 UI antipattern: helper shadow + JSON.stringify onclick + setSelection wrapper + stack light-mode + escapeHtml hotspots + cache-buster automatico"
metadata: 
  node_type: memory
  type: project
  originSessionId: 6aa8c5c6-b1fb-4f0a-bebe-9271e39fc1eb
---

α.172.39 (23 mag 2026) chiude BLOCCO 5 audit. 6 categorie antipattern UI/JS che ripetutamente causavano bug silenti.

**4.A — Helper shadow rimossi** (memo `feedback_global_helpers_centralizzati`):
- `pricelist.fmtCurrency`, `hr.fmtDate`, `fs_scan.fmtSize` → rimossi, uso `global.js` versioni canoniche
- `global.js fmtSize` esteso a supporto GB+ (binary 1024^N)

**4.B — JSON.stringify in onclick (4 spot)** — pattern silently-broken con quote/apice/HTML in dati:
- `dam.html` cache `_assetsById` Map + onclick `id` (no più object serialization)
- `notifications.html` link via `data-link` DOM attr
- `cost_report.html` look-up in `currentReport.cost_lines`
- `finance.html` look-up in `_currentBatch.lines`
- Handler accettano id (nuovo) O object (back-compat)

**4.C — `setSelection` wrapper bypass** (memo `feedback_vis_timeline_quirks`):
- 8 spot planning.html sostituiti `window._tlInstance.setSelection(ids)` → `_tlSetSel(ids)`
- `_tlSetSel` wrapper fa fire dell'evento `select` necessario per Bulk button + counter
- 1 spot recursion-guard (line 5410) lasciato diretto

**4.D — `stack:true` light-mode toggle** (`planning.html:1770`):
- Legge `localStorage.mf_tl_light='1'` → `stack: false` per scalabilità
- Memo: dataset >1500 item su Mac Chrome freezava (O(N²))

**4.E — `escapeHtml` su `${var}` in innerHTML** (XSS audit):
- Top 4 template patched: dashboard, projects, project_detail, clients
- Pattern: `escapeHtml(j.code || '')` etc su tutti i campi user-supplied
- Backlog lower-risk (pricelist/cost_report descrizioni/finance options/planning title attrs) → Sprint 5

**4.F — Cache-buster automatico via `app_version` Jinja global**:
- `templates.env.globals["app_version"] = app.version` in main.py post Jinja init
- 11 ref static `?v=hardcoded` → `?v={{ app_version }}` (base.html, copilot, login, planning, tech_sheet_public_edit, portal_base)
- Bump `app.version` = invalida TUTTI gli static automaticamente
- Memo `feedback_cache_buster_static`: era violato a α.172.34 (base.html main.css?v=α.172.16 vs file modificato a α.133)

**How to apply future**: per nuovi `${var}` in `innerHTML`, sempre `escapeHtml()` su user-supplied. Per nuovi static, mai hardcoded `?v=`, sempre `{{ app_version }}`. Per click handler con oggetti, mai JSON.stringify in onclick: usa data-* attribute O cache map by id.

Vedi [[project-session-23mag2026-sprint1]] per overview audit + sprint precedenti.
