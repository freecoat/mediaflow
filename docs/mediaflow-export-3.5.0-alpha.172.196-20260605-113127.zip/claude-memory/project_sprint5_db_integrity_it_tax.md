---
name: project-sprint5-db-integrity-it-tax
description: "Sprint 5 audit chiuso α.172.40 — BLOCCO 6 parte 1: immutability event listener + tenant_id FK + INDEX hot-path + italian_tax foundation + JSON validators"
metadata: 
  node_type: memory
  type: project
  originSessionId: 6aa8c5c6-b1fb-4f0a-bebe-9271e39fc1eb
---

α.172.40 (23 mag 2026) chiude BLOCCO 6 parte sicura. 6 sub-fix integrity DB + foundation IT tax compliance.

**5.A — JCLBilledSlice immutability event listener** (`app/services/billing_slice_immutability.py`):
SQLAlchemy `before_update` model-level che blocca UPDATE su slice eccetto storno (`voided_at`/`voided_by_invoice_id`). Defense-in-depth: oltre i guard router-level (`assert_slice_lock_safe` booking-driven + `assert_jcl_lock_safe` quote-side Sprint 2), qualsiasi ORM write da script/batch/AI futuro = `ValueError`. Idempotente al boot via `register_immutability_listener()`.

**5.B — 4 modelli `tenant_id` → ForeignKey**: Holiday, Notification, ProjectTechSheet, TechSheetFieldOption. Erano bare `Integer`. Caveat SQLite: ALTER COLUMN ADD CONSTRAINT not supported; integrity ora a livello ORM. Postgres porting applicherà constraint reale.

**5.C — Tag + FXRate tenant_id**: erano globali (leak reali). Aggiunta colonna + UNIQUE composito (Tag: name+tenant, FX: pair+tenant). Auto-migrate ALTER TABLE + CREATE UNIQUE INDEX. Old `UNIQUE(name)` Tag sopravvive su DB esistenti (rebuild → Sprint 6).

**5.D — INDEX FK hot-path (14 spot)**: projects.client_id, quotes.project/client_id, quote_lines.quote/price_item_id, jobs.project/client_id, job_cost_lines.job/quote_line/price_item_id, invoices.client/job/quote_id, invoice_lines.invoice_id. `index=True` su model + `CREATE INDEX IF NOT EXISTS` auto-migrate.

**5.E — `app/services/italian_tax.py` (foundation, wire-up router → Sprint 6)**:
- `validate_partita_iva` Luhn mod-10 (testato su RAI 06382641006)
- `validate_codice_fiscale` 16 alfanum PF / 11 cifre PG
- `validate_sdi_code` 7 alfanum o 0000000/999999
- `validate_iban_it` mod-97 ISO 13616
- `validate_regime_fiscale` RF01-RF19 (18 codici)
- `validate_tipo_documento` TD01-TD28 (19 codici)
- `validate_natura_iva` N1-N7.x (18 codici)
- `map_invoice_kind_to_tipo_documento(kind, is_credit_note)` — advance→TD02, credit→TD04, default→TD01
- `invoice_sdi_compliance_check(...)` — pre-emit, ritorna lista errori bloccanti
- Constants: REGIME_FISCALE_CODES/LABELS, TIPO_DOCUMENTO_CODES/LABELS, NATURA_IVA_CODES

Smoke test passati: 5 categorie validators + compliance check con 5 errori detected.

**5.F — JSON validators** SQLAlchemy `@validates` decorator (save-time validation, ValueError invece di corruzione silente):
- `Role.permissions` — list of str
- `WorkingHoursPolicy.overtime_brackets` — list of dict con from_hour+multiplier numerici
- `Tenant.asset_numbering_config` — dict

**Why**: integrity DB era frammentata. Audit BLOCCO 6 identificava 60+ finding qui — selezionato sub-set sicuro/quick wins. Parte rischiosa (FK ondelete table-rebuild + FatturaPA XML + UI backlog) → Sprint 6 (finale).

**How to apply**: per nuovi modelli con JSON, sempre `@validates` con check shape. Per nuovi monetary/financial models, considera event listener `before_update` per immutability post-billing. Per validation P.IVA/CF/SDI: importa `from app.services.italian_tax import ...`.

Vedi [[project-session-23mag2026-sprint1]] per overview audit + sprint precedenti.
