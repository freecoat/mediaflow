---
name: project-sprint6-sdi-compliance
description: Sprint 6 FINALE audit chiuso α.172.41 — italian_tax wire-up router + FatturaPA XML builder + UI backlog cleanup. Audit multi-agent 100% chiuso.
metadata: 
  node_type: memory
  type: project
  originSessionId: 6aa8c5c6-b1fb-4f0a-bebe-9271e39fc1eb
---

α.172.41 (23 mag 2026) chiude audit multi-agent al 100%. Sprint 6 finalizza BLOCCO 6 parte 2.

**6.A — italian_tax wire-up nei router**:
- `clients.py POST/PUT`: nuovo helper `_validate_fiscal_fields()` → 422 su vat/tax/sdi/iban invalidi
- `billing.emit_invoice`: pre-emit HARD-BLOCK via `invoice_sdi_compliance_check()` — solleva 422 con `{message, errors, hint}` se manca P.IVA cliente, SDI/PEC, regime fiscale tenant, o natura su vat_rate=0
- I validatori italiani non sono più dead code

**6.B — FatturaPA v1.6.1 XML builder** (nuovo `app/services/sdi_xml.py`):
Self-contained Python via `xml.etree.ElementTree`. No deps esterne (no xmlschema). Pattern:
- `build_fattura_xml(invoice, tenant) → (xml_str, filename)`
- Header FPR12 completo (DatiTrasmissione + Cedente + Cessionario da snapshot Invoice)
- Body con DettaglioLinee per InvoiceLine + DatiRiepilogo aggregato per aliquota + DatiPagamento con IBAN
- `_map_payment_method`: free-text → MP01-MP23
- Money via `Decimal` (money_round HALF_UP) per precisione SDI
- Filename SDI convention `IT{piva}_{progressivo}.xml` (Base32 Crockford 5 char da invoice.id+year)

Endpoint nuovo `GET /finance/api/invoices/{id}/sdi-xml` (`RequireEditInvoices`). Download XML per upload manuale al portale SDI. Trasmissione automatica + firma digitale rimandata a S8.x.

**6.C — UI backlog escapeHtml lower-risk** (5 spot):
- pricelist.html category/name/description
- cost_report.html description/category
- dam.html upload filename

**Audit overview finale**:
- Iniziato: 23 mag 2026 morning, 5 agent paralleli, 131 finding (37 P0)
- Chiuso: 23 mag 2026 sera, 7 commit α.172.35 → α.172.41
- Linee modificate: +2280/-260 (stima cumulativa)
- File nuovi: tenant_guard.py, billing_slice_immutability.py, italian_tax.py, invoice_totals.py, money.py, sdi_xml.py (6 helper services)
- Endpoint nuovo: /finance/api/invoices/{id}/sdi-xml

**Stato BLOCCHI**:
- ✅ BLOCCO 1 tenant scope (α.172.35)
- ✅ BLOCCO 2 slice-lock symmetric (α.172.36)
- ✅ BLOCCO 3 UI 404 endpoint (α.172.36)
- ✅ BLOCCO 4 finance invariants + Decimal hotspot (α.172.37+38)
- ✅ BLOCCO 5 UI antipattern (α.172.39)
- ✅ BLOCCO 6 DB integrity + IT compliance (α.172.40+41)

**Backlog NON eseguito (richiede backup utente)**:
- FK ondelete table rebuild SQLite (Project/Job/Tenant/Client refs)
- UNIQUE legacy rebuild (Tag.name, Invoice.number, Asset filename)
- Trasmissione automatica SDI (firma digitale + accreditamento)
- Wire-up _validate_fiscal_fields su Supplier/Tenant edit
- UI bottone "Genera XML SDI" in /finance tab Fatture

**Why ferma qui**: ROI bassi ulteriori vs rischio table-rebuild SQLite + scope feature-creep. Test utente intensivo PRIMA di proseguire.

Vedi [[project-session-23mag2026-sprint1]] per overview audit + [[project-sprint1-tenant-guard]] + [[project-sprint2-slice-lock-symmetric]] + [[project-sprint3-finance-invariants]] + [[project-sprint3-5-decimal-hotspot]] + [[project-sprint4-ui-antipattern]] + [[project-sprint5-db-integrity-it-tax]] per sprint precedenti.
