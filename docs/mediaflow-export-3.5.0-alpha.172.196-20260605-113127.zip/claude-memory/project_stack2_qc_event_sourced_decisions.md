---
name: project-stack2-qc-event-sourced-decisions
description: Decisioni architetturali Stack 2 QC event-sourced confermate da Matteo 27 mag 2026 prima di scrivere codice
metadata: 
  node_type: memory
  type: project
  originSessionId: 0f2a46f6-6d3a-46d5-8fe3-523b706730d6
---

Bundle L Stack 2 = QC event-sourced. Decisioni confermate 27 mag 2026.

**A. Granularità evento** → **per-Asset** (opzione 1).
- NON per-deliverable, NON per-section.
- `QCEvent.asset_id` FK obbligatoria, deliverable_id derivato join.
- Un deliverable con N asset ha N stream eventi paralleli, report aggregato.

**B. Event types append-only** OK come proposto:
- `qc.created`, `qc.section_checked` (pass/fail + measured_value + tolerance_used), `qc.note`, `qc.artifact_attached` (xlsx/PDF), `qc.signed_off`, `qc.reopened`, `qc.report_overridden`.
- Nessun DELETE. Ribaltamento solo via `qc.reopened`.

**C. Replay vs materializzazione** → snapshot denormalizzato OK.
- `QCReport` snapshot table, rigenerato sync su nuovo evento (event handler).
- Snapshot = cache, fonte verità = `QCEvent` append-only.
- Endpoint debug `/qc/api/reports/{id}/rebuild` per ricostruire from scratch.

**D. Integration Bundle I esistente** → da spiegare a Matteo prima di partire.
- Bundle I (α.172.89) ha: `JobDeliverable.qc_substatus` enum + `qc_report_pdf` path + `qc_cascade.py` service.
- Punto: Stack 2 non sostituisce Bundle I, lo **alimenta**. QC event diventa fonte, qc_substatus diventa derivato dallo snapshot.

**Why**: append-only history = audit forense post-consegna, replay = stato a qualsiasi istante, integration = back-compat zero rotture su Planning/Jobs/DAM Bundle I.

**How to apply**: scrivere `QCEvent` + `QCReport` modelli prima, poi service `qc_event_emitter.py` con sync snapshot rebuild, poi router `/qc/api/events/*`, poi integrare emitter in qc_cascade esistente. NO touch UI Bundle I fino a Stack 4.
