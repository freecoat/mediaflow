---
name: project_tb_ammontare_rendicontativo
description: TB/GB su quote = ammontare rendicontativo NON deliverable. Conteggio preciso solo per LTO oggi. Roadmap bridge MediaShuttle/Aspera/Yoyotta per transfer monitoring automatico.
metadata: 
  node_type: memory
  type: project
  originSessionId: b0f8a20b-e4f6-4c44-a1b9-6b146786f71d
---

**Fact**: in quote, le unità TB/GB (DeliverableUnitNature=`deliverable_volume`) sono **untità rendicontative di volume dati trasferiti** — NON sono deliverable nel senso "consegna spedita". Rappresentano ammontare dati che attraversa LTO, HDD, link Digidelivery.

**Why**: post-prod fattura il volume dati come metrica, ma il "deliverable" vero è la lavorazione (es. backup LTO 12 TB = 1 servizio con 12 TB di payload, non 12 deliverable). Conteggio preciso oggi solo per LTO (Yoyotta scrive verified bytes). Per HDD/MediaShuttle/Aspera oggi è stima manuale.

**How to apply**:
- `deliverable_volume` spawna **1 sola row aggregata** con `quantity_planned = qty quote` (es. 10 TB → 1 JobDeliverable qty=10). NON spawn-per-unit (sarebbe assurdo: 12 row TB).
- `deliverable_qty` (pc/lot/shot/version) spawna N row qty=1 (consegne discrete vere — 3 DCP = 3 row separabili).
- Cambio unit volume↔qty richiede respawn artifacts (α.172.99 `_respawn_line_artifacts` in quotes.py).

**Roadmap futura — Transfer monitoring bridge** (post Bundle L):
- Ingest MHL Yoyotta → auto-update `quantity_delivered` su deliverable LTO (già abbozzato in [[project_session_27mag2026_bundle_l_stack1]]).
- Connettore MediaShuttle/Aspera → poll API trasferimenti → match progetto/cliente → propose_quantity_delivered.
- Filesystem scanner (samba/SMB share monitor o LSP filesystem watcher) → conteggio byte trasferiti su path consegne.

Vedi anche: [[project_session_27mag2026_bundle_l_stack1]] (Bundle L Stack 1 = MHL parser + JobDeliverable.unit_nature).
