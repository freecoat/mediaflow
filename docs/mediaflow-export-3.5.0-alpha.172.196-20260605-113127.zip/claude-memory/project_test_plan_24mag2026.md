---
name: project-test-plan-24mag2026
description: "Test plan dettagliato step-by-step da svolgere insieme alla riapertura 24 mag 2026. Versione α.172.50. Punto di partenza Matteo: quotazione + 2 acconti creati."
metadata: 
  node_type: memory
  type: project
  originSessionId: 6aa8c5c6-b1fb-4f0a-bebe-9271e39fc1eb
---

**Punto di partenza Matteo (sera 23 mag, prima di chiudere)**:
- DB pulito post business-purge α.172.43.1
- Restart server fatto
- Creata 1 quotazione + 2 acconti
- App version α.172.50 in codice (probabilmente server ha ancora versione precedente in memoria → restart richiesto a riapertura)

**Test plan domani — step-by-step.**

## FASE 0 — Setup riapertura

1. **Restart server uvicorn** (`Ctrl+C` poi rilancia)
   - Aspettativa boot: `_auto_migrate_columns` esegue (Tag/FXRate.tenant_id, 14 FK indexes, Invoice.tenant_id). DB già migrato → idempotente, no print
   - Verifica routes count: deve essere **514** (Sprint 6 + reset endpoint α.172.50)
   - Apri `/finance` → 200 OK (no più 500 del primo restart α.172.42)

2. **Hard refresh browser** (`Ctrl+Shift+R`) per pickup nuova versione cache-buster ?v=α.172.50

3. **Verifica versione visibile**: `View source` di una pagina → cerca `?v=3.5.0-alpha.172.50`. Se ancora vecchia → cache stale, retry Ctrl+F5.

## FASE 1 — Test reset acconto (α.172.50)

4. Vai `/finance` → tab **Acconti** (`advances-drafts`)
5. Click "Gestisci acconto" su uno dei 2 AP confermati/draft
6. Verifica:
   - **Banner blu in cima**: "💡 Come funziona l'allocazione" + spiegazione (4 righe)
   - **Bottone "⟲ Resetta a pending"** visibile (giallo, footer azione)
   - **Hint sotto bottoni**: "Bozza = modificabile · Confermato = pronto emit · Reset → libera"
7. Click "⟲ Resetta a pending" → dialog conferma → OK
8. Atteso: toast "↻ Acconto resettato a pending (era draft|confirmed)"
9. Refresh lista AP → vedi status `pending` su quel AP
10. Riapri "Gestisci acconto" → bottone reset NON più visibile (status=pending)

## FASE 2 — Test cross-AP overflow (α.172.49)

11. AP #1 (resettato a pending): apri "Gestisci acconto"
12. Allocazione: spunta tutte le JCL disponibili, applica preset "Riempimento sequenziale"
13. Conferma allocazioni (status → confirmed). Verifica Σ alloc = AP.amount
14. AP #2 (l'altro in draft/pending): apri "Gestisci acconto"
15. Tenta di allocare la STESSA JCL già allocata da AP #1
16. Atteso: **toastBlock rosso** 12s con messaggio:
    ```
    ⛔ Operazione bloccata
    La voce è già parzialmente allocata ad altri acconti.
    • Voce JCL #N: <descrizione>
    • Quotato totale: € X
    • Già allocato ad altri acconti: € Y
    • Disponibile residuo: € Z
    ...
    ```
17. Allocazione blocca al save Conferma → resta in stato precedente

## FASE 3 — Test emit fattura acconto

18. AP #1 (confirmed con alloc complete): apri "Gestisci acconto" → click "💶 Emetti fattura subito"
19. Modal Emit aperto → verifica:
    - **Banner VERDE**: "✓ N JCL allocate · Σ € X (vs AP € Y)"
    - Bottone Emit **abilitato**
20. Compila Data emissione + Scadenza + IVA 22%
21. Click "💶 Emetti fattura"
22. Atteso: toast success "✓ Fattura YYYY-NNNNN emessa (€ X totale)"
23. Vai tab Fatture → vedi nuova fattura status=draft, kind=advance, doc_type=TD01

## FASE 4 — Test cascade NC → AP draft (α.172.42)

24. Sulla fattura acconto emessa: prova a **cambiare stato** a `cancelled` (via UI status dropdown)
25. Atteso: AP collegato torna a `draft` (cascade nuovo). Verifica nel tab Acconti → AP #1 stato `draft`, invoice_id=None
26. Riapri "Gestisci acconto" → bottone reset di nuovo visibile

## FASE 5 — Test compliance SDI (α.172.41 + .42)

27. Vai `/clients` → "Nuovo cliente"
28. Verifica modal ha campi: P.IVA, Codice fiscale, **Codice SDI**, **PEC**, Indirizzo, CAP, Città, Prov., Paese (default IT)
29. Crea cliente "Test SRL" con:
    - P.IVA invalida (es. `12345`) → atteso 422 con errore "P.IVA non valida"
    - P.IVA valida (es. RAI `06382641006`) + SDI `M5UXCR1` + indirizzo
30. Crea progetto + quote per questo cliente
31. Approva quote → Job auto-creato
32. Tenta emit fattura batch per questo Job
33. Se P.IVA + SDI compilati → emit OK
34. Se mancanti → 422 con `errors[]` esplicito (`invoice_sdi_compliance_check`)

## FASE 6 — Test XML SDI download (α.172.41)

35. Dopo emit fattura ordinaria (non acconto), prendi invoice_id
36. Visita URL diretto: `http://localhost:8000/finance/api/invoices/<id>/sdi-xml`
37. Atteso: download file `ITXXXXXXXXXXX_NNNNN.xml`
38. Apri file → verifica XML conforme FatturaPA v1.6.1:
    - `<FatturaElettronica versione="FPR12">`
    - `<DatiTrasmissione>` con `IdTrasmittente` + `CodiceDestinatario`
    - `<CedentePrestatore>` (tenant)
    - `<CessionarioCommittente>` (cliente)
    - `<DatiGeneraliDocumento>` con `TipoDocumento` TD01
    - `<DettaglioLinee>` per ogni InvoiceLine
    - `<DatiRiepilogo>` aggregato per aliquota
    - `<DatiPagamento>` con IBAN

## FASE 7 — Test pass-through OT (α.172.37)

39. Vai `/cost-report?job=<id>` per il Job creato
40. Verifica toggle **"Pass-through OT"** (banner top con switch)
41. Default OFF. Click ON → conferma toast "✓ Pass-through OT attivato — N righe aggiornate"
42. Per testare effettivo: crea Booking con overtime + marca done → toggle ON → confronta `total_accrued` con/senza weighted (richiede orario night/holiday/overtime per vedere multiplier)

## FASE 8 — Test cashflow Fandango (α.172.42)

43. Vai `/finance/cashflow`
44. Apri filtro cliente → seleziona Fandango (se ancora presente — dopo purge DB potrebbe non esserci, skip)
45. Atteso: outstanding net = 0 (post-fix). Era 57.528 pre-fix.
46. Se DB era stato purgato: questo test richiede ricreazione 3 fatture cancellate Fandango → skip pure

## FASE 9 — Test filmografia AI (α.172.45)

47. Vai `/clients/<id>/works` per il cliente creato
48. Click "🔍 Ricerca AI"
49. Inserisci nome noto (es. "Cattleya srl" o "Wildside") + hint opzionale "filmografia 2020-2024"
50. Atteso: candidati con dettaglio ricco (cast, regista, finanziamenti, festival)
51. Seleziona alcuni → "Importa"
52. Apri opera importata → scheda dovrebbe mostrare:
    - Synopsis
    - Cast & Crew (regista, DOP, attori)
    - Finanziamenti (MIC, Eurimages, tax credit)
    - Release date
    - Festival premiere
    - Premi
    - Link esterni (IMDb, trailer, ecc)

## FASE 10 — Test anomaly reopen cascade (α.172.37)

53. Crea anomalia (es. delta consuntivo > quotato → anomaly auto-detect via emit_invoice path)
54. Handle anomaly con action `write_off_loss` o `overhead_cost`
55. Verifica LossEntry o OverheadCost creato in DB / UI
56. Click "Riapri anomalia"
57. Atteso: `entry.notes` aggiornato con `[reopen cleanup] LossEntry#X hard-deleted` o `OverheadCost#X soft-deleted`
58. Verifica record collegato sparito (LossEntry) o soft-deleted (OverheadCost)

## FASE 11 — Block test (toastBlock visivo)

59. **Test 30%+80% schedule** (α.172.47):
    - Apri quote modal → tab Acconti schedule
    - Crea schedule "30% acconto firma" pct=0.30
    - Tenta crea altra schedule "80% saldo" pct=0.80
    - Atteso: toastBlock rosso 12s con bullet points percentuali

60. **Test 2 AP > budget** (α.172.46):
    - In Project con 1 quote approved (budget X)
    - Crea AP manuale 90% di X via `/finance` form
    - Tenta crea altro AP 50% di X
    - Atteso: toastBlock rosso "La somma degli acconti supererebbe il budget..."

61. **Test cross-AP JCL overflow** (α.172.49) — già coperto in FASE 2

## FASE 12 — Bug noti aperti / da verificare

62. **JobDeliverable allocation in acconto**: 6 deliverable non visibili in modal. Decisione futura: aggiungere tab/modal Deliverable? Discutere durante test.

63. **UI filmografia rendering**: schede ClientWork potrebbero non renderizzare TUTTI i nuovi campi (synopsis/cast_crew/funding_public). Verifica visiva — se mancano, sprint UI dedicato.

64. **Cache-buster app_version** (α.172.39): cambia versione su un file static, bump main.py, verifica browser pickup. Già implementato — verifica funziona.

## Punto di ripresa 25 mag

- Versione corrente: **α.172.72** (24-25 mag maratona)
- Test FASE 0-4 chiusi 24 mag. **Riprendi da FASE 5 SDI compliance** (cliente + sede + REA + emit + XML download)
- Implementazioni aggiunte 24 mag da verificare:
  - α.172.51-53: reset hard acconto + cap cross-AP preset + HARD-BLOCK sotto-copertura
  - α.172.54-56: emit fattura download PDF auto via fetch+blob
  - α.172.57-58: post-emit no cancel diretto + naming convention NC TD04 auto
  - α.172.60: sede strutturata tenant + IscrizioneREA + DatiBollo + bottone "📄 Scarica XML SDI" tabella fatture
  - α.172.61: PDF endpoint usa anagrafica destinatario completa
  - α.172.62-64: tech sheet dropdown options + labels human-readable + camera model dropdown
  - α.172.65-66: camera specs matrix 26 modelli filter live per dropdown camera
  - α.172.67-70: milestones timeline (gruppo dedicato + range giorno + modal CRUD vero + color)
  - α.172.68: bulk fix deselect + filtri fatture annullate/NC + Seed Netflix → AI deep search
  - α.172.71: projects quote/job row click + scadenza/quote ref/JCL count + capitolati AI 503 user-friendly + ripristino Indigo Dark + tema Claqo separato
  - α.172.72: brand pack ufficiale (mascot 5 SVG copilot + app icon variant-B/C + tema Claqo Light)

## FASE EXTRA — Ore lavorate (aggiunta 24 mag sera)

Test verifica:
- `/hr` → tab Ore lavorate → log ora su utente attivo
- Verifica conteggio in `/cost-report?job=X` colonna "Maturato"
- Verifica timesheet su Booking done = total_accrued aggiornato
- Overtime: scaglioni CCNL applicati su orari notturni/festivi (`overtime_brackets` JSON in WorkingHoursPolicy)
- TimePunch (timbrature): /hr → tab Timbrature → in/out → verifica matching Booking
- Pass-through OT (α.172.37): toggle Cost Report → weighted_revenue mostra OT al cliente
- Bug noti aperti:
  - Verifica calcolo OT con `night_start`/`night_end` cross-mezzanotte
  - Festività detection vs `holidays` + `use_national_holidays` flag

## Vecchio punto di ripresa (23 mag)

- Commit `c51b86a` (α.172.50)
- 13 commit (23 mag): α.172.34 → α.172.50
- DB: clienti+progetti+quote freschi, 2 AP creati dal test Matteo

## Issue residuo elencato

- Sprint 7 backlog: FK ondelete table-rebuild (rischio), trasmissione automatica SDI (firma digitale richiesta), UI bottone "Genera XML SDI" in /finance, allocazione acconto su JobDeliverable

Vedi [[project-session-23mag2026-sprint1]] + [[project-sprint6-sdi-compliance]] per overview audit + sprint precedenti.
