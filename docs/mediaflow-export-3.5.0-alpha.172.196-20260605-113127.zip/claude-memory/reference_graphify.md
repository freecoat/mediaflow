---
name: reference-graphify
description: "graphify knowledge graph installato in MediaFlow (α.172.29 commit 90d8824). Cmd, path, costo, regole d'uso."
metadata: 
  node_type: memory
  type: reference
  originSessionId: d07cff20-e7c9-4380-b5a7-4b5f7957c80d
---

# graphify (knowledge graph codebase)

**Binary**: `C:\Users\frico\.local\bin\graphify.exe` (pipx install graphifyy 0.8.15)
**Repo upstream**: github.com/safishamsi/graphify

## Cosa fa
Tree-sitter AST locale (no API) + semantic extraction via `--backend claude-cli` (no cost). Produce sottografo focalizzato vs grep raw → meno context, più mirato.

## Output (gitignored, locale)
- `graphify-out/graph.json` — grafo completo queryabile
- `graphify-out/GRAPH_REPORT.md` — sintesi community + god nodes
- `graphify-out/graph.html` — viz interattiva
- `graphify-out/.graphify_analysis.json` — diagnostica
- Stato α.172.29: **3808 nodi · 8046 edges · 182 community**

## Comandi utili (cd in mediaflow_fase1bis)
- `graphify update .` — incrementale dopo cambi codice (AST only, no API)
- `graphify cluster-only .` — re-clustering + report
- `graphify query "<question>"` — BFS sottografo
- `graphify path "<NodeA>" "<NodeB>"` — shortest path
- `graphify explain "<concept>"` — neighborhood
- `graphify .` — full rebuild (richiede `--backend claude-cli` per skip API key)

## Setup files toccati (committati)
- `.claude/settings.json` project: PreToolUse hook Bash matcher su grep/find/rg/etc
- `CLAUDE.md` project: sezione graphify in fondo con regole
- `.gitignore`: `graphify-out/` + `.graphify-cache/`

## Skill registry globale (non-committato, ~/.claude/)
- `~/.claude/skills/graphify/SKILL.md`
- `~/.claude/CLAUDE.md` (4 righe, registra skill)

## Backup pre-install (rimuovibili se tutto OK)
- `CLAUDE.md.bak-pre-graphify`
- `~/.claude/settings.json.bak-pre-graphify` (file globale non modificato comunque)

## Quando lo invocherà Claude Code automatico
PreToolUse hook è solo Bash matcher. Se Claude lancia Bash con grep/rg/find/fd/ack/ag, riceve hint "usa graphify query". Glob/Grep nativi NON triggherano hook (sono tool separati). Per usare graphify devo invocare via Bash esplicito.

## Rigenerazione consigliata
Dopo grossi cambi (nuove feature multi-file). Incrementale `graphify update .` ~secondi. Full rebuild ~minuti su backend claude-cli.
