---
name: project-session-12giu2026-sal
description: "Sessione 12 giu 2026 — α.172.217 SAL Stato Avanzamento Lavori (vista finanza), pushato 376de93"
metadata: 
  node_type: memory
  type: project
  originSessionId: 30b5f08c-84f7-4873-a54f-17d30d641ace
---

**α.172.217 PUSHATO (376de93)** — SAL Stato Avanzamento Lavori, 8 commit, 4 task subagent-driven TDD. Stessa giornata di F4/F5/F6 (MAM completa).

- **Richiesta Matteo**: vista finanza dello stato progetti. Scartato metterlo nel cashflow (cassa≠avanzamento). Pagina dedicata `/finance/sal` read-only (gate view_finance), 2 tab.
- **Decisioni**: riga=Progetto (aggrega job), **% = ore lavorate/quotate** (sempre), breakdown generico per reparto (dettaglio fine resta nel cost-report), allarme su ore lavorate o pianificate > quotate per-job, monte ore quotate = SOLO voci a tempo (giorni→ore via policy, voci a corpo escluse).
- **Service** `sal_metrics.py`: quoted/planned/worked_hours (riusa `_booking_billable_hours` di cost_line_sync, no double-count), by_department, job_alarm (red/amber/none), project_metrics, timeline_metrics (mese/trim + fatturato Σ Invoice.subtotal TD04=-1, filtro anno SQL).
- **Endpoint** `/finance/api/sal/{projects,projects/{id}/detail,timeline}` batch no-N+1. **UI** sal.html 2 tab (progetto con drill-down reparti+job, temporale anno×mese/trim) + voce menu Finanza.
- 790 test (+44), E2E `tools/_e2e_sal.py` 41/41, smoke browser verde (Gomorra 1420h quotate, reparti DI 940+Audio 480, timeline 12 mesi, 0 errori console).
- **Pendente Matteo**: smoke con dati reali. Future: export PDF/Excel SAL, forecast, % fatturato nel tab progetto.
- Note sessione: 2 caduti subagent (1 API error socket Task 2 → re-dispatch pulito; lavoro non persistito). 2 finding security gestiti durante F5/F6 (argument injection ascp, substring whitelist bypass). Nessun gate view_finance esisteva sulle altre pagine finance — SAL lo applica come da spec.
