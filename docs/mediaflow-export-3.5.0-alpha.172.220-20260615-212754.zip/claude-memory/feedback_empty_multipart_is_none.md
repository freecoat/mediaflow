---
name: feedback_empty_multipart_is_none
description: "Campo multipart vuoto arriva come None (non \"\") a FastAPI Form Optional[str] → branch clear-via-\"\" non scatta. Usa sentinel '0'."
metadata: 
  node_type: memory
  type: feedback
  originSessionId: ee361322-7c90-4cdd-9f46-c0f3a9d2da17
---

In MediaFlow un campo FormData vuoto (`fd.append('k','')`) inviato a un endpoint FastAPI con `k: Optional[str] = Form(None)` **arriva come `None`**, non come `""`. Verificato in browser α.172.202: `''` → no-op (param None), `'0'`/`'xyz'` → ricevuti correttamente.

**Why**: rompe il pattern comune `if raw in ("", "0"): clear`. Il ramo "clear esplicito via stringa vuota" non scatta mai dalla UI → cancellare un valore (preset audio, FK) dal form sembra non funzionare anche se il codice server è corretto. Il commento storico su `delivery_item_id` Optional[str] avvisava per gli `int`, ma vale anche per `str`.

**How to apply**: per PULIRE/azzerare un campo dalla UI manda un **sentinel non vuoto** (es. `'0'`) e gestiscilo server-side come clear: `pfd.append('k', val === '' ? '0' : val)`. NON affidarti a `''` per distinguere clear da assente. Sospetto che `delivery_item_id=''` (unlink capitolato) abbia lo stesso problema — da verificare. Collegato a [[project_session_06giu2026]] e [[feedback_no_jsonstringify_in_onclick]].
