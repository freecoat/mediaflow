---
name: ffmpeg-drawtext-fontfile-windows
description: build ffmpeg Windows (Gyan) crashano 0xC0000005 su drawtext senza fontfile esplicito — serve font di sistema + retry generalizzato
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 30b5f08c-84f7-4873-a54f-17d30d641ace
---

Le build ffmpeg Windows comuni (Gyan winget 8.1.1) hanno fontconfig SENZA file di config: qualsiasi filtro `drawtext` senza `fontfile=` esplicito stampa "Fontconfig error: Cannot load default config file" e poi **crasha** con rc=3221225477 (0xC0000005) — non un errore pulito.

**Why:** lo stderr del crash NON contiene la parola "drawtext" → un fallback condizionato a `"drawtext" in stderr` non scatta mai. Scoperto live con l'E2E F3 (i test puri del builder non eseguono ffmpeg → verde ingannevole).

**How to apply:** (1) passare sempre `fontfile='{path escapato}'` con font di sistema (`_find_fontfile()` in `agent/preview.py`: consola/arial → Monaco/Helvetica → DejaVu); (2) il retry senza burn-in va fatto su QUALSIASI rc!=0 del tentativo con burn, non su match dello stderr; (3) per feature che dipendono da binari esterni, l'E2E con binario reale è obbligatorio prima di dichiarare done — vedi [[project-session-11giu2026-f3]].
