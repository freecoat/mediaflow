---
name: feedback_i18n_always
description: PINNED — ogni nuova feature/UI va resa subito traducibile in tutte le lingue del menu lingue
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 8b3fabf4-5b72-4669-9d17-73d883b079a3
---

PINNED (richiesto da Matteo 13 giu 2026): ogni cosa che programmiamo deve essere **subito tradotta** nelle lingue disponibili dal menu lingue. Niente stringhe hardcoded in UI: usare il sistema i18n del progetto fin dalla prima stesura, non come passata successiva.

**Why:** evitare il debito i18n (memoria storica: round 3 i18n ha dovuto recuperare 477→15 stringhe non tradotte). Matteo vuole zero arretrato di traduzioni.

**How to apply:** per ogni nuova label/legenda/header/colonna/select/toast → chiave i18n + traduzioni in tutte le lingue attive nello stesso commit. Annotare i18n come requisito standing in ogni spec/piano. Verificare il set lingue dal menu prima di chiudere.

Correlati: [[project_session_28mag2026_tier2]] (i18n round 3).
