---
name: project_session_10giu2026_f2
description: Sessione 10 giu 2026 (parte 2) — F2 Watch + Match completata e pushata
metadata: 
  node_type: memory
  type: project
  originSessionId: eec392da-63ad-428e-991e-f2cbc1e5b60f
---

α.172.211 PUSHATO (origin 05b3fc5). **F2 Watch + Match** dopo F1 ([[project_session_10giu2026]]). Piano `docs/superpowers/plans/2026-06-10-f2-watch-match.md`, design `...specs/2026-06-10-f2-watch-match-design.md`. Subagent-driven 10 task TDD.

- **Watch** (`agent/watch.py`): polling listing, size-stable (proposto dopo ≥1 ciclo quiete), DCP/IMF via ASSETMAP. Job `scan` ricorrente → proposte `registered_via='agent_watch'`. Zero `import app.`.
- **Match** (`app/services/deliverable_match.py`): scoring puro naming+container+codec+risoluzione+fps vs JobDeliverable/DeliveryItem (lookup Container/VideoCodec/Resolution/FrameRate). Progetto da convenzione path. Forte→`Asset.matched_deliverable_id`; debole→candidati; zero→libera. Conferma→`digital_asset_id`+`status=qc`.
- **UI** /storage colonne Match+candidati+Scansiona; mobile `/m/proposte` (idiomi `mapi/mToast/mEsc`).
- **520 test**. E2E 12/12 (`tools/_e2e_f2.py`) + browser smoke. Checklist `docs/qc/f2-e2e-checklist.md`.

**Final review opus** (come F1): 0 Critical, 5 Important fixati fix-forward (commit 05b3fc5):
1. project-code: euristica isupper/len SBAGLIATA (lowercase code, watch-dir "out", progetto "OUT", 9-char) → ora usa watch_dirs REALI del volume + fallback set export-dir comuni + Project.code case-insensitive.
2. DCP/IMF checksum vuoto → dedup saltato → riproposta a ogni scan. Fix: dedup su (volume,rel_path) se checksum assente.
3. scan ri-matchava asset deduped già confermato → clobber matched_deliverable_id. Fix: match solo se proposed_state==pending_review.
4. link_deliverable_on_confirm: 409 se deliverable già linkato ad altro asset (no orphan silenzioso).
5. naming-score su template `{title}_{ep}` falsava → skip se contiene `{`.

**Lezioni E2E**: residui run crashati (project.code/lookup UNIQUE) → pre-clean idempotente + nomi E2E-specifici. ffprobe assente test machine → inietta specs per provare match forte. `→` in print crasha console cp1252 → `->`.

**Prossimo**: F3 = preview QC (job preview, relay streaming + opzione S3, player scheda QC, retention). Fasi rimanenti F4 LTO/MHL, F5 TransferOrder, F6 distruzione+dashboard. Server UP :8000 .211. Backlog F2: scheduler scan ricorrente, override output_dir per-progetto, auto-scarto file sparito, persistenza candidati deboli.
