---
name: project-session-11giu2026
description: "Sessione 11 giu 2026 remota — α.172.212 browse storage via agent + installer ZIP, pushato 1c01245"
metadata: 
  node_type: memory
  type: project
  originSessionId: 30b5f08c-84f7-4873-a54f-17d30d641ace
---

Sessione 11 giugno 2026 (remota /rc). **α.172.212 PUSHATO (1c01245)**.

- **Browse via agent**: `AgentJobType.browse` + `agent/browse.py` (dirs-first, cap 500, traversal guard) + `POST /storage/api/volumes/{id}/browse` + `GET /storage/api/jobs/{id}` + modal file-browser breadcrumb/poll in storage.html ("Sfoglia" su register-path, "Aggiungi" su watch dirs edit-volume; NON su nuovo volume — manca volume_id).
- **Installer ZIP**: `GET /storage/api/agents/{id}/installer` rigenera token, ZIP claqo-agent/ con json precompilato + avvia-agent.bat/.command. Service `app/services/agent_installer.py`. Contratto preso da `tests/test_agent_installer.py` trovato UNTRACKED (sessione precedente troncata prima dell'implementazione).
- 535 test (+15). E2E `tools/_e2e_browse_zip.py` 15/15. Browser smoke live: agent VERO avviato in background con token (CLAQO_URL env) su dir temp — pattern riusabile per smoke futuri.
- Server riavviato :8000 su .212. Smoke Matteo pendente (Sfoglia + ZIP).
- **Prossimo: F3 preview QC** — brainstorming INIZIATO e interrotto subito (skill invocata, zero domande fatte). Riprendere da lì: job preview agent, relay streaming + opzione S3, player scheda QC.
