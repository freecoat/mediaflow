---
name: project-session-11giu2026-f3
description: "Sessione 11 giu 2026 sera — α.172.213 F3 Preview QC subagent-driven, pushato 8c323c1"
metadata: 
  node_type: memory
  type: project
  originSessionId: 30b5f08c-84f7-4873-a54f-17d30d641ace
---

**α.172.213 PUSHATO (8c323c1)** — F3 Preview QC, 13 commit, 8 task subagent-driven TDD (pattern F1/F2). Vedi [[project-session-11giu2026]] per browse+ZIP della stessa giornata.

- Flusso: Genera preview (modal QC) o auto su conferma (`StorageVolume.auto_preview`) → job `preview` → agent ffmpeg 1080p TC burn-in+watermark (`agent/preview.py`) → upload streaming `PUT /agent-api/jobs/{id}/preview-upload` (o S3 presigned) → `Asset.preview_*` → player `GET /qc/api/assets/{id}/preview` (Range) nel modal QC condiviso (`components/qc_modal.html`, prefisso funzioni `qcm*`) + bottone 📍 TC che compila `qcm-log-timecode`.
- Hardening review (3 round): path locale SOLO `local_path_for` (mai dall'agent), mode dal payload server, key S3 server-derived, `.part` uuid per richiesta (no interleave su retry), escaping drawtext (virgole/apostrofi), guard ffmpeg assente, retry upload 3x, stderr utf-8, preview_error senza path interni, cache-bust player post-rigenerazione.
- 576 test (+41). E2E `tools/_e2e_f3.py` SKIP su questa macchina (no ffmpeg) — gira in facility. Browser smoke modal QC verde.
- **Pendente Matteo**: smoke con agent in facility (ffmpeg): conferma con auto_preview → player + 📍 TC. Backlog F3: refresh presigned scaduto, retention preview, player /storage+mobile, thumbnails, HLS.
- Lezione subagent: modal QC NON è in job_detail.html → componente condiviso aperto anche da planning.html; le funzioni onclick devono vivere nel componente.
