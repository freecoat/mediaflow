---
name: project-session-12giu2026-f5
description: "Sessione 12 giu 2026 — α.172.215 F5 TransferOrder subagent-driven, pushato 37e797d"
metadata: 
  node_type: memory
  type: project
  originSessionId: 30b5f08c-84f7-4873-a54f-17d30d641ace
---

**α.172.215 PUSHATO (37e797d)** — F5 TransferOrder, 9 commit, 5 task subagent-driven TDD. Segue [[project-session-12giu2026-f4]].

- **Adapter registry** `transfer_adapters.py` (manual + aspera agent-driven); driver futuri Shuttle API/S3/Backlot si registrano lì (Matteo li usa tutti in facility, credenziali quando le porta).
- **Agent ascp** (`agent/transfer.py`): credenziali SOLO env agent (`ASPERA_SSH_KEY_PATH`/`ASPERA_EXTRA_ARGS`), traversal guard, multi-volume; ramo transfer in handle_job PRIMA del guard vol top-level (i file hanno volume_id per-file).
- **Service** `transfer_orders.py`: FSM come ArchiveTicket; done → AssetMovement outgest per asset (to_party/to_contact/carrier/tracking=link); failed → notify_permission; esiti job tolleranti a ordini orfani (try ValueError nel router, MAI 500 → job resterebbe claimed); il ramo transfer di process_job_result ritorna None (return è esposto come asset_id!).
- **UI**: tab 🚚 Transfer (ids `ntr-*`, NON `nt-*` che è il modal ticket F4), badge scadenza link, `_transferSafeHref` allowlist http/https (escapeHtml NON blocca `javascript:` negli href — lezione XSS).
- 669 test (+45), E2E 52/52. Convenzione datetime: progetto = NAIVE UTC (clock.now_utc docstring) — reviewer che propone tzinfo va respinto.
- **Prossimo: F6** (ultima fase MAM): distruzione doppia-conferma, dashboard "dove vive ogni asset", report storage, + TPN gate transfer rimandato da F5.
