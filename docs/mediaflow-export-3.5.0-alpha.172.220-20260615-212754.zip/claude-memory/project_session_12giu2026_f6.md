---
name: project-session-12giu2026-f6
description: "Sessione 12 giu 2026 — α.172.216 F6 distruzione+dashboard+report, CHIUDE roadmap MAM F1-F6. Pushato 1b0e93d"
metadata: 
  node_type: memory
  type: project
  originSessionId: 30b5f08c-84f7-4873-a54f-17d30d641ace
---

**α.172.216 PUSHATO (1b0e93d)** — F6, 6 task subagent-driven TDD. **CHIUDE roadmap MAM F1→F6.** Segue [[project-session-12giu2026-f5]].

- **Distruzione doppia-conferma** (`destruction.py` + `DestructionRequest` FSM): permesso RBAC `approve_destruction`, approve vieta self (user None bypassa? NO — fix), cancel solo richiedente/admin (is_admin dal router), agent `delete_verify` VERIFY-ONLY (mai cancella), `_finalize` idempotente → AssetMovement `destroyed` (nuovo enum membro) + content_state deleted/archived_only (record Asset eterno).
- **Dashboard 🗺 Mappa** (/storage 7° tab): asset-map (batch no-N+1, cap 500+truncated) + storage-report + UI distruzioni.
- **Gate TPN transfer** (egress_guard `assert_transfer_allowed`, Tenant.transfer_destination_whitelist): **match host anchored** — `_extract_host` da user@host:/path, esatto o suffisso .dominio; destination manual = match esatto. Substring NO (bypass `evil-netflix.com.attacker.com` chiuso da security review). Pannello /settings Sicurezza.
- 757 test (+88), E2E `tools/_e2e_f6.py` 51/51 (doppio TestClient per doppia conferma).
- **Pendente Matteo**: smoke browser /storage completo + flusso reale agent facility.
- **Backlog MAM consolidato**: delete attivo agent (oggi verify-only), driver transfer reali (Shuttle API/S3/Backlot), link manuale orfana→asset, retention preview, report PDF/schedulati, email destinatario, verifica periodica tape.
- Tunnel cloudflared quick attivo (riaggancia da solo ai restart). 2 troncamenti session-limit gestiti: Task 4 (subagent morto post-lavoro non committato → committato io) e Task 6 (re-dispatch pulito).
