- [Matteo profilo](user_matteo.md) — manager IT post-prod, Mac Python 3.14, conciso, AI propone utente dispone
- [Programma email+calendario 4 sotto-fasi](project_mail_calendar_program.md) — 1.Calendari✅α.248 → 2.Email client Thunderbird → 3.sleek → 4.AI copilot profondo. Prereq: reconnect Google+People API
- [Asset Library redesign BACKLOG](project_asset_library_redesign_backlog.md) — deliveries(quote→planning) popolano assets, operatore associa file esistente NO upload. Dopo email+calendar
- [PINNED i18n sempre](feedback_i18n_always.md) — ogni nuova UI traducibile 5 lingue, no hardcoded, stesso commit
- [Approccio generico sempre](feedback_approccio_generico.md) — architetture riusabili, in-depth, proposte ampie, domande esplicite. NON tappare buchi singoli
- [Log report a ogni apertura](feedback_log_report_apertura.md) — diagnostica + piano + conferma prima di toccare codice
- [Sonnet pianifica, Opus esegue](feedback_sonnet_plan_opus_exec.md) — brainstorming+piano SEMPRE subagent Sonnet; esecuzione codice/TDD/smoke in Opus
- [Commit automatici a fine versione](feedback_commit_auto.md) — committo senza chiedere a fine bump + CHANGELOG + STATO
- [Push policy context-dependent](feedback_push_solo_major.md) — locale=solo major bump; remoto=push ogni commit
- [Export ZIP a ogni push](feedback_export_zip_at_push.md) — genera DB ZIP in docs/ prima del push, importabile via /settings>Dati
- [.env untracked dal 12 mag](feedback_env_untracked.md) — .env non tracciato (leak API key) — usa export ZIP per portabilità
- [Screenshots path](reference_screenshots_path.md) — Matteo li copia in docs/Logs-temp/Screenshots/
- [graphify installato](reference_graphify.md) — knowledge graph (3808 nodi). `graphify query/path/explain`. AST locale + claude-cli
- [AI model switchabile](feedback_modello_ai_switchabile.md) — Sonnet 4.6 default, dropdown UI Opus/Haiku

### Trappole tecniche (feedback)
- [.env non caricato in os.environ](feedback_dotenv_not_loaded_osgetenv.md) — pydantic Settings non popola os.environ; os.getenv (oauth/crypto) non vede .env. Bridge in config.py f231e58. Win launcher usa `py` non `python` (stub Store)
- [Smoke E2E browser obbligatorio](feedback_smoke_e2e_browser.md) — backend smoke NON cattura ReferenceError JS; grep nome funzione prima del commit
- [Mock al punto unico, forme reali](feedback_mock_shape_must_match_real_api.md) — mockare la funzione da testare inventa forme che l'API non manda (bug oggetto /mail)
- [Uvicorn reload orfani in smoke](feedback_uvicorn_reload_orphans_smoke.md) — run.py reload=True lascia figli orfani sul socket 8000 (codice vecchio); lancia uvicorn senza reload, 127.0.0.1
- [git add -A mid-merge sweepa junk](feedback_git_add_all_sweeps_stray_in_merge.md) — untracked locali non-ignorati finiscono nel merge commit; filtra file A contro MERGE_HEAD
- [Template change → restart](feedback_template_change_needs_restart.md) — Jinja su OneDrive non ricarica a runtime (mtime); riavvia prima dello smoke
- [Cache-buster static asset](feedback_cache_buster_static.md) — modificare static/js senza bumpare ?v= in base.html = fix non arriva al browser
- [Auto-migrate colonne al boot](feedback_auto_migrate_columns.md) — colonna nuova senza check in _auto_migrate_columns() main.py = crash se utente non migra
- [Soft-delete + UNIQUE bypass](feedback_soft_delete_unique_bypass.md) — progressivi/unicità usano execution_options(include_deleted=True)
- [Helper JS in global.js](feedback_global_helpers_centralizzati.md) — escapeHtml & co. centralizzati, non ridefiniti per template
- [No JSON.stringify in onclick](feedback_no_jsonstringify_in_onclick.md) — antipattern; usa data-* attributes
- [No Jinja letterale in commenti JS](feedback_jinja_in_js_comments.md) — `{% if %}` in commento JS spacca parsing
- [No shadow funzioni globali Jinja](feedback_jinja_shadow_globals.md) — context bool che shadow funzione globale → TypeError base.html. Usa prefisso
- [Empty multipart = None](feedback_empty_multipart_is_none.md) — FormData vuoto = None a FastAPI Form Optional[str]; sentinel '0' per pulire
- [JSON.parse col1 = 500 server](feedback_jsonparse_col1_is_500.md) — copilot "line 1 column 1" = 500 plain-text Starlette, non proxy
- [AI schema descriptions](feedback_ai_schema_descriptions.md) — tool-schema ambigui servono description; enum non diverga da dati reali
- [AI parser JSON lenient](feedback_ai_json_lenient.md) — safe_json_parse tollera commenti // e trailing commas
- [AI max_tokens + decouple save](feedback_ai_maxtokens_and_decouple.md) — output troncato=max_tokens basso (8000→32000, >16000=streaming Claude); mai estrazione AI ~7min sincrona in /api/save (tunnel timeout→409); disaccoppia. α.172.233 fix import Paramount
- [Anthropic streaming threshold](feedback_anthropic_streaming_threshold.md) — SDK rifiuta non-streaming >10min; auto-stream se max_tokens>16K
- [ClaudeProvider.chat auto-stream >16K](feedback_claude_chat_autostream.md) — output vision grande troncato senza streaming → JSON {}
- [Vision capitolati costo](feedback_vision_cost_capitolati.md) — estrazione PDF vision cara (~75k img token/call); DeepSeek no vision (resta Claude)
- [Copilot provider legacy → contesto](feedback_copilot_legacy_provider_context.md) — DeepSeek/Ollama/Perplexity no tool nativi; feature nel build_context
- [Copilot più capability = meglio](feedback_copilot_more_capabilities.md) — ogni mutator endpoint ha propose_* nel registry AI
- [Vis-timeline 7.x quirks](feedback_vis_timeline_quirks.md) — HTML annidati sanificati (HTMLElement), select no su setSelection (_tlSetSel), stack:true O(N²) freeza
- [ffmpeg drawtext fontfile Windows](feedback_ffmpeg_drawtext_fontfile_windows.md) — Gyan crasha 0xC0000005 senza fontfile; retry no-burn su rc!=0; E2E binario reale
- [jsonschema metaschema URI](feedback_jsonschema_metaschema_uri.md) — draft-07 = http://json-schema.org/draft-07/schema# (http, # finale)
- [Plugin registry test isolation](feedback_plugin_registry_test_isolation.md) — _REGISTRY richiede fixture autouse snapshot + importlib.reload
- [SQLAlchemy after_insert quirk](feedback_sqlalchemy_after_insert_quirk.md) — projection sync NON in after_insert; chiama esplicitamente post-flush

### Decisioni architetturali (project)
- [Decisioni hosting backend](project_hosting_decisions.md) — VPS+SQLite, Postgres con trigger, deployment-per-tenant, DB-per-tenant Fase 7. Docker+Caddy pronti
- [Cost report ≠ Timesheet](project_costreport_vs_timesheet.md) — cost report parte da Booking, Timesheet binario HR separato
- [Reverse-quote flow](project_reverse_quote_flow.md) — Job nasce sempre da Quote; reverse via attach o phantom quote
- [Invarianti Quote↔Job↔Booking↔Resource](project_integrity_invariants.md) — HARD-BLOCK delete con booking attivi, man-hours canonico
- [CCNL parametrizzato](project_normativa_ccnl.md) — overtime_brackets + ccnl_label
- [Pass-through OT al cliente](project_pass_through_ot.md) — toggle weighted_revenue: serve OT approved + WHP + unit=day
- [DAM digital ≠ physical](project_dam_physical_assets.md) — modelli SEPARATI Asset (digital) e PhysicalAsset; internal_archive/delivered_external ortogonale
- [TB/GB ammontare rendicontativo](project_tb_ammontare_rendicontativo.md) — volume = 1 row aggregata; cambio unit cross-nature respawn artifacts
- [AI derivazione costi](project_ai_cost_derivation.md) — futuro: AI legge visura/bilancio → propose_resource_cost_update
- [Capitolato↔deliverable link](project_capitolato_deliverable_link.md) — catena FK capitolato→quote→job→planning; bucket=N item
- [Multiselect/multidrag desiderata](feedback_multiselect_multidrag.md) — non chiudere senza affrontarlo
- [Port mobile futuro](project_mobile_port.md) — PWA scope ridotto: staff operativo + finance read-only + planning lista. NO drag timeline
- [Dialogo con il cliente](project_dialogo_cliente.md) — futuro: portale cliente con DAM, cost report, scheda progetto
- [Rebrand Claqo](project_rebrand_claqo.md) — MediaFlow→Claqo α.172.59 parziale. Mascot robot solo copilot. Icona finale ≠ mascot
- [Rebrand obbligatorio](project_rebrand_required.md) — "mediaflow" già preso, sostituire prima del lancio
- [17 capitolati corpus](project_capitolati_corpus.md) — docs/capitolati_esempio/ per listino generico e DeliveryTemplate
- [Audit capitolati + colore RAI](project_capitolato_audit_color.md) — 12 item UHD Rec.2020 PQ+SDR invariati (RAI inaffidabile, fix manuale)
- [Deliverables pipeline brainstorm WIP](project_deliverables_pipeline_brainstorm.md) — design capitolato→…→asset; spec in docs/superpowers/specs/2026-05-29
- [Stack 2 QC event-sourced](project_stack2_qc_event_sourced_decisions.md) — per-asset, event types, snapshot denorm sync, alimenta Bundle I
- [Anomaly workflow stateful](project_anomaly_workflow.md) — 5 tipi + 4 azioni (rimanda/rivaluta/write-off/overhead) + AnomalyEntry stateful

### Account linking + Calendario + Documenti (corrente)
- [Sessione 5-6 lug Calendario Fase B+B.1](project_session_05lug2026_calendar_phaseB.md) — α.240+α.241 ramo feat/calendar-phaseB NON pushato. B: CalendarEvent+FullCalendar+capability+fix snapshot _ACTION_HANDLERS. B.1: event_modal.js condiviso (create/edit/delete), vista settimana, tab acquisizioni leggibile ✎/🗑. start.bat launcher. 1053 test, smoke Playwright verde
- [Sessione 6 lug Calendario Fase C+D](project_session_06lug2026_calendar_phaseCD.md) — α.242 sync Google bidirezionale + α.243 documenti Drive (DocumentLink+google_drive.py+documents.js, fallback name, Picker opzionale). Ramo feat/calendar-phaseB ora B+B.1+C+D, 1103 test, smoke verde. MERGED main (a3b2893) non pushato. CHIUDE A/B/C/D
- [Sessione 7 lug Client email F1](project_session_07lug2026_mail_client_f1.md) — α.244 /mail webmail standalone (Gmail readonly+compose opt-in incrementale, gmail.py+mail.py STATELESS no migrazione, iframe sandbox, compose completo). Ramo feat/mail-client-phase1 NON pushato, 1133 test, smoke verde (degrada CTA senza opt-in). Trappola: test router serve JWT cookie reale+monkeypatch SessionLocal. PROSSIMO F2 integrazione CRM (tab Email+pin EmailLink+Estrai-AI+Activity)
- [Sessione 7 lug Client email F2](project_session_07lug2026_mail_client_f2.md) — α.172.245 ramo feat/mail-client-phase2 NON pushato. EmailLink aggancia thread Gmail a trattative (tab Email+pin da url/thread_id+anteprima sandbox+Estrai-AI copilot+auto-Activity email), parse_gmail_thread_id, mfMailAssign da /mail. 6 task TDD, 1152 test, smoke Playwright verde. PROSSIMO smoke Matteo + F3 auto-flow (auto-associaz mittente, notifiche)
- [Sessione 4 lug OAuth Fase A](project_session_04lug2026_oauth_phaseA.md) — α.239 MERGED main (dc7669d) NON pushato. Account linking Google (scope least-privilege calendar.app.created+readonly+drive.file), refresh auto, CSRF HMAC, colonne sync UserOAuthToken, UI card /settings i18n. 7 task subagent TDD, 1033 test. Design A/B/C/D. PROSSIMO Fase B (CalendarEvent+FullCalendar). Prereq Matteo: OAuth client Google Cloud. + pulizia 59 progetti test banner

### Corrente (17 lug)
- [Mail ctx-menu + contatti α.263](project_session_17lug2026_mail_ctxmenu_contacts.md) — MERGED main 6fe5959 non push. Context menu tasto destro/drag-label/select-all + scope opt-in mail_full (elimina-def/svuota-cestino) + redesign modale contatti+Note. 1401 test. PENDENTE smoke Matteo

### 15 lug
- [Corpo email + etag drag&drop](project_session_15lug2026_mail_body_etag.md) — α.250 main (9a5d8b0) NON push (111 avanti). Iframe 300x150: CSS `mail-*` mai esistito da F1. sandbox="allow-same-origin" (MAI allow-scripts) per auto-altezza. Etag overlay→PUT→riallineo. Token ha già scope `calendar` pieno. PENDENTE: Matteo trascini davvero un evento Google
- [Merge F1+F2+F3 + fix /mail + Google Calendar editabile](project_session_15lug2026_gcal_editable.md) — main α.248 NON push (88 avanti). "Regressione" era falsa: merge no-op, /mail rotto da F1, calendario read-only by design. PENDENTE: OAuth reale mai esercitato (smoke con Google mockato)

### Client email F3
- [Rubrica Contatti F3](project_session_14lug2026_mail_client_f3.md) — α.172.246 ramo feat/mail-client-phase3 NON push. Contact standalone (client_id nullable+M:N acq/proj), /contacts pagina+picker associa, estrazione ibrida da email, ponte scheda tecnica, propose_contact esteso, badge notifica. 1196 test+smoke verde. PROSSIMO smoke Matteo→merge F1+F2+F3

### Media Library (corrente)
- [Media Library A+B](project_session_13lug2026_media_library_faseA.md) — ramo feat/media-library NON pushato/mergiato. A(α.244) /media browser read-only fonde Asset+PhysicalAsset, filtri 4 gruppi (tech json_extract nidificato $.video.*). B(α.245) azioni bulk associa/archivia/scollega/export + **supersede** (vecchio link storico+stato→in_progress, 3 col DeliverableAsset, media_actions.py). 59 test, smoke verde. PROSSIMO smoke Matteo (2 migrazioni) → merge A+B OR Fase C

### KDM (corrente)
- [19 giu KDM](project_session_19giu2026_kdm.md) α.226 KDM/DKDM tracking. /kdm+form pubblico token+CPL auto-match+materializza deliverable. Trappole: PriceItem no `code`, @ai_capability prima snapshot
- [23 giu KDM i18n](project_session_23giu2026_kdm_i18n.md) α.227 PUSHATO ad4a08f. Fix 42 chiavi i18n. topbar_title hardcoded IT. git commit -F (hook blocca heredoc); [24 giu](project_session_24giu2026.md) α.230-233 PUSHATO (52b0582) KDM redesign Step1+2+batch+fix import (RIAPERTURA in α.234)
- [Motore parsing+bg extract](project_session_27giu2026_parse_engine.md) α.234 (3170172) parsing esplicito (badge+override, users.parse_ai_provider) + α.235 (7a27a6c) estrazione item AI BACKGROUND (thread+polling) + delete item (🗑+bulk). NON push. PENDENTE: Matteo test bg extract+ri-carica Paramount
- [Acquisizioni F1](project_session_27giu2026_acquisizioni_f1.md) α.236 MERGED (b536f9a) NON push. Modulo CRM/pipeline (Acquisition/Contact/Activity, kanban+tabella, capability propose_*, fix can_edit_projects). FOLLOW-UP: KPI/filtri owner-cliente UI
- [Acquisizioni F2](project_session_27giu2026_acquisizioni_f2.md) α.237 MERGED (eddc5ed) NON push. Estrazione email copilot (📥/🔎)+incrocio web. Capability update_client+propose_client_work, web_search con Tenant.web_sources include_domains
- [KDM UI](project_session_27giu2026_kdm_ui.md) α.238 MERGED (45bf651) NON push. /kdm tab Link+link editabili PUT+filtri+select-all+multiselect bulk-delete. Trappola test-pollution fixture (monkeypatch non assegnaz diretta)
- [KDM redesign decisioni](project_kdm_redesign.md) — 24 giu: Step1 detail editabile+filtri+azioni emetti/conferma+fix picker form pubblico; Step2 certificati N. Emissione esterna=registro, producer link+account
- [Sessione 23 giu parser robusto](project_session_23giu2026_parser_robusto.md) — α.172.228/229 (2d12718) parser 8-blocchi + item-list robusti + auto-extract. pick_parse_provider modello forte, 150k chunk, capitolato_storage salva+resolve. PENDENTE: Matteo RI-CARICA Paramount (id18 a 0 item)

### Sprint audit (α.172.35-41)
- [Sprint 1](project_session_23mag2026_sprint1.md) audit multi-agent 131 finding/37 P0; [tenant_guard](project_sprint1_tenant_guard.md) α.35 scoped/fetch_or_404+RBAC edit_cost_lines; [Sprint 2 slice-lock](project_sprint2_slice_lock_symmetric.md) α.36 billing_slice_guard.py
- [Sprint 3](project_sprint3_finance_invariants.md) α.37 weighted_revenue+anomaly cascade+IVA riga; [3.5 Decimal](project_sprint3_5_decimal_hotspot.md) α.38 invoice_totals; [Sprint 4](project_sprint4_ui_antipattern.md) α.39 cache-buster Jinja
- [Sprint 5](project_sprint5_db_integrity_it_tax.md) α.40 JCLBilledSlice immutability+tenant_id FK+italian_tax.py; [Sprint 6 SDI](project_sprint6_sdi_compliance.md) α.41 FatturaPA XML builder /finance/api/invoices/{id}/sdi-xml

### Sessioni recenti (giu 2026, MAM F1→F6) — tutte PUSHATE
- MAM F1→F6 α.172.210-216: [F1](project_session_10giu2026.md) Asset Registry+Claqo Agent, [F2](project_session_10giu2026_f2.md) watch+auto-match, [F3](project_session_11giu2026_f3.md) preview QC ffmpeg, [F4](project_session_12giu2026_f4.md) LTO YoYotta+ArchiveTicket FSM, [F5](project_session_12giu2026_f5.md) TransferOrder, [F6](project_session_12giu2026_f6.md) distruzione+TPN gate. [browse+installer](project_session_11giu2026.md) α.212, [SAL](project_session_12giu2026_sal.md) α.217, [8 giu](project_session_08giu2026.md) cascade cestino, [6 giu](project_session_06giu2026.md) audio override

### Storico (apr-mag 2026, compresso)
- [Content Lockdown 5 giu](project_session_05giu2026_content_lockdown.md) α.195 megaswitch egress TPN fail-closed; [4 giu](project_session_04giu2026.md) α.185 multiselect righe quote; [3 giu](project_session_03giu2026.md) α.179→184 multi-risorsa mobile+naming; [2 giu](project_session_02giu2026.md) α.160→178 capitolato/TC/mobile/hosting
- [31 mag](project_session_31mag2026.md) α.147→159 TPN/DAM+valuta+MOBILE PWA v1+v2 ([remote batch](project_session_31mag2026_remote_batch.md) α.160 NON push); [30 mag](project_session_30mag2026_multiaudit.md) α.142→146 audit 8-dim+export ZIP; [29 mag](project_session_29mag2026.md) α.124→129 vision+97 AudioConfigPreset
- Stack1/2 Bundle L (25-28 mag): [Tier2](project_session_28mag2026_tier2.md) α.109→116 delivery taxonomy+parser 2-pass, [Stack2 close](project_session_28mag2026.md) α.97→101 QC event-sourced, [27 sera](project_session_27mag2026_sera_stack2.md)/[pom](project_session_27mag2026_pomeriggio.md), [Stack1 close](project_session_27mag2026_bundle_l_stack1.md) α.94-96 17/17 tech specs, [26](project_session_26mag2026.md) Bundle K, [25 locale](project_session_25mag2026_locale_bundle_i.md) I+J+H2+H3, [25 pom](project_session_25mag2026_pomeriggio.md) E/B/A/C/D/F/G/H1, [25](project_session_25mag2026.md) smart_split, [test plan 24](project_test_plan_24mag2026.md)
- [22 mag](project_session_22mag2026.md) α.28→34 tech sheet+festività+WHP+graphify; [21 mag](project_session_21mag2026.md) α.17→27 Copilot multi-resource+Quote immutabile; [15 mag audit](project_session_15mag2026_audit_maratona.md) 6 round 80+ fix; [14 mag](project_session_14mag2026_followup.md) temi+timeline T1-T4
- [12 mag notte](project_session_12mag2026_night.md) α.88 cost report+cashflow+anomalie; [12 sera](project_session_12mag2026_late.md) α.84→87 MFAutocomplete/MFFilterBar/plugin/OverheadCost; [12](project_session_12mag2026.md) stress 1k+untrack .env
- [11 mag sera](project_session_11mag2026_late.md) α.22→76 Supplier 360+TPN+parse fatture AI+31 AI tools; [11](project_session_11mag2026.md) α.14→16.3 tenant scope+permission gate 76/76; [10 mag](project_session_10mag2026.md) α.66.6→13 listino lean 43+cost-rate
- Billing riarch 8 mag: [sera](project_session_08mag2026_evening.md) α.63/64, [notte](project_session_08mag2026_late.md) α.58→62 JCLBilledSlice+HARD-BLOCK 409, [8](project_session_08mag2026.md) α.56, [Roadmap OBSOLETA](project_billing_roadmap_alpha65plus.md); [7](project_session_07mag2026.md) α.41→51 font+billing 4 step; [6](project_session_06mag2026.md) α.35→40 ROI; [5 sera](project_session_05mag2026_late.md) α.22→25
- [3 mag](project_session_03mag2026.md) α.51→56+α.1→8 reverse-flow+AI tool-use+Cestino; [2](project_session_02mag2026.md) versioning quote; [1](project_session_01mag2026.md)+[notte](project_session_01mag2026_late.md) deadline notify; [30 apr](project_session_30apr2026.md) v3.4.21→27 overtime+RBAC; [29 apr](project_session_29apr2026.md) core-planning E1→E6; [28 apr](project_session_28apr2026.md) v3.4.5→11
- [16 mag maratona](project_session_16mag2026_maratona.md) α.119→134 ARCHITETTURA.md; [16](project_session_16mag2026.md)/[17](project_session_17mag2026.md) α.135; [α.134 Shadow](project_alpha134_findings.md); [α.120 backlog](project_alpha120_backlog.md); [test checklist α.114-118](test_checklist_post_audit_alpha114_118.md)
