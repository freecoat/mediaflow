---
name: feedback_dotenv_not_loaded_osgetenv
description: pydantic Settings NON popola os.environ; moduli con os.getenv non vedono .env senza bridge
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 1cfa5f87-c87d-4679-903d-695c25a37837
---

`app/config.py` usa `pydantic BaseSettings` (`env_file=".env"`): legge `.env` SOLO per popolare l'oggetto `settings`, **non** esporta in `os.environ`. Nessun `load_dotenv` nel progetto (python-dotenv nemmeno installato).

**Trappola:** moduli che leggono config via `os.getenv(...)` — `oauth_providers.py` (`GOOGLE_OAUTH_CLIENT_ID/SECRET`, `OAUTH_REDIRECT_BASE_URL`), `crypto.py`/`_fernet` (`AI_KEY_ENCRYPTION_KEY`) — NON vedono i valori di `.env` anche se presenti. Sintomo reale (5 lug 2026): OAuth Google sempre 503 "provider non configurato" con credenziali corrette in `.env`; `is_configured('google')` False, `os.getenv('GOOGLE_OAUTH_CLIENT_ID')` None.

**Why:** pydantic-settings e os.getenv sono due sorgenti separate; l'app mescolava le due convenzioni senza bridge.

**How to apply:** fix in `app/config.py` (commit f231e58) — `_load_dotenv_into_environ()` minimale (no dipendenza) che parsa `.env` e fa `os.environ[k]=v` per chiavi non già presenti, chiamato a import prima di `Settings()`. Per nuova config leggibile via os.getenv verificare che passi da questo bridge. Preferire comunque `settings.<campo>` (pydantic) per nuovi valori quando possibile.

Correlato: [[feedback_env_untracked]] [[project_session_04lug2026_oauth_phaseA]].
