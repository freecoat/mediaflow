---
name: feedback_git_add_all_sweeps_stray_in_merge
description: git add -A mid-merge sweeps stray untracked local junk into the merge commit; filter added files against MERGE_HEAD
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 1af54fad-1935-4b58-912d-eae11ab4ca15
---

Completare un merge con conflitti: MAI `git add -A`. Sweepa untracked locali non
gitignorati (`.playwright-mcp/`, `db_snapshots/*.db`, `data/previews/*.mp4`,
`*.bak`) dentro il commit di merge. In α.262 ha portato 186 file spuri (277 con
playwright) → 96830 insertions invece di ~4742.

**Why:** questi dir sono untracked ma NON in `.gitignore`; alcuni già parzialmente
tracciati storicamente, quindi non saltano all'occhio.

**How to apply:** stagea i risolti mirati, poi filtra i file aggiunti contro il
ramo: per ogni `git diff --cached --name-only --diff-filter=A`, se
`git cat-file -e MERGE_HEAD:"$f"` fallisce E non l'hai creato tu → `git reset HEAD -- "$f"`.
Verifica anche le D (delete) siano nel ramo, non stray. Target ~108 file/+4742 (STATO cita 107/+5477), non 571/+96830.

Collegato: [[feedback_env_untracked]] (stessa classe: junk locale non tracciato).
Nota: valutare `.gitignore` per `.playwright-mcp/` + `db_snapshots/` per prevenire recidiva.
