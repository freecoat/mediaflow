---
name: feedback_mock_shape_must_match_real_api
description: "Mockare al livello sbagliato inventa forme che l'API vera non manda — il bug oggetto /mail passò così"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 5203352a-6664-4f8f-9f6d-795ef8cec547
---

Mockare la funzione che *contiene* la logica da testare non testa niente: verifica solo il mock. Il bug "oggetto = corpo" in `/mail` (α.172.247) è passato così — `test_threads` mockava `gmail.list_threads` a livello di router, quindi la logica vera non girava mai e il mock restituiva `{"id","snippet"}` + un subject che **Gmail non manda**.

**Why:** ogni servizio Google in questo progetto dichiara nel docstring il proprio *punto unico di mock* (`_gmail_request`, `_google_request`). Mockare più in alto salta esattamente il codice da verificare, e il mock diventa una fantasia coerente con sé stessa ma non con l'API reale.

**How to apply:** mocka al punto unico dichiarato, e riproduci le forme **reali** dell'API (per Gmail: `threads.list` → solo `{id, snippet, historyId}`, nessun header; il subject sta solo in `threads.get`). Se non sei sicuro della forma, chiamala davvero una volta e guarda. Corollario: un mock nasconde anche gli errori di serializzazione — `urlencode` senza `doseq` stringificava `metadataHeaders` come `"['Subject']"` rompendo la chiamata vera, invisibile a qualunque test col mock. Vedi [[feedback_smoke_e2e_browser]].
