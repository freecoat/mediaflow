---
name: feedback_sonnet_plan_opus_exec
description: "Workflow — brainstorming e piano SEMPRE con Sonnet (subagent), esecuzione con Opus (main loop)"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 9092570b-26c1-4d24-9a81-44c4f3631c75
---

D'ora in poi (14 lug 2026): **brainstorming + writing-plans SEMPRE delegati a subagent model=sonnet**; **esecuzione (codice, TDD, smoke, commit) sempre in Opus** (main loop).

**Why:** Matteo vuole ottimizzare costo/qualità — pianificazione va bene con Sonnet, l'implementazione la vuole in Opus.

**How to apply:** Il design dialogue con l'utente lo fa Opus (interattivo). Poi: scrivo spec → dispatch `Agent subagent_type general-purpose model=sonnet` che invoca `superpowers:writing-plans` sulla spec → Opus esegue i task. Se serve rivedere/patchare il piano, uso lo stesso subagent Sonnet via [[SendMessage]]. Correlato: [[feedback_commit_auto]], [[feedback_smoke_e2e_browser]].
