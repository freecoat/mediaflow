---
name: feedback_uvicorn_reload_orphans_smoke
description: run.py usa uvicorn reload=True; kill lascia figli orfani sul socket 8000 che servono codice vecchio → smoke ingannevole. Lancia senza reload
metadata: 
  node_type: memory
  type: feedback
  originSessionId: ff3f0919-ec19-4c5b-95b9-6dca6e9e95d6
---

Durante smoke browser locali: `run.py` avvia uvicorn con `reload=(app_env=='development')` → in dev è `reload=True`, che spawna un processo reloader + worker figlio. Un `taskkill`/`pkill` sul parent lascia il **figlio orfano** che continua a tenere il socket `:8000` e serve il **codice vecchio**. Sintomo: applichi un fix, riavvii, ma il browser vede ancora il bug (es. 500 già risolto), e `server.log` del nuovo processo mostra `0` richieste. `netstat -ano | grep :8000` mostra **più PID LISTENING**; `Get-Process -Id <pid>` a volte li dà per morti mentre il socket resta stale.

**Why:** reload multiprocess + kill parziale = zombie sul socket. Windows tollera bind multipli su :8000 e consegna al processo vecchio.

**How to apply:** per smoke locali lancia uvicorn **senza reload**:
`.venv/Scripts/python.exe -c "import uvicorn; uvicorn.run('app.main:app', host='127.0.0.1', port=8000, log_level='warning')"`
(NON `APP_ENV=production`: fa scattare `assert_production_security` in `main.py` lifespan → RuntimeError su AUTH_REQUIRED). Prima di ripartire: `taskkill //F //IM python.exe` (nessun altro python in gioco durante smoke), poi verifica `netstat` = 1 solo listener su 127.0.0.1:8000. Usa `127.0.0.1` non `localhost` per evitare cache sessione browser sul vecchio host.

Correlato: [[feedback_smoke_e2e_browser]] (smoke browser becca ciò che i mock non coprono — vedi fix 403 Fase C: `ensure_claqo_calendar` fuori dal try), [[feedback_template_change_needs_restart]].
