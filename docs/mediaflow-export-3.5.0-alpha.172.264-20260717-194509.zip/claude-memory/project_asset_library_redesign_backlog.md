---
name: project_asset_library_redesign_backlog
description: "Backlog Asset Library — deliveries di progetto popolano gli assets, operatore associa file esistente (no upload)"
metadata: 
  node_type: memory
  type: project
  originSessionId: 15d1c523-2657-4f72-bd97-d7599104853e
---

Asset Library & Filesystem scan **vanno riprogettati** (feedback Matteo 12 lug 2026, /remote-control). BACKLOG: ci si lavora **dopo** aver finito email + calendario.

**Modello mentale corretto (da chiarire nel redesign):**
- Il link vero è **quotazione → planning → deliveries → assets**.
- Le **deliveries** (dalle quotazioni, messe in lavorazione via planning) **popolano gli assets**.
- Quando una delivery entra in lavorazione, l'**operatore la associa a un file** esistente sul filesystem.
- I **file NON vanno caricati** (no upload): si punta/associa al file già presente. Coerente con pattern DocumentLink/EmailLink (solo riferimento, no storage).

**Why:** oggi il link asset↔delivery di progetto è poco chiaro; il flusso reale parte dal capitolato/quotazione e scende fino all'asset consegnabile. Vedi [[project_capitolato_deliverable_link]] (catena FK capitolato→quote→job→planning) e [[project_dam_physical_assets]].

**How to apply:** al ritorno sul tema, progettare la UI/dati in modo che l'asset nasca dalla delivery pianificata e l'operatore agganci un percorso file, non un upload. Non tappare buchi singoli — approccio generico ([[feedback_approccio_generico]]).
