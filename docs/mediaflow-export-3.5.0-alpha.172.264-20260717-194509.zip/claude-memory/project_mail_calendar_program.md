---
name: project_mail_calendar_program
description: Programma 4 sotto-fasi email client + calendario reale + AI copilot (post α.247)
metadata: 
  node_type: memory
  type: project
  originSessionId: 5831b190-1b19-417b-b417-a8379c88c130
---

Programma deciso 11 lug 2026 (ramo `feat/mobile-responsive-email`), dopo che Matteo ha chiesto client email completo tipo Thunderbird + calendari visibili + AI ovunque + look sleek. Ordine confermato 1→2→3→4, ogni sotto-fase = spec+plan+TDD+smoke+commit propri.

**1. Calendari — i miei calendari** ✅ α.172.248 (`8400115`). Sidebar lista calendari Google (colore+toggle per-calendario), voce fissa Claqo, overlay filtrato per calendario visibile (localStorage `mf_cal_hidden`). Endpoint `/calendar/api/google-calendars`. Spec `docs/superpowers/specs/2026-07-11-calendar-my-calendars-design.md`.

**2. Email client core** — Gmail-native (scope `gmail.modify`+`gmail.settings.basic`, deciso). Split 2a-2d:
- **2a Azioni & organizzazione** ✅ α.172.249 (`bd469af`): letto/non-letto, stella, archivia, cestino, sposta-etichetta (singolo+bulk multi-select), conteggi non-letti, paginazione, rispondi-a-tutti. `apply_action`/`modify_thread`/`trash` + `POST /mail/api/threads/action`.
- **Hotfix perf** ✅ α.172.250 (`dca2031`): lista lenta 5s = N+1 sequenziale in `list_threads`/`list_labels` → `ThreadPoolExecutor` parallelo.
- **2c compose avanzato** ✅ α.172.251+252 (`a7e711d`,`α.252`): editor WYSIWYG (execCommand, 9 font/7 size), allegati multipli accumulanti+drag&drop, firma persistente (`users.email_signature`), autosave bozze (debounce, `update_draft`), compose grande+massimizza+**pop-out** (`/mail/compose` standalone, partial `components/mail_compose.html`), mark-read-auto, **pannello ⚙️ impostazioni** (`users.mail_prefs` JSON: mark_read/autosave/auto_refresh/compose_new_window/default_font), **auto-sync** polling+focus, icone SVG azione. NB: 2c anticipata prima di 2b per feedback Matteo /remote-control.
- **2b cartelle/etichette** ✅ α.172.253 (`ec55d14`): sidebar etichette ad **albero** collassabile (`Parent/Child`), CRUD (crea+annida/rinomina/elimina, `gmail.create/rename/delete_label` + `POST/PUT/DELETE /mail/api/labels`), **ricerca avanzata** (Da/A/Oggetto/allegati/date → query Gmail).
- **2d rubrica/filtri/auto-reply** ✅ α.172.254 (`5753852`): impostazioni ⚙️ **a tab** (Generali/Rubrica/Filtri/Risposta-automatica). Rubrica read-only People (ricerca+Scrivi). Filtri Gmail CRUD (`list/create/delete_filter` + `/mail/api/filters`). Vacation responder (`get/set_vacation` + `/mail/api/vacation`). Scope `gmail.settings.basic`+`contacts.readonly` già presenti.

**Sotto-fase 2 (Email client core) CHIUSA** ✅ = 2a+2b+2c+2d. ~1214 test. Tutti i flussi live Gmail = smoke solo Matteo (reconnect necessario).

**3. Restyling sleek** ✅ α.172.255 (`1249d16`): blocco `.mail-*` in `sleek.css` (`body.sleek-mode`), allineato al layer esistente (radius/border tenui/hover/accent indigo/micro-label). Pop-out applica sleek da `localStorage.mf_sleek`. CSS-only.

**4. AI copilot mail** ✅ α.172.256 (`b668de3`): **Rispondi con AI** (`/mail/api/ai/reply`, `provider.complete`→bozza HTML→compose), **Ricerca semantica** (`/mail/api/ai/search`, NL→query Gmail), **Estrai** (inietta corpo nel copilot globale `#cp-input`+`copilotSend`, riusa registry `propose_*`). Provider per-utente. NB: slice mail (reply/search/extract); estensioni più profonde (azioni mailbox proposte, calendario semantico) = follow-up possibile.

**PROGRAMMA EMAIL+CALENDARIO CHIUSO** ✅ (fasi 1→4, α.248-256, ramo `feat/mobile-responsive-email` NON pushato). ~1217 test.

Prereq utente per smoke live (da α.247): riconnettere account Google (`/settings→Account`) + abilitare **Google People API** su Google Cloud. Scope Calendar `calendar` full, email `gmail.modify`+`gmail.settings.basic`+`contacts.readonly`. Le funzioni AI richiedono anche un provider AI configurato (Impostazioni→AI). Vedi [[feedback_smoke_e2e_browser]] — smoke email/calendario reale = solo Matteo (serve account connesso). Dopo smoke: valutare merge+push ramo, oppure [[project_asset_library_redesign_backlog]].
