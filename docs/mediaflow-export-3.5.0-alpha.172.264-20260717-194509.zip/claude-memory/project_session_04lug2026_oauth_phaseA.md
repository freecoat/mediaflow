---
name: project-session-04lug2026-oauth-phasea
description: "4 lug 2026 — Fase A OAuth foundation (account linking Google) merged main α.239, + pulizia 59 progetti test banner"
metadata: 
  node_type: memory
  type: project
  originSessionId: 1cfa5f87-c87d-4679-903d-695c25a37837
---

Sessione 4-5 lug 2026.

**Pulizia:** hard-delete 59 progetti "Test Project Banner" (TST-*) + 58 kdm_requests + 59 kdm_request_links (no altri figli). Nessun backup (scelta Matteo).

**Programma nuovo — account linking + calendario + documenti** (Acquisizioni Fase 3 + infra cross-cutting). Design doc `docs/superpowers/specs/2026-07-04-account-linking-calendar-documents-design.md`. 4 fasi A/B/C/D, un piano per fase.
- Decisioni: Claqo owner appuntamenti + sync bidirezionale; entità **CalendarEvent generica** (link espliciti nullable acquisition/project/activity/client); **solo Google** ora (Microsoft scaffold); **FullCalendar** CDN; sync = calendario dedicato "Claqo" + overlay primario read-only + import selettivo; documenti = collega riferimenti (URL+metadata) via Picker/paste.

**Fase A FATTA e MERGED main (dc7669d, non pushato) — v3.5.0-alpha.172.239.** Piano `docs/superpowers/plans/2026-07-04-phaseA-oauth-foundation.md`. 7 task subagent-driven TDD, full suite 1033 pass.
- Riusata infra OAuth già scaffoldata α.152 (`UserOAuthToken`, `oauth_providers.py`, router `/auth/oauth/*`).
- Scope Google **least-privilege** (security review): `calendar.app.created` + `calendar.readonly` + `drive.file` — NO scope pieno `calendar`.
- `get_valid_access_token()` refresh automatico (skew 120s, no db.commit — caller committa).
- CSRF **state firmato HMAC stateless** (`settings.secret_key`), rimpiazza `_state_store` in-memory. `verify_oauth_state` mai raise.
- Colonne `UserOAuthToken.auto_sync_calendar` + `claqo_calendar_id` (per Fase C) + `scripts/migrate_oauth_calendar.py` + auto-migrate boot + strumenti [P].
- `/auth/oauth/status` esteso + `POST /auth/oauth/{provider}/sync-toggle`.
- UI: card OAuth dentro **pane-account esistente** di /settings (non tab nuovo) + `settings_account.js` + 13 chiavi i18n `settings.account.*` ×5 lingue (runtime `mfT()`).
- Fix finali review opus: escape HTML callback OAuth (XSS `error` param), nome script migrazione in docs, dead `import secrets`.

**Fase A VALIDATA LIVE (5 lug)** su Google reale: Matteo ha registrato OAuth client (JSON in docs/google_api/ — gitignored), collegato fricot@gmail.com, token+refresh salvati in DB. Flow /start→consent→callback→save_token OK.
- Fix post-merge (non su branch): `avvia*.bat` usano `py` non `python` (stub Store) [a5fc437]; **bridge .env→os.environ in config.py** [f231e58] — vedi [[feedback_dotenv_not_loaded_osgetenv]] (era il 503, os.getenv non vedeva .env).
- Trappola Google: 403 access_denied = consent screen Testing + email non in Test users (NON serve verifica). Aggiungere email a Test users.
- Server dev: `.venv/Scripts/python.exe -m uvicorn app.main:app --host 127.0.0.1 --port 8000` (python nudo = stub Store rotto).

**PROSSIMO:** Fase B — `CalendarEvent` + vista FullCalendar + embed acquisitions + capability `propose_calendar_event`. Poi C (sync), D (documenti). Ogni fase = piano proprio.

Vedi [[feedback_i18n_always]] [[feedback_smoke_e2e_browser]] [[project_session_27giu2026_acquisizioni_f2]].
