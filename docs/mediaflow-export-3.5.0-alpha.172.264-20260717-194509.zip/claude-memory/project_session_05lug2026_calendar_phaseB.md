---
name: project-session-05lug2026-calendar-phaseb
description: "Fase B Calendario α.172.240 su feat/calendar-phaseB, NON pushato. CalendarEvent+FullCalendar+capability AI + fix snapshot _ACTION_HANDLERS"
metadata: 
  node_type: memory
  type: project
  originSessionId: b307c16c-088d-4664-974d-fcef0e8a3eb4
---

α.172.240 Fase B Calendario, ramo `feat/calendar-phaseB` (6 task TDD dal plan `docs/superpowers/plans/2026-07-05-phaseB-calendar-events.md`). Task 1-4 già committati sessione precedente; questa sessione chiuso **Task 5 + 6**.

- **Task 5** (ed3b919): tab "Appuntamenti" in detail-panel `/acquisitions` — usa var reale `_acqCurrentId` (module `let`, non `window.`). `acqDetLoadCalendarEvents`/`acqNewAppointment`, i18n `acq.detail.tab.calendar`+`noAppointments`.
- **XSS fix** (31e4a91): `meeting_url` linkificato SOLO se `/^https?:\/\//i` — `escapeHtml` non blocca schema `javascript:`. Flag da commit security review automatica.
- **Task 6** (6634406): capability AI `propose_calendar_event` (handler `_h_propose_calendar_event` in ai_assistant.py + schema in ai_tools.py TOOLS).

**Fix regressione α.236 (importante)**: `_ACTION_HANDLERS = _registry_get_handlers()` + `_sync_legacy_parser_action_types()` erano a metà `ai_assistant.py` (riga ~4456), PRIMA dei 4 handler acquisizioni (`propose_acquisition/activity/contact/acquisition_stage`, righe 4481+). `get_handlers()` ritorna dict FRESCO dallo snapshot → quei 4 erano in `_REGISTRY` ma ASSENTI da `_ACTION_HANDLERS` → `apply_action` (line ~174 `_ACTION_HANDLERS.get()`) falliva "Tipo azione non supportato" + invisibili a `VALID_ACTION_TYPES` (parser markdown Ollama/Perplexity). **Risolto**: snapshot+sync spostati a EOF del modulo, dopo TUTTI i `@ai_capability`. Aggiorna la trappola storica in [[project_session_19giu2026_kdm]] ("@ai_capability prima snapshot"): ora lo snapshot è in fondo, i nuovi handler non richiedono più posizionamento speciale. Test regressione: `test_calendar_capability.py::test_acquisition_handlers_registered`.

**Fase B.1 (6 lug, α.172.241, 4 commit fino baf81d1)**: rifinitura UX su feedback Matteo (sovrapposizioni, orari invisibili, no editing). Spec+plan `docs/superpowers/{specs,plans}/2026-07-06-*`.
- `event_modal.js` = modal evento condiviso (create/edit/delete, unica fonte scrittura eventi POST/PUT/DELETE), usato in `/calendar` + tab acquisizioni. Inietta DOM 1 volta, `window.openEventModal({event,prefill,onSaved})`. Segue pattern modal `.modal-overlay#id` + openModal/closeModal.
- calendar_page.js: vista default `timeGridWeek` (slot 07-22, nowIndicator, 24h), eventClick→edit, select/dateClick→new, drag/resize→PUT. Rimosso prompt().
- Tab acquisizioni: righe leggibili (titolo/fascia oraria/luogo/badge stato/link http(s)) + ✎/🗑, no prompt. `_apptStatusBadge`/`_apptWhen`.
- Trappole rispettate: mfT(key) 1-arg (ritorna key se assente → definite tutte le chiavi); helper globali non ridefiniti; data-* attributes no JSON-in-onclick; innerHTML solo markup statico (valori via .value).
- **Launcher**: creato `start.bat` (doppio clic, `.venv` diretto). avvia.bat si fermava su pause quando `python`=stub Store. NB Matteo confonde REPL (`python` nudo apre `>>>`) — serve `.venv/Scripts/python.exe run.py` (slash in Git Bash, no `!`).

**Stato**: 1053 test passed. Smoke Playwright verde (create id=2/edit/delete via modal, timeGridWeek, tab acquisizioni, 0 errori console; DB test ripulito). NON pushato (ramo feature, [[feedback_push_solo_major]]). PROSSIMO Fase C (sync Google bidirezionale, accende `auto_sync_calendar` di [[project_session_04lug2026_oauth_phaseA]]). Merge feat/calendar-phaseB→main dopo OK Matteo.
