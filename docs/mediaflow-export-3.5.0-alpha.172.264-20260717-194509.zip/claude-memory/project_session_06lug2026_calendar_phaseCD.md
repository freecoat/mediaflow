---
name: project-session-06lug2026-calendar-phasecd
description: "Fase C sync Google (α.242) + Fase D documenti Drive (α.243) su feat/calendar-phaseB, NON pushato. Ramo ora contiene B+B.1+C+D, pronto merge→main dopo smoke Matteo"
metadata: 
  node_type: memory
  type: project
  originSessionId: b30e7979-6374-4397-ab96-c80b990b0042
---

Ramo `feat/calendar-phaseB` (segue [[project_session_05lug2026_calendar_phaseb]]) ora contiene **B + B.1 + C + D**, tutto committato, NON pushato ([[feedback_push_solo_major]] ramo feature).

**Fase C — sync Google bidirezionale (α.172.242)**: push per-utente appuntamenti Claqo → calendario secondario "Claqo" su Google (`calendar.app.created`); overlay read-only eventi Google in `/calendar` (`calendar.readonly`); autosync on-save + bottone Sincronizza. `app/services/google_calendar.py` (urllib, `_google_request` mockabile) + `calendar_sync.py`. Endpoint `POST /calendar/api/sync`, `GET /calendar/api/google-overlay`. Best-effort (mai 500 su chiamate Google). Fix smoke: `ensure_claqo_calendar` fuori dal try → 403 propagata → 500; ora creazione calendario guardata.

**Fase D — documenti Drive collegati (α.172.243, QUESTA sessione)**: plan `docs/superpowers/plans/2026-07-06-calendar-phaseD-documents.md`, 5 task TDD, tutti committati (5bea045→45e3e62).
- `DocumentLink` (`document_links`, tenant-scoped, soft-delete) — collega file Drive a progetti/trattative, solo metadata+link, no storage locale. Migrazione `scripts/migrate_documents.py` + strumenti `[R]`/`[r]` (tabella creata anche da create_all al boot).
- `app/services/google_drive.py`: `parse_drive_file_id` (regex Drive/Docs/Sheets/Slides + `?id=`), `fetch_file_metadata` best-effort (unico `_drive_request` mockabile). Scope `drive.file` → file mai toccati dall'app danno 403/None → **fallback name "Documento Drive"**.
- `app/routers/documents.py`: link/list/delete/picker-config, RBAC runtime per `linked_type` (project→view/edit_projects, acquisition→view/manage_acquisitions), tenant via `scoped`/`fetch_or_404`. `_safe_url` http(s) only.
- `documents.js`: `mfDocInit/List/AddByUrl/Picker/Remove`; handler rimozione delegato bindato UNA volta via flag modulo `_mfDocClickBound` (mfDocInit richiamato a ogni apertura pannello trattativa → evita leak listener). Embed: sezione 📎 in `project_detail.html` (usa const `PROJECT_ID`); tab "Documenti" dedicato in `acquisitions.html` (reload lista su switch tab via `_acqCurrentId`).
- Google Picker: bottone "Scegli da Drive" nascosto se manca `GOOGLE_PICKER_API_KEY` (env, opzionale) o utente non connesso. Solo access_token effimero al client, mai refresh.

**Stato**: 1103 test passed. Smoke Playwright verde (project id=3 + acquisition id=2: add link fallback name, href sicuro, 🗑 rimuove, tab acquisizioni, Picker nascosto senza key; unico errore console = 404 preesistente favicon `/login`). **Chiude programma A/B/C/D** ([[project_session_04lug2026_oauth_phaseA]] Fase A OAuth).

**PROSSIMO**: merge `feat/calendar-phaseB` → main + push dopo smoke Matteo. **Prereq Matteo**: OAuth client Google Cloud reale (Calendar+Drive API, redirect `{OAUTH_REDIRECT_BASE_URL}/auth/oauth/google/callback`) per test live C+D; opzionale `GOOGLE_PICKER_API_KEY` per il Picker. Senza OAuth reale, feature funzionano in locale ma senza chiamate Google effettive.
