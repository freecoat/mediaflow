---
name: project-session-07lug2026-mail-client-f1
description: "Client email Sotto-fase 1 α.244 /mail webmail standalone su feat/mail-client-phase1 NON pushato. Gmail readonly+compose opt-in, gmail.py+mail.py stateless, iframe sandbox. Prossimo F2 integrazione CRM"
metadata: 
  node_type: memory
  type: project
  originSessionId: b30e7979-6374-4397-ab96-c80b990b0042
---

Nuovo programma **Client email** (Google, due vie), decomposto in 3 sotto-fasi. Brainstorm 7 lug con Matteo: vuole client Gmail-like completo (leggi+invia) + poi integrazione CRM. Scomposizione: **F1 = /mail webmail standalone** (questa sessione), F2 = integrazione CRM (tab Email nel detail cliente/trattativa, pin `EmailLink` pattern [[project_session_06lug2026_calendar_phaseCD]] DocumentLink, "Estrai con AI" riusa estrazione Acquisizioni [[project_session_27giu2026_acquisizioni_f2]], log Activity), F3 = auto-flow.

**α.172.244 F1** (ramo `feat/mail-client-phase1`, 7 task TDD, spec+plan `docs/superpowers/{specs,plans}/2026-07-07-mail-client-phase1*`):
- **Scope Gmail opt-in incrementale**: `gmail.readonly`+`gmail.compose` richiesti SOLO via `GET /auth/oauth/google/start?scopes=email` (nuovo param) con `include_granted_scopes=true`. NON nel bundle default `PROVIDERS["google"]["scopes"]`. `authorization_url(provider, state, extra_scopes=None)`. `UserOAuthToken.scopes` = fonte verità. Bottone "Collega Gmail" in settings_account.js card Google (mostra "Email ✓" se già). NB gmail.send era GIÀ nel bundle default (leftover Fase A) — lasciato.
- **`app/services/gmail.py`**: urllib, unico `_gmail_request(method,path,token,params,body)` mockabile; MIME via `email.message.EmailMessage` stdlib; base64url con padding `data+"="*(-len%4)`. Funzioni: list_threads/get_thread(`_normalize_message` walk MIME parts→body_html/text/attachments)/list_labels/build_mime/send_message/save_draft/list_drafts/delete_draft/get_attachment. Best-effort (token assente/403/rete→vuoto/None).
- **`app/routers/mail.py`**: proxy STATELESS (no tabella/migrazione), per-utente non tenant-scoped, `current_user`. `/mail` page + `/mail/api/{status,threads,thread/{id},labels,attachment/{msg}/{att},send,draft,drafts,draft/{id}}`. Registrato in main.py dopo documents_router. `templates` import deferred `from app.main import templates` dentro la funzione page.
- **Frontend** `mail.html`+`mail.js` 3-pannelli (nav label|lista thread|lettura)+compose modal (Nuovo/Rispondi/Rispondi-tutti/Inoltra/allegati/bozze). Globali `mfMailInit/LoadThreads/OpenThread/Compose/Send`. Voce sidebar Email (base.html dopo Calendar, icona lucide `mail`).
- **Sicurezza**: corpo email in iframe `sandbox=""` (no script) via srcdoc; immagini remote bloccate default (regex `src`→`data-blocked-src`, toggle "Mostra immagini"); confirm invio; allegati Content-Disposition attachment; escapeHtml su tutti i valori; nessun token al client.

**TRAPPOLA test router** (già in [[feedback_smoke_e2e_browser]] area): il middleware `auth_guard` (main.py ~2668) risolve l'utente da JWT cookie via `app.database.SessionLocal()` PRIMA del router → monkeypatch `current_user` sul modulo NON basta (401). Serve fixture pattern `test_documents_api.py`: JWT cookie reale `create_access_token({"sub":email,"tid":1})` + `monkeypatch.setattr(database,"engine"/"SessionLocal", test_engine/S)` + `dependency_overrides[get_db]`. Poi i test patchano `mailmod.gmail.<fn>`.

**Stato**: 1133 test passed (+30). Smoke Playwright verde: `/mail` degrada a CTA "Connect Gmail" senza opt-in (3 pannelli presenti, sidebar Email, compose modal apre con prefill, 0 errori console salvo 404 favicon /login preesistente). NON pushato. Live richiede Gmail API abilitata su Google Cloud + opt-in email da /settings. **PROSSIMO**: smoke Matteo → poi F2 integrazione CRM. Nota: `feat/calendar-phaseB` (A/B/C/D) MERGED main (a3b2893) non pushato.
