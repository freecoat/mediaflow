---
name: project_session_07lug2026_mail_client_f2
description: "Sessione 7 lug — Client email Sotto-fase 2 (integrazione CRM email trattative), α.172.245"
metadata: 
  node_type: memory
  type: project
  originSessionId: b71fa503-4f00-47a5-8102-8bb9fabab1f5
---

α.172.245 Client email **Sotto-fase 2** — integrazione CRM (trattativa). Ramo `feat/mail-client-phase2` NON pushato (commit 0c9757d), attende smoke Matteo. Continua [[project_session_07lug2026_mail_client_f1]].

**Cosa**: aggancia thread Gmail alle trattative (`acquisitions`).
- `EmailLink` (tabella `email_links`, tenant-scoped, soft-delete, pattern DocumentLink, ancorato solo `acquisition_id`, salva metadata+thread_id, no corpo). Migrazione `scripts/migrate_email_links.py` + voce strumenti.
- `gmail.parse_gmail_thread_id(url)` — estrae thread id da URL Gmail (#inbox/ID, #label/N/ID, #search/q/ID, ?th=ID); non-Gmail→None.
- Router `app/routers/email_links.py`: `POST /acquisitions/api/{aid}/emails/link` (pin da thread_id o url, metadata best-effort da get_thread, fallback subject "Email"), `GET /acquisitions/api/{aid}/emails`, `DELETE /email-links/{id}` (soft). RBAC acquisitions. **Pin logga Activity(type=email,inbound) automatica**.
- Frontend `email_links.js` (tab "Email" in acquisitions.html): ricerca Gmail in-tab + incolla-link→Aggancia; lista pinnati + anteprima iframe sandbox + Estrai-AI (inietta corpo nel copilot, no backend AI) + 🗑. Wiring in acqDetTab/acqOpenDetail (righe 835-836,856).
- `mfMailAssign` in mail.js: "Assegna a trattativa" dal `/mail` (picker via `/acquisitions/api/list` che ritorna `{items:[...]}` con prospect_name+title).
- i18n 5 lingue `email.*`.

6 task TDD (plan `docs/superpowers/plans/2026-07-07-mail-client-phase2.md`), 1152 test verdi. **Smoke browser Playwright verde**: tab switch, pin-by-URL crea EmailLink (subject fallback "Email" senza token Gmail), auto-Activity email confermata, soft-delete OK, 0 errori console.

**PROSSIMO**: smoke Matteo, poi **Sotto-fase 3** (auto-flow: auto-associazione per indirizzo mittente, AI senza pin manuale, notifiche).

Trappola: `acqOpenDetail(aid)` fetcha `/acquisitions/api/{id}` — id inesistente = 404 console (non bug). Test data acquisitions id=2 Filmino, id=3 Filmetto.
