---
name: project-session-13lug2026-media-library-fasea
description: "Media Library Fase A (α.172.244 read-only) + Fase B (α.172.245 azioni mutanti+supersede) completate, ramo feat/media-library NON pushato/NON mergiato"
metadata: 
  node_type: memory
  type: project
  originSessionId: 93fc556f-8c0c-4094-b989-29f925a1542f
---

Sessione 13 lug 2026: completata **Media Library Fase A** su ramo `feat/media-library` (v3.5.0-alpha.172.244). Piano `docs/superpowers/plans/2026-07-12-media-library-phaseA.md`, 7 task TDD eseguiti con executing-plans skill.

**Cosa fa**: `/media` browser **read-only** che fonde `Asset` (digitale) + `PhysicalAsset` (fisico) tenant-scoped, ordinati `created_at DESC`, paginazione best-effort cross-natura. Zero mutazioni (bulk disabilitati). Filtri 4 gruppi: contesto/natura/consegna/tech. Dettaglio con tech_specs completo + deliverables.

**File chiave**: `app/services/media_library.py` (list_assets/filter_options/asset_detail/_delivery_info), `app/routers/media.py`, `app/services/media_gate.py` (permesso `manage_assets`, retrocompat `edit_planning_all`), `scripts/migrate_manage_assets.py`, `app/templates/pages/media_library.html`, `app/static/js/media_library.js`.

**Trappole risolte**:
- tech_specs_json shape reale **nidificato** `$.video.codec/width/height/framerate` (NON flat come ipotizzava il piano) → `json_extract` adattato.
- `PhysicalAsset` soft-delete via `deleted_at` (filtrare), checksum = `checksum_xxhash`/`checksum_md5` (non `checksum`).
- `assets.uploaded_by` NOT NULL (seed smoke).
- Gating: filtro esclusivo di una natura (asset_type/proposed_state/tech = digitale; physical_kind = fisico) restringe l'elenco a quella natura.

32 test verdi (rbac 2 + library 23 + api 7). Smoke Playwright verde (DB copia + 2 asset + 1 LTO, login admin → 3 righe merge, ricerca, dettaglio tech-specs, 0 errori console).

## Fase B (α.172.245, stesso ramo/sessione — 6 task TDD)

Piano `docs/superpowers/plans/2026-07-13-media-library-phaseB.md`. Attiva le **azioni bulk** in `/media` (prima disabilitate): **Associa a consegna**, **Archivia**/**Smarca** (`is_internal_archive`), **Scollega**, **Esporta CSV**. Gate `manage_assets` (viewer 403).

**Supersede** (semantica chiave): associare un asset a una consegna con già un attivo della stessa natura → vecchio link **superseduto** (storico conservato, NON cancellato) + stato consegna `qc/delivered/closed` → `in_progress` (+ notifica `deliverable_reopened_supersede` a `view_finance`). 3 colonne nuove su `DeliverableAsset`: `superseded_at`/`superseded_by_id`/`supersede_reason`. `_resync_primary` ignora i superati (→ primario = nuovo asset).

**File**: `app/services/media_actions.py` (associate/set_flags/unlink/export_manifest_csv, read-write, riusa `deliverable_assets.link_asset/unlink_asset`), `app/routers/media.py` (`POST /media/api/{associate,flags,unlink}` Form + `items` JSON, `GET /media/api/{export,deliverables}`), `scripts/migrate_deliverable_asset_supersede.py` + auto-migrate boot. UI: modal Associa/Scollega cascata progetto→consegna in `media_library.html`+`.js` (riusa `openModal/closeModal`), badge superseduto barrato (`_deliverables_list` espone `superseded`). i18n 5 lingue `media.assocBtn`…`media.superseded`.

**Trappola**: `Job.client_id` NOT NULL (seed smoke). CSV export cap 5000. `set_flags` salta asset coda-interna (project_id None) per non-admin.

59 test media verdi (supersede_model 3 + actions + api). Smoke Playwright verde (associa a_new a SMOKE DCP delivered → vecchio superseduto, digital_asset_id→a_new, stato in_progress, `superseded:true` nel dettaglio, 0 errori console).

**Ramo `feat/media-library` NON pushato, NON mergiato.** Fase A (6 commit) + Fase B (8 commit, ultimo `e5c8d26`). PROSSIMO: smoke Matteo sul Mac (`scripts/migrate_manage_assets.py` + `scripts/migrate_deliverable_asset_supersede.py`) → poi **merge → main** (A+B) oppure Fase C. Vedi [[project_asset_library_redesign_backlog]] [[project_dam_physical_assets]] [[project_capitolato_deliverable_link]].
