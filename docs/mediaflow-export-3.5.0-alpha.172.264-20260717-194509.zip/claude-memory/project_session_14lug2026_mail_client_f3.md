---
name: project_session_14lug2026_mail_client_f3
description: "Sessione 14 lug — Client email Sotto-fase 3 Rubrica Contatti, α.172.246, ramo feat/mail-client-phase3"
metadata: 
  node_type: memory
  type: project
  originSessionId: 9092570b-26c1-4d24-9a81-44c4f3631c75
---

α.172.246 **Client email F3 — Rubrica Contatti** (riformulazione del "auto-flow" originale). Ramo `feat/mail-client-phase3` (da `feat/mail-client-phase2`) NON pushato/mergiato. 16 task TDD. Primo uso del workflow [[feedback_sonnet_plan_opus_exec]]: brainstorm+spec (Opus) → piano Sonnet subagent → esecuzione Opus. Continua [[project_session_07lug2026_mail_client_f2]].

**Pivot brainstorm**: Matteo ha ri-centrato F3 da "auto-associazione thread→trattativa" a **Rubrica Contatti** standalone alimentata dalle email.

**Cosa**:
- `Contact.client_id` → **nullable** (contatti orfani) + `company_text`/`source`. Join M:N `contact_acquisitions`/`contact_projects` (Contact↔trattativa e ↔progetto; client_id resta FK singolo = azienda). Retrocompat piena endpoint client-scoped + `_sync_primary`.
- Migrazione `scripts/migrate_contacts_rubrica.py`: SQLite **non fa DROP NOT NULL** → rebuild tabella (regex strip NOT NULL da sqlite_master, pattern `migrate_deliverable_audio_label.py`). Idempotente + auto-migrate boot + strumenti `[u]`/`[U]`.
- Pagina `/contacts` (router esteso `app/routers/contacts.py`): list/match/detail/create(dedup email)/update/link/unlink. UI `contacts.js` (lista, MFFilterBar triage, dettaglio, **picker associa** cliente/trattativa/progetto via /clients/api /projects/api /acquisitions/api/list, dissocia ✕). Sidebar "Rubrica".
- Estrazione `app/services/contact_extract.py` (deterministico partecipanti+firma regex, gratis; `enrich_with_ai` opzionale). Endpoint `/contacts/api/extract` + `/extract/enrich`. Bottone "Estrai contatto" in mail.js + email_links.js (contacts.js incluso su mail.html+acquisitions.html per le funzioni condivise).
- Ponte scheda tecnica: `POST /contacts/api/from-tech-sheet` + bottone "Salva in rubrica" pane Crew project_detail.html (scrive `contact_id` nel JSON `data.contacts[idx]`).
- Copilot `propose_contact` esteso (client_id opzionale + acquisition_id/project_id); descriptor ai_tools.py `required:["name"]`.
- Notifiche on-demand: `GET /contacts/api/notify-badge` + badge tab Email trattativa (best-effort, no push). Rotta letterale PRIMA di `/contacts/api/{cid}` (collisione Starlette int-parse).

**Trappole risolte**:
- Euristica firma del piano prendeva la prima riga (frase/nome) come ruolo → riscritta: skip righe-frase (virgola/punteggiatura finale), convenzione nome→ruolo = 2ª riga di testo.
- Security review flaggò IDOR su link/unlink = **falso positivo**: `fetch_or_404`→`scoped()` filtra già tenant_id.
- Piano Sonnet aveva lasciato il picker "associa" come follow-up; corretto via [[SendMessage]] (spec §2 lo richiede).
- i18n: `common.save/cancel` NON esistono → usato `btn.save`/`btn.cancel`; chiavi `contact.*` nuove 5 lingue.

**Stato**: 1196 test verdi (suite completa 6.5min). Smoke Playwright verde (DB copia reale + JWT admin mint + uvicorn no-reload dev; crea contatto→dettaglio→picker trattative reali→associa→refresh ✕ + lista "1 🎯"; /mail+/acquisitions 0 errori console). Commit finale 40803d5.

**PROSSIMO**: smoke Matteo (`scripts/migrate_contacts_rubrica.py`) → merge `feat/mail-client-phase3` → main (chiude Client email F1+F2+F3). NB rami pendenti anche `feat/media-library` (A+B) e `feat/mail-client-phase2`. Follow-up possibile: mostrare contatti rubrica del progetto nella scheda tecnica (link inverso).
