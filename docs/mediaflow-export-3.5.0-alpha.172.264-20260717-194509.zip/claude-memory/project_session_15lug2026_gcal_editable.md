---
name: project_session_15lug2026_gcal_editable
description: "15 lug — merge F1+F2+F3 su main, fix oggetto /mail, eventi Google Calendar editabili (α.247/248)"
metadata: 
  node_type: memory
  type: project
  originSessionId: 5203352a-6664-4f8f-9f6d-795ef8cec547
---

Ramo `main` a α.172.248, **NON pushato** (88 commit avanti). Tre commit: `175b42b` merge Client email F1+F2+F3, `092a3f1` fix oggetto `/mail`, `310897a`+`1beff59` eventi Google editabili.

**Diagnosi chiave**: Matteo segnalò "email sbagliate + calendario rotto, huge regression dopo il merge". Il merge era un **no-op** (`git diff phase3 main` vuoto). Nessuna delle due era una regressione del merge:
- `/mail`: bug di F1 mai funzionante (vedi [[feedback_mock_shape_must_match_real_api]]).
- Calendario: i 3 `CalendarEvent` erano soft-deleted da UI il 5–7 lug (unico writer di `is_active=False` = DELETE a `calendar.py:218`); l'overlay Google era `editable:false` **by design** Fase C. Lezione: quando l'utente dice "regressione", verificare l'ipotesi contro il DB/runtime prima di accettarla — qui tre ipotesi plausibili (OAuth scope, RBAC, migrazione) sono state uccise dall'evidenza.

**α.172.248 — eventi Google editabili**: scope opt-in `calendar.events` (non `calendar` pieno), `accessRole` di `calendarList` finalmente onorato (c'era ma era ignorato → i calendari festivi sarebbero stati editabili), ricorrenze escluse, PATCH+If-Match (412→409), eliminazione a **due passi** (irreversibile su Google). Overlay ora logga + `error:true` invece di inghiottire. 1239 test.

**PENDENTE**: il percorso **OAuth reale non è mai stato esercitato** — lo smoke ha usato Google mockato su DB scratch. Matteo deve fare `/settings` → "Attiva editing calendario" → consenso reale → verificare `/calendar`. **Limite noto**: drag&drop senza etag = last-write-wins (l'overlay non espone l'etag per-evento); il modale è protetto.

Design/piano: `docs/superpowers/specs|plans/2026-07-15-google-calendar-writable-*`. `feat/media-library` (A+B) attende ancora merge. Vedi [[project_session_14lug2026_mail_client_f3]].
