---
name: project_session_15lug2026_mail_body_etag
description: α.172.250 su main (9a5d8b0) NON pushato — corpo email 300x150 (CSS mail-* mai esistito) + etag drag&drop Google. Smoke Gmail/Google reali
metadata: 
  node_type: memory
  type: project
  originSessionId: 227df87d-1ac4-4ee4-9d85-24cbf459153b
---

**v3.5.0-alpha.172.250** — 15 lug 2026, commit `9a5d8b0` diretto su `main` (nessun ramo). **111 commit avanti, NON pushato** (policy locale, vedi [[feedback_push_solo_major]]). 1306 test verdi.

Due difetti indipendenti, **entrambi dichiarati come limiti noti** nelle fasi precedenti e mai chiusi:

**1. `/mail` corpo email = francobollo 300×150.** `_mailRenderBody` emetteva `<iframe class="mail-body-frame">` dalla F1 (α.172.244), ma **la classe non esisteva in NESSUN CSS** — zero regole `mail-*` in main/sleek/mobile.css. Un iframe senza width/height cade sul default UA 300×150. Aggiunto blocco `mail-*` in `main.css` + auto-altezza `mfMailFitFrame`.
- **Decisione sicurezza (approvata da Matteo)**: `sandbox=""` → **`sandbox="allow-same-origin"`**, necessario perché con origine opaca il parent non può leggere `contentDocument.scrollHeight`. **MAI `allow-scripts`**: i due insieme annullano il sandbox. Provato a runtime con email ostile (`<script>` inline + `img onerror`) → entrambi bloccati. `test_mail_body_frame_never_allows_scripts` presidia la coppia (controlla gli attributi `sandbox` via regex, non il sorgente grezzo: "allow-scripts" compare nei commenti).
- Iniettato `_MAIL_BODY_CSS` nel frame: le email non portano font-size di base → cadevano su Times 16px.
- `&` non escapato in `srcdoc` mangiava le entità (in un attributo `&amp;` → `&`).

**2. `/calendar` drag&drop Google last-write-wins** (limite dichiarato in α.172.248). Il modale mandava If-Match, `_calPutTimes` no: l'overlay non esponeva l'etag. Ora `_normalize_google_event` lo produce (overlay + `get_external_event`) → `extendedProps` → PUT. **Va riallineato dalla risposta** (`setExtendedProp`): senza, il 2° drag consecutivo dà un **409 falso**. Sul 409 → revert + `refetchEvents()`.

**Smoke**: DB **copia scratch** in scratchpad (env `DATABASE_URL` vince su `.env` — verificato con `engine.url`, non assunto), Gmail/Google **reali in lettura**. 25 thread, frame 419×2495, 5/5 eventi con etag, 1 editabile owner. **La PATCH stubbata**: scrivere avrebbe mutato il calendario reale di Matteo.

**Scoperta**: il token Google in DB ha già lo scope **`calendar` pieno** (superset) → l'editing calendario è **già attivo** per Matteo senza opt-in.

**PENDENTE**: smoke Matteo = (1) `/mail` corpo, (2) **trascinare davvero** un evento Google (unico passo che l'AI non può fare), (3) `/media` (2 migrazioni). Rami `feat/mail-client-phase1/2/3` + `feat/media-library` mergiati e **cancellabili**.

Vedi [[project_session_15lug2026_gcal_editable]], [[feedback_smoke_e2e_browser]].
