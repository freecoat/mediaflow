---
name: project_session_17lug2026_mail_ctxmenu_contacts
description: "α.172.263 mail context-menu+drag-label+select-all+scope mail_full+redesign modale contatti, MERGED main 6fe5959 non pushato"
metadata: 
  node_type: memory
  type: project
  originSessionId: 1af54fad-1935-4b58-912d-eae11ab4ca15
---

**α.172.263** (17 lug) MERGED main `6fe5959` (no-ff), NON pushato. Ramo `feat/mail-context-menu-contacts` conservato (cancellabile dopo smoke Matteo). Spec+plan `docs/superpowers/*/2026-07-17-mail-context-menu-drag-select-contacts*`. Sonnet-plan/Opus-exec, 13 task TDD, 1401 test verdi.

**Fatto**: context menu tasto destro /mail (`mfMailOpenContextMenu` in mail.js, archivia/cestino/letto/stella/spam + submenu sposta-in-etichetta▸ solo label utente + voci gated elimina-definitivo/svuota-cestino con doppio confirm) + drag&drop righe→etichetta (=move, add label+remove INBOX) + select-all header (indeterminate) + redesign modale contatti sezionato + campo Note. Backend: scope opt-in `mail_full`=`https://mail.google.com/` (gmail.modify NON cancella fisicamente), `has_mail_full_scope`, `delete_thread_forever`/`empty_trash`, gate 403, `POST /mail/api/trash/empty`, bottone opt-in /settings.

**Scoperta chiave**: verbi `apply_action`/`_ACTION_LABELS` (read/unread/star/unstar/archive/spam/move/label/unlabel) GIÀ tutti presenti dal merge α.262 → backend nuovo ridotto a delete fisico. `Contact.notes` già in models.py:4843 → nessuna migrazione.

**Trappole risolte**: CSS mail vive INLINE nel `<style>` di mail.html (palette `--bg2/bg3/border2/accent/text3`, NON main.css/`--surface`); `.form-row` già in main.css (riusata). Tasks 7-9 (stessa funzione riscritta 3×) consolidati in 1 commit. Full suite background si fa KILLARE (>10min infra), foreground completa 389s.

**PENDENTE**: smoke interattivo Matteo (Google reale — context menu su thread veri, drag, opt-in mail_full→elimina-definitivo).

**α.172.264** (17 lug) MERGED main `40883ce` (ramo `fix/settings-email-badge-scope`), non push: fix badge "Email ✓" /settings — controllava solo `gmail.readonly` ma GMAIL_SCOPES dal merge α.262 = `gmail.modify` → badge spento con Gmail connesso. `hasMail` ora accetta modify (superset) o readonly (legacy), coerente con `_GMAIL_READ_SCOPES` server. Solo frontend.

Vedi [[feedback_git_add_all_sweeps_stray_in_merge]], [[feedback_sonnet_plan_opus_exec]], [[project_mail_calendar_program]].
