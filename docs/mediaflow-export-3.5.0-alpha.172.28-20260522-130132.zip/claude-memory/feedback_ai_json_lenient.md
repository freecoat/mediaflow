---
name: AI parser JSON deve essere tollerante a commenti e trailing commas
description: I modelli open-source piccoli infilano commenti // e virgole finali nei blocchi action; il parser deve gestirli o le azioni spariscono silenziosamente
type: feedback
originSessionId: 73b0a440-ba67-42e1-847b-2d242e61f050
---
Quando il copilot di MediaFlow restituisce blocchi `action` con JSON, i modelli open-source piccoli (Llama 3.1 8B, Qwen 7B) frequentemente generano JSON non strict:
- commenti a fine riga `// commento`
- commenti a blocco `/* ... */`
- virgole finali prima di `}` o `]`
- (più raro) apici singoli al posto di doppi

`json.loads()` strict fallisce su tutto questo, l'azione viene scartata in silenzio, il drawer del copilot non mostra la card di conferma, l'utente vede solo il testo della risposta e nessuna azione applicabile.

**Why:** Bug reale 2026-04-27 con prompt "Aggiungi una quotazione per Gomorra…": Ollama 8B ha generato `"number": null, // verrà generato automaticamente` e altri 3 commenti — `safe_json_parse` ritornava None, niente AIAction salvata. Sistemato in v3.4.1 con strip state-aware + system prompt rinforzato + warning log.

**How to apply:** Quando si tocca `safe_json_parse` o si aggiungono nuove capability AI:
1. Mantenere la cascata: parse strict → strip commenti+commas → regex first-block. Non tornare a un singolo `json.loads()`.
2. Lo strip dei commenti deve essere state-aware sulle stringhe per non rompere URL `https://...` o stringhe con `//`.
3. Loggare con `logger.warning` quando si incontra un blocco action non parsabile o con type non valido — il silenzio è il vero nemico del debug.
4. Nel system prompt, includere SEMPRE la sezione "FORMATO JSON OBBLIGATORIO" con divieto esplicito di commenti e trailing commas. Senza, anche modelli grossi (GPT-4o, Sonnet) talvolta li mettono per "spiegare al lettore".
