---
name: Sempre approccio generico, non tappare buchi
description: Quando Matteo chiede una feature, propongo prima il modello generico riusabile, non il fix puntuale
type: feedback
originSessionId: 597bbfea-aac6-4cdd-a74f-edcc57fda2cc
---
Quando Matteo richiede una feature, devo:
1. Proporre prima un'architettura **generica** che servirà anche a richieste future
2. Esplorare in-depth le conseguenze (modello dati, hook, UI, permessi, interazioni con altri pezzi)
3. Fare proposte ampie, non minimali
4. Fare domande esplicite quando ci sono decisioni di design importanti

**Why:** Direttiva esplicita di Matteo (30 aprile 2026 notte): "Stiamo sviluppando, non tappando buchi. Tieni sempre presente come implementare funzioni generali per le mie richieste ed esplora in-depth le possibili conseguenze. Fammi domande se ne hai e fai proposte come stai facendo anche più ampie e generiche." Caso scatenante: chiedendo di vedere le richieste ferie pending da approvare, ho proposto sia il fix specifico che un sistema notifiche generico — lui ha confermato che è il pattern giusto sempre.

**How to apply:**
- Prima di scrivere codice: proponi modello dati, servizio, endpoint, UI, hook con altri pezzi del sistema
- Lista esplicita delle decisioni di design da prendere (con il tuo consiglio + tradeoff)
- Fai domande specifiche, non generiche — ogni domanda deve avere il tuo consiglio chiaro per accelerare la risposta
- Default: lavoro più grande ben architettato vs lavoro piccolo che andrà rifatto
- Tieni a mente la roadmap: progettare per supportare anche cantieri futuri (mobile/cliente, multi-tenant hard, ecc.)
- Eccezione: bug fix critici (login rotto, crash) → fix puntuale immediato, refactoring generico in commit separato dopo
