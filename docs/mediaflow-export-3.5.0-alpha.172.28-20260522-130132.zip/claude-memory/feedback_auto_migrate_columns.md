---
name: Auto-migrate colonne nuove al boot
description: Quando aggiungi una colonna al modello, aggiungila ANCHE in _auto_migrate_columns() di main.py per evitare crash se utente non lancia migrate
type: feedback
originSessionId: 597bbfea-aac6-4cdd-a74f-edcc57fda2cc
---
Quando aggiungo una nuova colonna a un modello SQLAlchemy esistente, oltre a scrivere `scripts/migrate_*.py`, devo aggiungere il check anche in `_auto_migrate_columns()` dentro `app/main.py` lifespan. Altrimenti se Matteo fa pull e riavvia senza eseguire la migrazione, l'app crasha al primo SELECT che tocca la colonna.

**Why:** in v3.4.25 ho aggiunto `users.extra_permissions` con script di migrazione `[K]` opzione strumenti.bat/sh. Matteo ha pull-ato e riavviato senza lanciare `[K]` → login crash con `OperationalError: no such column: users.extra_permissions`. Hotfix v3.4.25.1 = aggiunto auto-bootstrap nel lifespan.

**How to apply:**
- Quando modifico `app/models/models.py` aggiungendo una colonna a una tabella esistente:
  1. Scrivo `scripts/migrate_*.py` esplicito (per chiarezza nei log + opzione manuale)
  2. **Aggiungo check in `_auto_migrate_columns()` di `app/main.py`**: se la colonna manca, ALTER TABLE idempotente
  3. Aggiorno `strumenti.bat/sh` con la nuova opzione
- Pattern code per check:
  ```python
  insp = inspect(engine)
  if "<table>" in insp.get_table_names():
      cols = {c["name"] for c in insp.get_columns("<table>")}
      if "<col>" not in cols:
          with engine.begin() as conn:
              conn.execute(text("ALTER TABLE <table> ADD COLUMN <col> <type> NULL"))
  ```
- Eccezione: per cambi schema pesanti (FK forti, rename, split tabelle) fermati e chiedi a Matteo se vuole comunque autobootstrap.
