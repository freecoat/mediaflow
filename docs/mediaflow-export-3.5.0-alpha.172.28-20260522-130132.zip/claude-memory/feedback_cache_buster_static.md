---
name: Bump cache-buster static asset quando modifichi
description: Modificare static/js/global.js senza bumpare ?v= in base.html = bug invisibile per cache browser
type: feedback
originSessionId: 597bbfea-aac6-4cdd-a74f-edcc57fda2cc
---
Ogni volta che modifico un asset statico incluso con cache-buster `?v=...` (es. `<script src="/static/js/global.js?v=X.Y.Z">`), DEVO bumpare il querystring nel template che lo include. Altrimenti il browser di Matteo continua a servire la versione cached → la modifica sembra non applicata e i bug sembrano persistere.

**Why:** in v3.4.24 ho aggiunto `escapeHtml` a `global.js` per fixare crash su `/admin/users` + `/admin/roles` + `/hr`. Matteo dopo il pull mi ha rimandato esattamente lo stesso `ReferenceError`. Causa: `?v=3.2.1` in `base.html` non bumpato → file cached. Hotfix v3.4.24.1 = solo bump del querystring. **Insegnamento doppio**: (a) auto-controllo prima di chiudere una versione che modifica static asset, (b) un sintomo identico dopo un fix non significa "il fix non funziona" ma spesso "il fix non è arrivato al browser".

**How to apply:**
- Modifica `static/js/global.js` o altro JS con cache-buster → `Grep "global.js\?v="` per trovare l'inclusione → bump al numero di versione corrente in `base.html` o nel template specifico.
- Stesso vale per `copilot.js?v=` in `components/copilot.html` se mai ne modifico la logica.
- `static/css/main.css` non ha cache-buster oggi (rischio analogo, da bumpare se vado a modificarlo o aggiungerlo poi).
- **Smoke test mentale prima del commit**: ho toccato un file `.js` o `.css` static? Sì → bump del query-v. Sempre.
