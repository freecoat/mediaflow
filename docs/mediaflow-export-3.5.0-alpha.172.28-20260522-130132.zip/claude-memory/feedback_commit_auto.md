---
name: Commit automatici a fine versione
description: Matteo vuole che committi senza chiedere conferma quando chiudo una versione (bump main.py + CHANGELOG + STATO + commit)
type: feedback
originSessionId: 2b4b36bf-a717-4764-bc5b-89f52b45072e
---
A fine di ogni versione (bump `app/main.py` + voce `CHANGELOG.md` + aggiornamento `docs/STATO.md`), procedo con `git add` + `git commit` senza chiedere autorizzazione.

**Why:** Matteo me l'ha detto esplicitamente il 2026-04-28 dopo v3.4.8.1: "Effettua i commit in automatico d'ora in poi." Lo ha rinforzato in v3.4.9.1: "Mi raccomando procedi con le spunte automatiche dei commit, che non voglio ogni volta pigiare su 1 e 2 per approvare le tue lavorazioni!". È fastidioso per lui dover approvare ogni comando.

**How to apply:**
- Vale per il flusso normale: chiudo lavoro → bump versione → CHANGELOG → STATO → commit.
- Continuo a usare HEREDOC per il messaggio (richiede multi-line) e a includere `Co-Authored-By: Claude Opus 4.7`.
- NON estendo l'autonomia ad azioni distruttive: niente `push --force`, `reset --hard`, `branch -D`, skip hooks. Quelle restano da chiedere.
- NON estendo a `git push` su remote (non lo ha mai chiesto, non c'è remote configurato).
- Se lavoro è ambiguo o ci sono cambi non programmati nel diff → chiedo prima.
