---
name: communication-tips-next-session
description: "Matteo ha chiesto esplicitamente (19 mag 2026) suggerimenti su come migliorare la sua comunicazione delle richieste. Da consegnare a inizio prossima sessione, NON spontaneamente nel mezzo del lavoro."
metadata: 
  node_type: memory
  type: feedback
  originSessionId: ce2e09d6-ef4e-475c-be29-f36649645184
---

Matteo ha chiesto (19 mag 2026, fine sessione α.171.11): "Se possiamo trovare un modo di migliorare la mia comunicazione, fammelo sapere nella prossima sessione. So che ho dei limiti importanti, ma non so bene come migliorare e strutturare meglio: accetto i tuoi suggerimenti in merito."

**Why:** richiesta esplicita di feedback strutturato. Vuole crescere nella collaborazione, non rimanere passivo.

**How to apply:** appena entrato in nuova sessione, dopo log report di apertura ([[feedback_log_report_apertura]]), prima di nuove richieste implementative, presentare 3-5 suggerimenti CONCRETI basati su osservazioni reali di sessioni passate. NON inventare consigli generici. Esempi osservati questa sessione (α.171.11):

1. **Ancora ogni issue a URL/route**. Es. "issue 4 in cashflow" è OK ma "in /finance/cashflow tab Cassa" è meglio. Riduce ricerca route da parte mia.
2. **Per UI bug, includi sempre uno o due artefatti tecnici**: screenshot (path standard in [[reference_screenshots_path]]), errore console DevTools, o body della response HTTP 4xx/5xx. La diagnosi parte dall'evidenza, non dall'inferenza.
3. **Per "non funziona X perché disattivato/Y"**: dichiara cosa hai tentato + cosa è greyed-out + se hai visto un tooltip/messaggio. Issue 2 "Attacca a quote pending è disattivata" → senza condizione (zero pending quotes) non capivo se era bug o by-design.
4. **Esempi numerici concreti come issue 1 (10000 / 8000)** sono ECCELLENTI. Replica questo stile su tutte le issue finanziarie: cifra quotata, cifra reale, scenario attivante. Riduce ambiguità del 70%.
5. **Prioritizzazione esplicita**: P0 (blocca lavoro), P1 (fastidioso), P2 (nice-to-have). Issue 3 era P0 (impedisce salvataggio) ma non l'ho saputo finché non l'ho letto.
6. **Per feature richieste (vs bug)**: scrivi 1 frase "perché" oltre al "cosa". Issue 1 fattura esterna senza booking: il *perché* (azienda esterna delegata, no booking interno) sarebbe stato utile in apertura per disegnare meglio l'architettura.

NON dare TUTTI questi punti insieme — selezionare i 2-3 più rilevanti in base a cosa è successo da ultimo. Se ha lavorato bene su qualcosa, citalo (rinforzo positivo): es. "il riepilogo numerico in issue 1 era esemplare, replica quello stile".

Aggiornare questa memoria quando emergono nuovi pattern (positivi o migliorabili) da feedback reale.
