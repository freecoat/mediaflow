---
name: feedback-env-untracked
description: ".env è UNTRACKED da git dal 12 mag 2026 (era trackato dal 5 mag, policy ribaltata per evitare leak API key)"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 500648d1-0ad1-4b64-ba42-071421048286
---

`.env` non è più tracciato dal repo. Non `git add .env`. Non assumere che cross-macchina porti config — l'altra macchina deve rebuildare `.env` da `.env.example`.

**Why:** Il 5 mag 2026 Matteo aveva autorizzato il tracking (commit `b087bf3 — chore: track .env in repo`) per portare config tra macchine in repo privato. Il 12 mag 2026 la policy è stata ribaltata dopo che una API key Anthropic in chiaro stava per finire in commit (catturata dal warning prima del push). Il rischio di leak supera il comfort della portabilità.

**How to apply:** Per portare config cross-macchina usa il pacchetto export ufficiale (`build_export_zip` con `include_env=False`) + reinserisci chiavi a mano sull'altra macchina. NON ri-tracciare `.env`. Se serve template versionabile aggiorna `.env.example`. Vedi [[feedback-push-solo-major]] per le policy git complementari.
