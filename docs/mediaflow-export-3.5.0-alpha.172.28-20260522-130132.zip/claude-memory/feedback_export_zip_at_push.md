---
name: export-zip-at-push
description: "Ad ogni push GitHub, esportare anche stato DB su file ZIP nella cartella docs/, formato importabile via /settings > Dati."
metadata: 
  node_type: memory
  type: feedback
  originSessionId: b16f80d3-9342-4c09-8ea1-1453dacca845
---

Ad ogni `git push origin main`, generare anche un export ZIP completo dello stato DB e committarlo nella cartella `docs/` prima del push.

**Why:** Matteo lavora da macchine diverse (locale + remoto). Quando fa `git pull` su una macchina nuova, deve poter importare lo stato DB più recente via UI `/settings > Dati` invece di rigenerare da seed/migrate. Aggiornato 14 mag 2026.

**How to apply:**
1. Versione bump + CHANGELOG + STATO aggiornati come al solito.
2. Prima del commit, lanciare export:
   ```
   .venv/Scripts/python.exe -c "
   import sys; sys.path.insert(0, '.')
   from app.database import SessionLocal
   from app.services.data_export import build_export_zip
   from pathlib import Path
   db = SessionLocal()
   try:
       data, fname = build_export_zip(db, app_version='X.Y.Z',
                                       include_uploads=False,
                                       include_trash=False)
       (Path('docs') / fname).write_bytes(data)
       print(fname)
   finally:
       db.close()
   "
   ```
3. File nominato `docs/mediaflow-export-{version}-{YYYYMMDD-HHMMSS}.zip`.
4. Includere lo ZIP nello `git add` insieme ai file modificati.
5. Push.

**NB:** ZIP grossi (~9 MB con DB lean stress) — bloat repo accettabile per ora. Future: spostare in release asset GitHub o cartella ignorata + script CI.

Vedi [[push-policy-context-dependent]].
