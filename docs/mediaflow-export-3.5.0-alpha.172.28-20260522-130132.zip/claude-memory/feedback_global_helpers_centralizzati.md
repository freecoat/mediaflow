---
name: Helper JS in global.js, non locali
description: escapeHtml e altri helper di rendering vanno in static/js/global.js, non ridefiniti per template
type: feedback
originSessionId: 597bbfea-aac6-4cdd-a74f-edcc57fda2cc
---
Quando un template Jinja deve usare un helper come `escapeHtml`, mettilo (o trovalo) in `app/static/js/global.js`. NON ridefinirlo localmente nello `{% block scripts %}`.

**Why:** in v3.4.23 ho creato `/admin/users` e `/admin/roles` ridefinendo `escapeHtml` localmente in altri 5 template ma dimenticandolo nei due nuovi → crash silenzioso `ReferenceError` al primo render. Risultato: 3 dei 4 problemi che Matteo ha segnalato dopo i test erano lo stesso bug. Sintomi apparenti completamente diversi dalla causa ("auto-User non funziona", "matrix permessi non funziona", "lista utenti vuota") — tutti rendering JS che si interrompevano alla prima chiamata `escapeHtml`.

**How to apply:**
- Quando aggiungo helper di rendering riutilizzati (escape, format, badge), SEMPRE in `global.js`.
- Se trovo una funzione duplicata in N template, è candidata a centralizzazione.
- Già in `global.js`: `escapeHtml`, `toast`, `openModal`/`closeModal`, `api`, `fmtCurrency`, `fmtDate`, `fmtSize`, `statusBadge`, `assetIcon`. Da preferire questi.
- Test smoke: apri ogni nuova pagina con la console del browser aperta. Un `ReferenceError` al primo `innerHTML` è la firma del problema.
