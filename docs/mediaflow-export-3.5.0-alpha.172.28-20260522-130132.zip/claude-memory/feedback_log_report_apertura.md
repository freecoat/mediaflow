---
name: Log report e conferma a ogni apertura progetto
description: Pattern fisso: diagnostica codice + piano d'azione + attesa conferma utente prima di agire
type: feedback
originSessionId: b023d553-0ef8-4520-b045-492feb89994c
---
A ogni apertura del progetto MediaFlow, prima di implementare qualsiasi cosa: produrre log report di diagnostica (stato pagine, endpoint testati, bug trovati, gap rispetto a documentazione) + piano d'azione strutturato + lista domande aperte.

**Why:** Pattern "AI propone, utente dispone" applicato anche al rapporto Claude–Matteo. Il codice MediaFlow è cresciuto con scaffolding non testato dalla chat web e va costantemente riallineato a stato reale prima di toccare nulla. Matteo ha esplicitamente chiesto questa procedura il 2026-04-25.

**How to apply:** All'inizio di ogni sessione su questo progetto: 1) test endpoint reali con uvicorn, 2) audit codice/template di pagine sospette, 3) confronto codice vs CLAUDE.md, 4) report sintetico con tabella status + gap, 5) plan d'azione per step, 6) lista numerata di conferme richieste, 7) STOP — attendere risposta puntuale di Matteo prima di partire.
