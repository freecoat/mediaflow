---
name: Modello AI default Sonnet 4.6 ma con switcher in UI
description: Default Sonnet bilanciato, ma utente deve poter cambiare modello da UI Impostazioni
type: feedback
originSessionId: b023d553-0ef8-4520-b045-492feb89994c
---
Modello Anthropic di default per MediaFlow: `claude-sonnet-4-6` (bilanciato costo/qualità). MA in Fase 2 F13 va implementato selettore modello in UI Impostazioni AI per passare a Opus 4.7 (top, costoso) o Haiku 4.5 (rapido/economico) senza toccare `.env`.

**Why:** Matteo lo ha richiesto esplicitamente il 2026-04-25 quando confermato il default. Diversi task hanno costi/latenza diversi: estrazione capitolato pesante può giustificare Opus, chat copilot quotidiana può girare su Sonnet o Haiku. Lock-in al `.env` è scomodo per case di post che vogliono provare modelli diversi.

**How to apply:** Quando si implementa `/settings/ai` (F13), includere dropdown modello con i 3 livelli Anthropic + equivalenti OpenAI/Ollama. Persistere la scelta in DB (campo nuovo su `Tenant` tipo `ai_model_override`) o in tabella settings dedicata, non in env. La scelta da UI deve sovrascrivere il default `.env`.
