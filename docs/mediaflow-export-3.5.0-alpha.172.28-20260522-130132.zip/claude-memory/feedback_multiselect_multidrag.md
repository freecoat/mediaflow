---
name: Multiselect/multidrag timeline = desiderata forte
description: Matteo ribadisce che selezione multipla per area + drag-multi simultaneo restano un must-have da raggiungere, anche dopo gli α-step audit
type: feedback
originSessionId: 0263d296-50b8-401c-b650-d6bee2f64a60
---
Multiselect (selezione per area, rubber-band) + multidrag (spostare 5+ booking
insieme con un solo gesto, in tempo reale, senza N round-trip API) restano
un'esigenza prioritaria di Matteo. I tentativi α.16→α.22 (ROI shift+drag) sono
falliti per limiti vis-timeline; il workaround attuale (dropdown ☑ Seleziona,
pannello filtri α.24, bulk-edit modal, multi-move post-drop con confirm α.23)
è funzionale ma "lento".

**Why:** 6/5/2026 — anche dopo i fix di performance del branch
`experiment/timeline-audit` Matteo ha esplicitamente detto "Insisto sulla
funzionalità multiselect e multidrag. È un forte desiderata da tenere a mente."

**How to apply:** quando si pianificano i prossimi round (post-α.31), tenere
multiselect+multidrag in cima alla lista R12. Se i fix vanilla non bastano
(sintomo Mac+Chrome), il candidato di sostituzione libreria deve essere
valutato anche su questa capacità (Bryntum/DHTMLX hanno multidrag nativo;
FullCalendar Premium no di default). Non chiudere α.31 dichiarandolo "ok"
solo perché il drag singolo va: il tema multi resta aperto.
