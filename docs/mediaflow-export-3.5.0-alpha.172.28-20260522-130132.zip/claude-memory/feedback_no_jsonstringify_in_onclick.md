---
name: Mai JSON.stringify dentro attributi onclick
description: Antipattern frequente nei template MediaFlow — produce HTML rotto se il valore contiene caratteri speciali
type: feedback
originSessionId: 73b0a440-ba67-42e1-847b-2d242e61f050
---
Mai usare `${JSON.stringify(value)}` dentro attributi `onclick="..."` (o qualunque attributo HTML con delimitatore `"`). Le virgolette doppie del JSON rompono il parsing dell'attributo e l'handler non viene mai chiamato — silently broken, nessun errore in console.

**Why:** Bug reale incontrato il 2026-04-27 sul tasto "Elimina cliente" in `clients.html`: `onclick="deleteClient(${c.id}, ${JSON.stringify(c.name)}, false)"` rendeva `onclick="deleteClient(1, "RAI Documentari", false)"` → l'attributo finiva alla prima `"` interna, nessun errore JS, solo bottone morto. Pattern probabilmente replicato in altri template del progetto.

**How to apply:** Quando devi passare dati a un click handler in template literal:
1. Preferito: `data-*` attributes sul bottone + lettura via `btn.dataset.xxx` nella funzione (passa `this` come argomento o usa `event.currentTarget`).
2. Alternativa per stringhe: escapare le `"` con `&quot;` esplicitamente (non con `JSON.stringify`).
3. Per valori semplici (id numerici, boolean) interpolare direttamente è OK.

Quando rivedi un template MediaFlow con onclick dinamici, controlla se qualche `${JSON.stringify(...)}` è dentro un attributo — è un bug latente da risolvere preventivamente.
