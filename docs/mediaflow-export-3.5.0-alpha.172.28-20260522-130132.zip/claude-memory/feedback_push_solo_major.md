---
name: push-policy-context-dependent
description: Push GitHub a ogni commit quando Matteo è in remoto (su altra macchina). Default originale era solo major bump.
metadata: 
  node_type: memory
  type: feedback
  originSessionId: b16f80d3-9342-4c09-8ea1-1453dacca845
---

Su `freecoat/mediaflow` (privato), la policy push dipende dal contesto:

- **Modalità default (Matteo locale)**: push solo ai major version bump (v3.x.x → v4.0.0). I commit intermedi restano locali. Origine: setup remote 29 apr 2026.
- **Matteo in remoto (su altra macchina)**: push a **ogni commit** appena chiuso (alpha/patch/hotfix incluso). Matteo aggiornato 14 mag 2026: "devi pushare su github, perché sono in remoto".

**Why:** quando lavora da un'altra macchina (mac di laboratorio, altro pc) deve poter `git pull` immediato per testare. Senza push, i fix non gli arrivano.

**How to apply:** se Matteo dice "sono in remoto" / "in trasferta" / "sull'altra macchina" → push automatico a ogni commit. Quando ritorna locale → torna a "solo major". Se non specificato e dubbio → chiedere prima di pushare.

Vedi anche [[feedback_export_zip_at_push]] (deve sempre esportare DB ZIP insieme al push).
