---
name: feedback-reset-business-data-gaps
description: "scripts/reset_business_data.py NON purga 17+ tabelle satellite (advance_payments, invoice_payments, billing_batches, jcl_billed_slices, supplier_invoices, anomaly_entries, asset_*, ecc.). Genera record orfani al rerun di seed custom."
metadata: 
  node_type: memory
  type: feedback
  originSessionId: ae7121f8-f3d5-4226-82f0-44f11f236422
---

`scripts/reset_business_data.py` cancella solo le tabelle "core" elencate in `TABLES_TO_PURGE` (notifications, ai_*, booking_*, bookings, invoices, invoice_lines, jcl, jobs, quotes, projects, clients, resources). NON tocca le tabelle satellite finanziarie/asset:

- `invoice_payments` (cassa ricevuta)
- `advance_payments`, `advance_payment_allocations`, `advance_payment_consumptions`
- `quote_advance_schedules`, `quote_advance_allocations`
- `billing_batches`, `billing_batch_lines`, `loss_entries`, `jcl_billed_slices`
- `supplier_invoices`, `supplier_invoice_payments`, `suppliers`
- `asset_access_logs`, `asset_movements`, `asset_memberships`, `ingest_batches`, `physical_assets`, `job_deliverables`
- `anomaly_entries`, `project_access_grants`, `booking_changes`, `project_milestones`

**Why:** lasciate fuori storicamente perché aggiunte dopo α.66.20 (acconti α.136, slice α.61, anomalie α.89, supplier_invoices α.71, ecc.) e nessuno ha aggiornato lo script reset.

**How to apply:** quando scrivi un seed custom che chiama `reset_business_data` e poi crea nuovi record, fai un purge extra esplicito di queste tabelle (pattern in `scripts/seed_5projects.py:purge_business_data`), altrimenti vedrai record orfani con `project_id` puntato a progetti cancellati o duplicati di payments. Da sistemare in `reset_business_data.py` aggiornandolo alla lista completa.
