---
name: feedback-smoke-e2e-browser
description: Smoke E2E browser obbligatorio prima del bump per features UI nuove. Backend smoke asyncio NON cattura errori di binding nome funzione JS.
metadata: 
  node_type: memory
  type: feedback
  originSessionId: bfbe3a2b-5cad-4cca-9cf6-ba0233c6c163
---

# Smoke E2E browser obbligatorio per UI

**Regola**: prima di bumpare versione su feature UI nuova (modal/handlers/refresh dopo POST), verifica E2E in browser, non solo backend.

**Why**: bug α.137/139 — chiamate `loadQuote(id)` inesistente (vera funzione `reloadQuote()`). Smoke backend asyncio passava (POST/DELETE/GET tutti corretti). Bug emerso solo a uso reale: errori JS silenti, UI non rinfrescava.

Trovato in α.140.1 hotfix (commit cb68c40). 4 occorrenze in `changeQuoteCurrency`, `refreshQuoteFx`, `submitAdvanceSchedule`, `deleteAdvanceSchedule`.

**How to apply**:
- Per ogni nuova feature UI con `await fetch + refresh state`: aprire browser, eseguire l'azione, verificare che la UI si aggiorni con il nuovo stato.
- Aprire DevTools Console: cercare errori di binding nome funzione (`ReferenceError: X is not defined`).
- Se non possibile testare in browser, dichiarare esplicitamente nel commit/STATO che la UI non è stata verificata end-to-end.
- Backend smoke (asyncio direct call) verifica solo correttezza endpoint, NON binding JS.
- Prima di copiare nome funzione da altri handler (es. `loadProjects`, `reloadJob`), grep nel template per confermare che la funzione effettivamente esiste con QUEL nome.

**Test pattern**: dopo aver scritto handler che fa fetch + refresh, sempre fare:
```bash
grep -c "function FUNCTION_NAME" template.html
```
prima del commit.
