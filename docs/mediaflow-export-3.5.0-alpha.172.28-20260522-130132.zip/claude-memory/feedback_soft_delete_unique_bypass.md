---
name: Soft-delete + vincoli UNIQUE
description: Con il filter automatico soft-delete (`deleted_at IS NULL`), le query che validano vincoli UNIQUE o calcolano progressivi devono bypassare il filter, altrimenti collidono al INSERT.
type: feedback
originSessionId: 67d5f425-dd8b-4031-bb7c-66c2d36eda72
---
Pattern stabilito in v3.5.0-alpha.7 (cestino quote).

**Regola**: con soft-delete, un record nel cestino ha `deleted_at != NULL` ed è invisibile alle query di default, MA occupa comunque qualunque vincolo UNIQUE / chiave naturale a livello DB (`quotes.number`, `projects.code`, `clients.vat_number`, ecc.).

Le query di SISTEMA che dipendono dall'unicità DB devono esplicitamente includere i record cestinati:

```python
last = (db.query(Quote)
          .execution_options(include_deleted=True)
          .filter(Quote.number.like(f"{prefix}%"))
          .order_by(Quote.id.desc()).first())
```

**Why**: senza bypass, `_next_quote_number` non vede `Q-2026-001` cestinata → ripropone `Q-2026-001` → INSERT fallisce con `UNIQUE constraint failed`. Bug riprodotto in test reale Matteo (3 mag 2026).

**How to apply**:
- Auto-numero / progressivi (Q-yyyy-NNN, P-NNN, ecc.) → bypass
- Pre-check unicità prima di INSERT → bypass
- Validazione duplicati su rinomina → bypass
- Lookup user-facing (cerca per nome cliente, code progetto, ecc.) → NO bypass (vogliamo NON trovare record cestinati)
- Resolve di entità per AI capability (`_resolve_quote`, `_resolve_project`) → NO bypass (l'AI non deve operare su cestinati)

Quando aggiungi soft-delete a un nuovo modello, fai grep di tutti i punti che usano i campi UNIQUE del modello e decidi caso per caso.
