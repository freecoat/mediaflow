---
name: Vis-timeline 7.7.3 quirks
description: 4 trappole non-ovvie di vis-timeline 7.x (sanitizer HTML, select event programmatico, stack:true O(N²), doubleClick double-fire), da ricordare prima di toccare planning.html
type: feedback
originSessionId: fca8b616-da35-4723-a2de-0b4205dd63c7
---
Vis-timeline 7.7.3 ha quattro comportamenti non documentati che hanno causato altrettanti round di debug. Promemoria per quando torneremo a modificare `app/templates/pages/planning.html`.

**1. `group.content` come stringa HTML annidata viene SANIFICATO** — class+style attributes vengono strippati dal sanitizer interno. Sopravvivono solo elementi root single-token (es. `<span style="...">text</span>` OK; `<div><div class="x">text</div></div>` → strip).

**Why:** dopo α.41, il fix font non funzionava perché vis ha un sanitizer non documentato che processa stringhe HTML annidate.
**How to apply:** per labels timeline complesse passare un `HTMLElement detached` costruito con `document.createElement` + `style.cssText` + `textContent`. Vis lo fa `appendChild` as-is, niente sanitization. Vedi `tlBuildResourceGroups` + `tlHeatmapElement` come pattern.

**2. `select` event emesso SOLO per click utente, NON per `setSelection()` programmatico** — qualunque chiamata da codice (ROI/area, select-by-job, panel filter, invert, clear) NON triggera il listener `tlInstance.on('select', ...)`.

**Why:** dopo α.42 sticky-selection funzionava per click, ma il bottone Bulk non si attivava su selezione ROI (Matteo "sparito" in α.47.1).
**How to apply:** usare il wrapper `_tlSetSel(ids)` che chiama setSelection + tlOnSelectionChange + sync `_tlPrevSelection` per sticky. Definito in `planning.html` α.47.1, riutilizzare per ogni nuova chiamata programmatica.

**3. `stack: true` calcola overlap O(N²)** — con N items larghi (zoom mese) + 600+ background items × risorse, ogni `requestAnimationFrame` può bloccare 200+ms su Chrome/Mac. Su Firefox tollerato (GC più aggressivo). Su PC tollerato (GPU rendering diverso).

**Why:** freeze Chrome/Mac persistente con 30+ booking + 20 risorse + zoom mese. Performance trace: PageAnimator rAF da 225ms picco, 18,761 Paint events, top 7 RunTask 480-300ms.
**How to apply:** offrire toggle "Light mode" con `stack: false` + `_hideBg = true` + CSS conditional (no animation/transition/filter su `.vis-item`). Bottone 🪶 Light in toolbar α.46.2 + persistenza `localStorage.mf_tl_light_mode`. Soluzione finale per dataset grandi: valutare sostituzione libreria (Bryntum/DHTMLX nel backlog Round 12).

**4. `doubleClick` event emesso DUE VOLTE per ogni gesto** — una dal recognizer Hammer.js interno (`e.recognize` → `tryEmit` → `emit`), una dal native DOM `ondblclick` (`p.dom.root.ondblclick`). Il listener `tlInstance.on('doubleClick', ...)` viene quindi invocato 2x. Se il handler è async, il primo invocation è ancora in volo quando arriva il secondo → side-effect duplicato (es. `tlbAddAssignmentRow` chiamato 2x → modal con 2 righe identiche per 1 assignment in DB).

**Why:** v3.5.0-alpha.66.2 — Matteo segnala booking nuovi che nascono con risorsa "duplicata" anche con 1 solo assignment in DB. Diagnostica via `console.log` con stack trace ha rivelato 2 invocazioni con stack diverso (Hammer + DOM). Stessa dinamica per "doppio-click su area vuota" (`tlbOpen`).
**How to apply:** dedup il listener `doubleClick` con timestamp window 350ms (gap dblclick tipico ~250ms, doppio-fire interno <10ms):
```js
let __tlLastDblClick = 0;
tlInstance.on('doubleClick', async (props) => {
  const now = Date.now();
  if (now - __tlLastDblClick < 350) return;
  __tlLastDblClick = now;
  ...
});
```
Pattern applicabile a qualsiasi listener sintetico vis-timeline che si scopre essere doppio-fired.
