---
name: AI derivazione costi da visura amministrativa (futuro)
description: Capitolo futuro - AI legge documenti amministrativi (visura, bilancio, registri costi) per derivare cost-rate effettivi per resource type
type: project
originSessionId: 32a94049-6da5-4a2f-9917-ca6eb4ce9eb0
---
In α.66.9 cost-rate Resource per `cost_type=studio` (sala interna) e `cost_type=employee` parte da valori manuali (tariffa fissa per studio, monthly_gross_salary × multiplier per employee).

**Capitolo futuro** (post α.66.10): permettere all'AI di leggere documenti amministrativi (visura camerale, bilancio, registro costi mensili, fatture utenze, ammortamenti attrezzature) e proporre cost-rate aggiornati derivati dai costi reali.

**Why:** i valori manuali invecchiano rapidamente, i costi reali della casa di post variano mese su mese (utenze, ammortamenti, manutenzione hardware, licenze software, formazione personale). L'AI può fare il lavoro che oggi farebbe il commercialista una volta l'anno, ma in modo continuo e granulare per reparto/sala/risorsa.

**How to apply:** quando si farà il cantiere "AI Costi Amministrativi", riusare il pattern già consolidato `propose_*` (AIAction status=proposed → conferma utente → applied). Capability nuova `propose_resource_cost_update` che prende: documento source + Resource target → propone nuovo `internal_cost_hourly` con motivazione e fonti. Tracking via AIAction per audit. Decisione se/come implementare aperta.
