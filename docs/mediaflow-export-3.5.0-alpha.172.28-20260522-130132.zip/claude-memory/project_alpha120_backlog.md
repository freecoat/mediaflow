---
name: project-alpha120-backlog
description: Backlog finding emersi da test checklist post-audit α.114-118 (sessione 16 mag 2026). Da affrontare in round α.120 unico. Aggiornato durante esecuzione checklist.
metadata: 
  node_type: memory
  type: project
  originSessionId: 2d02b59b-3641-44fa-b273-ba15559e468d
---

# α.120 backlog — finding test UI checklist α.114-118

Sessione 16 maggio 2026. Matteo esegue checklist UI parallela a smoke server-side. Findings accumulati qui per round audit α.120 unico.

## Bug puri (priorità alta)

**F3 — CR lista non aggiorna alla prima apertura (regressione α.115/117)**
- Sintomo: /cost-report apre con maturato stale. Si allinea solo DOPO aver aperto dettaglio progetto.
- Backend OK: `/cost-report/api/reconcile-status` → `stale_count=0`. TTFB 5ms.
- Causa probabile: frontend non subscribe al polling sync al primo render, oppure pesca da cache stale prima del reconcile background. Dirty flag α.115 + bg reconcile α.117 non coprono path "first paint".
- Da investigare: `app/templates/pages/cost_report.html` JS first-load + polling /api/reconcile-status.

**F5 — Chip filtro `/projects?client_id=X` non mostra nome cliente**
- Sintomo: `/clients` → "Vedi progetti" → filtro applica MA chip nel riquadro filtri cliente è vuoto.
- Fix: in `projects.html` se URL ha `?client_id=N`, resolve nome cliente server-side e pre-popola chip filtro.

**F7c — Naming pattern salvato in /settings non riflesso UI pagine**
- Sintomo: dopo aver aggiornato naming Quote in `/settings#numbering`, riquadro naming in `/quotes` resta vuoto.
- Possibile causa: template `/quotes` non legge `NumberingConfig.format_pattern` per mostrare pattern attivo. UI mostra solo lo "schema" senza riflettere config tenant.
- Fix: aggiungere endpoint o context var con format_pattern attivo per ogni doc_type, esporlo nelle pagine relevanti (quotes, jobs, billing, etc).

## UX bug (priorità media)

**F4 — Palette tema chiude su mouseleave**
- Sintomo: hover apre menu colori, mouseleave chiude. Forza click rapido.
- Fix: trasformare in toggle click-to-open + click-fuori-per-chiudere (no hover).

## Design discussion (priorità da decidere)

**F6 — `admin_email` semantica errata**
- Implementato α.113 Q3: campo Client.admin_email → snapshot in fattura → stampato in PDF come "Att.ne Amministrazione".
- Intento Matteo: campo serve per **inviare** email (mail send) della fattura, NON per intestazione PDF.
- Decisione richiesta:
  - Lasciare PDF intestazione + aggiungere nuovo campo `billing_email` separato per send?
  - Sostituire uso: rimuovere stampa PDF, usare admin_email solo per send?
  - Workflow send email: SMTP configurabile? Provider?

**F7a — Naming drawer position**
- α.114 A14 fix: drawer a sinistra flush sidebar.
- Matteo: prima si era detto a destra. Ora preferisce centro popup (modal style).
- Decisione: modal centrato sì/no.

**F7b — Inserimento blocchi naming**
- Attuale: drag&drop blocchi + bottone "+ aggiungi char"/separator.
- Matteo: vorrebbe digitazione diretta nel riquadro blocchi attivi, fra un blocco e l'altro (typing inline).
- Decisione: hybrid editor (drag&drop + typing) o solo input text con autocomplete var?

## Bug puri (cont.) — batch 2 Q5-Q11

**F3 conferma — Q5**: drag/shift bulk done booking non rinfresca CR list. Solo entrando in dettaglio + back rinfresca.

**F8 — Overhead write-off categoria mismatch lista vs drawer**
- Lista `/overhead` mostra card "Write-off (LossEntry) · €33'895,34".
- Click → drawer "0 voci · Nessuna voce in questa categoria nel periodo selezionato".
- Mismatch: aggregato somma OK, query drawer perde le voci. Filtro periodo o tenant scope buggato sul drawer query.

**F9 — Codice progetto mismatch fra moduli (UX critica)**
- /cost-report mostra codice progetto diverso da /planning, /finance, /suppliers.
- Matteo: non vuole vedere codici interni DB, solo codice progetto o cliente.
- Da audit: omogeneizzare visualizzazione `{project.code} · {project.title}` ovunque, mai `project.id` o stringhe interne.
- Possibile causa: alcune pagine mostrano `Job.code` (numerazione job autogenerata) invece di `Project.code`. Specie in CR.

**F10 — Job dropdown in fattura passiva: serve JCL, non Job**
- /suppliers nuova fattura → dropdown "Job" mostra entità Job reali.
- Matteo vuole le righe del job (JobCostLine = lavorazioni costabili derivate da QuoteLine), per linkare la fattura alla LAVORAZIONE specifica.
- Senza linkare a JCL non si può riportare cost_external in cost report dettagliato.
- Fix: rinominare dropdown "Lavorazione" + popolarla con JCL del job, oppure aggiungere SECONDO dropdown a cascata Job → JCL.

**F11 — Resource link in modal supplier: solo freelance + niente "+ Crea risorsa"**
- Pattern attuale: dal supplier puoi linkare qualsiasi risorsa + bottone "+ Crea risorsa".
- Matteo: flusso INVERSO — è la Resource (freelance esterno) che genera il Supplier, non il contrario.
- Fix:
  - Filtrare dropdown "Risorsa associata" SOLO `ResourceType.person_freelance` (no internal/equipment/etc).
  - Rimuovere bottone "+ Crea risorsa" dal modal supplier.
  - Da `/resources` su tipo freelance: aggiungere bottone "Genera supplier collegato" che crea Supplier link.

## Bug puri (cont.) — batch 3 A1-A8 (cashflow + PDF)

**F12 — Cashflow NC TD04 ignorata**
- Emit fattura €1000 gen, NC TD04 a mar.
- Atteso: gen +1000, mar -1000, saldo netto 0.
- Reale: cashflow segna fatturato + importo aperto stesso mese fattura. NC ignorata. Saldo annuale errato.
- Root cause probabile: cashflow query non filtra `is_credit_note`/`TD04`, oppure NC non collegata a Invoice originale come storno (deve essere `parent_invoice_id`).

**F13 — Cashflow non aggiorna stato pagato**
- Invoice.status passa `draft → sent → paid` ma cashflow continua a mostrarla solo come "fatturata" mai "pagata".
- Probabile: cashflow legge `Invoice.status` snapshot al momento di emissione, non in real-time.

**F14 — PDF fattura `cancelled` stampabile (regola sbagliata)**
- Lista `/finance` permette download PDF di fatture cancelled.
- Atteso: blocco con 409 o bottone disabled. Fattura annullata non deve essere stampabile.

**F15 — PDF NC senza nome progetto + voci quote duplicate**
- Stampa NC riporta TUTTE le voci della quote del progetto con prefisso [Storno].
- Manca nome progetto / cliente nell'intestazione.
- Atteso: NC mostra solo le voci della fattura stornata + intestazione progetto + cliente.

**F16 — Totali fatture + cashflow SENZA IVA di default (richiesta architetturale)**
- Attuale: tutti gli importi mostrati IVA inclusa.
- Matteo: default deve essere SENZA IVA, toggle UI per mostrare IVA opzionalmente.
- Impatto: Cost report, /finance liste, /cashflow, dashboard. Aggiornare anche dropdown export e summary card.

## Bug puri (cont.) — batch 4 A9-A16

**F17 — Terminologia tecnica esposta in UI**
- A9 task usava "job_cost_line_id" (JCL = JobCostLine). Matteo non capisce concetto.
- In UI booking edit: rinominare "JCL" / "job_cost_line_id" in "Lavorazione" o "Voce di costo del job".
- Esponere dropdown utente-friendly: scelta lavorazione tra le righe del job (no ID tecnico).
- Audit globale terminologia UI: cercare ovunque appaia "JCL", "cost_line", "job_cost_line" e tradurre in "lavorazione".

**F18 — Lista fatture: detail on click + nascondi change-status se immutabile**
- /finance lista fatture: click su riga deve aprire DETTAGLIO fattura (drawer o pagina).
- Se status non modificabile (paid/cancelled/overdue→sent), nascondere i bottoni cambio stato.

**F19 — Cashflow split per reparti + totale aziendale**
- /finance#cashflow oggi mostra solo totale aziendale.
- Aggiungere breakdown per Department (DI/Video, VFX, Audio, Commercial).
- Source: Job → Project → PriceItem.department_id; o JCL.department snapshot.

**F20 — Componi fattura: tasto aggrega batch sparisce dopo chiusura popup senza salvare**
- Scenario: 2 batch approvati stesso progetto. Click batch → popup → close without save.
- Atteso: aprendo l'altro batch, tasto "Aggrega/Accorpa con batch X" presente.
- Reale: tasto sparisce. Solo refresh page lo rievoca. Regressione UI state.
- Da debug in /finance billing UI flow.

**F21 — Revamp /team /resources /departments UX + filtri risorse**
- Confusione su relazione fra le tre pagine. Struttura non chiara.
- Audit IA UX: rivedere navigazione, gerarchia (departments → resources → team?), differenze ruoli (chi appare in team vs resources).
- Aggiungere filtri per lista risorse (tipo, reparto, ruolo, attivo).
- Possibile fusione /team e /resources?

**F22 — Cleanup link `Resource.supplier_id` non funziona (BUG α.114 A10)**
- Pattern frontend supplier modal: PUT `/resources/api/{prev}` con `supplier_id=''` per delink precedente.
- Backend `update_resource`: `supplier_id: Optional[int] = Form(None)` + check `if supplier_id is not None`.
- '' (stringa vuota) → FastAPI converte a None → check skip → resource NON delinked.
- Conferma: PUT supplier_id='' su resource 26 → resource resta linked a supplier 1.
- Fix: distinguere "key not present" da "key empty". Opzioni:
  - Form sentinel `clear_supplier=true` flag separato.
  - Endpoint dedicato `DELETE /resources/api/{id}/supplier-link`.
  - Refactor Form: accept str poi parse manuale ('' → "clear", N → int, missing → no change).

**F23 — A11 fattura passiva: tolto project pulisce job dropdown (correct), ma manca dropdown LAVORAZIONE (JCL)**
- Già notato F10. Conferma: serve dropdown a cascata Project → Job → JCL per linkare fattura passiva alla LAVORAZIONE specifica.
- Senza JCL link: cost_external non riporta cost reale su righe specifiche del cost report.

## Bug puri (cont.) — batch 5 α.115-118 + trasversali

**F3 conferma ULTERIORE — gravità maggiore**
- B6: pagina CR apre rapida (no freeze 30s, OK perf α.117), MA cifre lista palesemente sbagliate al primo render.
- Esempio Voice of Tide Ep. 3 (Job 2024-0015):
  - PRE-apertura: quotato 121547,84 / maturato 117690,61 / fatturato 123575,15 / residuo -3857,23 / drift —
  - POST-apertura+back: quotato 121547,84 / maturato 2875,00 / fatturato 102792,00 / residuo -118672,84 / drift -3532,26
- Variazione: maturato −98%, fatturato −17%, residuo decuplica.
- Background reconcile indicator probabilmente NON sta polling correttamente al first load, oppure UI legge JCL.total_accrued (snapshot stale) invece del valore reconciled.
- Critical: la lista CR mostra dati FALSI all'utente al primo paint. Bug grave per decisioni gestionali.

**B5 nota — Chip filtro drift solo post-Rileva**
- /finance#anomalies: chip "⚖ Drift costo" appare solo dopo click "Rileva".
- Atteso: chip sempre visibile come opzione filtro (anche con count=0).
- Fix UI: render chip da metadata schema, non da count entries.

**F24 — Sweep visualizzazione codici DB**
- Matteo NON vuole vedere codici interni DB in UI: solo codici funzionali (project.code, client.code, quote.number, invoice.number, job.code se serve, batch.code).
- ID numerici interni → escludere ovunque.
- Audit globale: cercare in template `id=`, `internal_id`, `pk` esposti utente.
- F9 collegato: omogeneizzare il SET di codici visibili (project preferred over job code in CR liste, etc).

## Stato WIP — interrotto 16 mag 2026

**Codice modificato uncommitted** (da riprendere al restart):
- `app/routers/resources.py` — F22 fix (PUT supplier_id raw form parsing, distingue '' clear da missing). Test passati ✅.
- `app/routers/finance.py` — F14 fix endpoint `/api/invoices/{id}/pdf` blocca 409 se cancelled.
- `app/routers/billing.py` — F14 fix endpoint `/billing/invoice/{id}/pdf` blocca 409 se cancelled.

**Da finire F14**:
- Restart server pickup F14 billing.py edit.
- Test E2E download PDF su invoice cancelled (id=2 cancelled o trova un id paid → cancel → tentativo PDF → 409).
- UI hide bottone download PDF da `app/templates/pages/finance.html` riga 1196 quando `i.status === 'cancelled'`.

**Pendenti P0 α.120 ancora da fare**:
- F15 NC PDF: aggiungere intestazione progetto + filtrare voci stornate (oggi duplica TUTTE le voci quote con [Storno]).
- F12+F13 Cashflow: NC TD04 storno + status real-time.
- F3 CR list valori falsi al primo render (CRITICO, debug cost_report.html JS init + reconcile polling).

**Step closing α.120**:
- Bump version `app/main.py` → 3.5.0-alpha.120
- CHANGELOG.md entry con tutti i 6 fix P0
- docs/STATO.md sezione corrente
- Commit (no push, decide Matteo)
- Export ZIP α.120 in docs/

**Server stato**: stopped. DB con side-effect minori test sessione:
- invoice 111 status=overdue (era sent, transition legit α.114 test)
- supplier_invoice 131+132 soft-deleted
- 2 anomaly entries cost_drift dismissed auto_resolved
- numbering_configs overhead_cost=`OH-{YYYY}-{NNNN}` (= default, no-op)
- mediaflow.db.bak-pre-smoke-20260516-094339 (backup locale, untracked)

## Roadmap α.120 — priorizzazione

### P0 (bloccanti, fix subito)
- **F3** — CR list mostra valori falsi al primo render. Investigazione root cause cost_report.html JS init + reconcile polling.
- **F22** — Resource.supplier_id delink non funziona via PUT form vuoto. Fix Form sentinel pattern in resources.py.
- **F12** — Cashflow NC TD04 ignorata. Saldo annuale errato.
- **F13** — Cashflow non aggiorna stato pagato. Status real-time.
- **F14** — PDF fattura cancelled stampabile. Aggiungere block 409 + UI disabled.
- **F15** — PDF NC senza nome progetto + voci quote duplicate. Refactor NC PDF.

### P1 (UX bug, fix con audit visivo)
- **F4** — Palette sticky toggle (no hover).
- **F5** — Chip filtro client_id senza nome cliente.
- **F7c** — Naming pattern non riflesso UI pagine relevanti.
- **F8** — Overhead write-off mismatch lista vs drawer.
- **F10/F23** — Fattura passiva: aggiungere dropdown "Lavorazione" (JCL) cascata Project→Job→JCL.
- **F18** — Lista fatture: detail on click + hide change-status se immutabile.
- **F20** — Componi fattura: aggrega batch tasto sparisce dopo close popup.
- **B5** — Chip anomaly drift sempre visibile (da schema, no count).

### P2 (architetturale, design discussion)
- **F6** — `admin_email`: serve per SEND email (no intestazione PDF). Discutere prima.
- **F7a** — Naming drawer position centro popup.
- **F7b** — Naming inserimento blocchi inline typing.
- **F11** — Supplier↔Resource flusso inverso (no crea-da-supplier).
- **F16** — Totali fatture + cashflow SENZA IVA default + toggle IVA.
- **F17** — Terminologia JCL → "Lavorazione" in UI ovunque.
- **F19** — Cashflow split per reparti + totale aziendale.
- **F21** — UX revamp /team /resources /departments + filtri.
- **F24/F9** — Sweep visualizzazione codici DB (no internal id, solo codici funzionali).

### Strategia
1. Round α.120 (focus P0): 6 fix bug bloccanti. Test E2E per ognuno. Commit + bump + export.
2. Round α.121 (UX puro): batch P1 da 8 fix. Audit visivo sui flussi indicati.
3. Round α.122 (architetturale): P2. Iniziare con design discussion sui finding più impattanti (F6, F16, F17, F21). Decisioni → implementazione iterativa.
4. Documentare ogni decisione design in memoria progetto.
