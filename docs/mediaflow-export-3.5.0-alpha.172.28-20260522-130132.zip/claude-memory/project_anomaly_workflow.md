---
name: project-anomaly-workflow
description: "Sprint S4 α.89 — stateful workflow per anomalie fatturazione. Tassonomia 5 tipi, 4 azioni, AnomalyEntry table."
metadata: 
  node_type: memory
  type: project
  originSessionId: 0e7f74d6-1669-407d-aeea-3310737e3d50
---

Sprint S4 chiuso in α.89 (notte 12 mag 2026). Era già in backlog post-S8.

## Tassonomia (AnomalyType)
1. **extra_after_billed** — JCL con quantity_actual > Σ slice fatturate
2. **sforamento_monte_ore** — JCL non-extra con actual > quoted
3. **quote_discrepancy** — Job con consuntivo vs budget oltre ±15%
4. **mancato_recupero** — Invoice due_date passata + status != paid/cancelled
5. **over_budget** — JCL is_extra=True (extra puri)

## Azioni (AnomalyAction)
1. **rimanda_commerciale** — cambio stato workflow, no side-effect
2. **rivaluta_producer** — cambio stato workflow, no side-effect
3. **write_off_loss** — crea `LossEntry(reason=written_off)`, linka `handled_target_id`
4. **overhead_cost** — crea `OverheadCost(category=other, code OH-YYYY-NNNN)`,
   linka `handled_target_id`

## Idempotency

`dedup_key = "{type}:{source_kind}:{source_id}"` UNIQUE per tenant.
Re-run detect aggiorna `last_seen_at`+`amount`+`description`, non duplica.
Status non viene MAI toccato dal detector (rispetta handled/dismissed).

## File chiave
- `app/models/models.py:2367+` — AnomalyEntry + 4 enum
- `app/services/anomaly_detector.py` — 5 detect_* + detect_all
- `app/routers/anomalies.py` — 8 endpoint v2
- `app/templates/pages/finance.html` tab section-anomalies + JS

## Endpoint
- `GET /finance/api/anomalies/v2` — filtri status/type/period
- `GET /finance/api/anomalies/v2/summary` — KPI per tipo
- `POST /finance/api/anomalies/detect` — re-scan idempotente
- `POST /finance/api/anomalies/{id}/handle` — Form: action, notes
- `POST /finance/api/anomalies/bulk-handle` — Form: anomaly_ids (CSV), action, notes
- `POST /finance/api/anomalies/{id}/dismiss`
- `POST /finance/api/anomalies/{id}/reopen`

## RBAC
- `view_anomalies` — vedi lista
- `handle_anomalies` — applica azioni
- Admin auto-resync via ALL_PERMISSION_KEYS [[feedback-permissions-config]]

## Endpoint legacy (back-compat)
Vecchi `/api/anomalies/floating-jobs`, `/discrepancies`, `/overdue-supplier`,
`/summary` restano per chi li avesse linkati esternamente. UI ora usa solo v2.

## Possibili estensioni
- Modal action dedicato (al posto del prompt() legacy)
- AI capability `propose_anomaly_action` (autopropone rimanda vs write-off)
- Job orfani come 6° tipo (Job.quote_id IS NULL) — non incluso α.89, presente
  nel legacy `floating-jobs`
- Detector come cron job periodico (oggi solo on-demand)
