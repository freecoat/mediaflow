---
name: project-backlog-alpha171
description: Backlog post-α.170 con 13 issue raggruppate per area + priorità. Phantom redesign + CR ore double-count + filtri planning + UX polish. Cataloga 19 mag durante test interrotto.
metadata: 
  node_type: memory
  type: project
  originSessionId: 76dd9ecc-d850-456e-ad46-d0f8304818f4
---

Backlog accumulato durante test T1 α.170 (Matteo, 19 mag 2026 pomeriggio). Test posticipato per affrontare prima questi temi architetturali.

## P0 — Invarianti finanziari/data integrity

**CR-1: Voci con stima = quotato senza booking** — Job `2026-0008 Voice of Silence Vol.2`. Voci `Transfer Elettronico`, `Re-recording mix Dolby Atmos`, `Proxy ProRes 422 HQ`, `Auto-QC Baton/Vidcheck` mostrano stima=quotato ma 0 booking. Possibili cause: stima default fallback su `quoted` quando nessun assignment? cost_line_sync non resetta a 0? Verifica `cost_report.py` payload `cost_estimated` derivation.

**CR-2: Ore double-count sala+risorsa** — Quando booking ha 1 sala + 1 risorsa umana, conteggio ore in CR somma entrambi → raddoppia. Regola CORRETTA da Matteo:
- Prendi sempre risorsa con max ore (singola)
- Se presente almeno 1 risorsa umana → override umana (anche se sala ha più ore)
Implementazione: `cost_line_sync` su BookingAssignment deve aggregare per booking_id (non per assignment), prendere max(humans) || max(all).

## P0 — Phantom quote redesign

Vedi [[project-phantom-quote-redesign]] memory dedicata. 8 sub-feature:
1. Rename "Quotazione a Consuntivo"
2. UNIQUE 1-per-progetto
3. Stato standby + endpoint promote
4. Endpoint merge (crea versione su quote target, anche approved)
5. Pre-condizione: no phantom se quote attiva/approvata
6. Auto-attach booking nuovi → phantom esistente via PriceItem
7. Voci partono quantity_quoted=0
8. Modifica quote approved con doppia conferma + auto-versioning + propagazione delete voce
9. CR-3: voce phantom non visibile in CR (questo è sub-feature dipendente da 1-8)

## P1 — Filtri planning

**TL-1: Filtro reparto multi-chip stile autocomplete** — Matteo preferisce stesso pattern di cliente/progetto/job/risorsa (chip-based) vs `<select multiple>` size=4. Più coerente UI.

**TL-2: Risorse limitate quando filtro reparto attivo** — Filtro mostra reparti ma non scorre giù → vede solo prime N risorse. Probabile interazione tra Light Mode auto-enable + cap 100 + filtro reparto. Indagine necessaria.

**TL-3: Filtro lavorazione (= JCL/voce listino) come subfiltro progetto** — Aggiungi in tutte le viste planning. Limita ai bookings la cui JCL ha description/price_item match. Backend: `/planning/api/bookings?job_cost_line_id=X` o `?jcl_search=foo`.

**TL-4: Filtri "Per progetto" view rotti** — `renderProjectView` non rispetta `getFilterParams()`. Verifica.

**TL-5: Ricerca testuale full-text** — `f-q` cerca su codice/titolo solo. Estendi a `notes` booking, `description` JCL, `role` risorsa, ecc.

## P2 — Polish UI

**TL-6: Risorse tronche in coda timeline** — Ultime risorse non interamente visibili. Probabile `tlComputeHeight` clip troppo aggressivo. Indagare.

## Già chiusi α.170/α.170.1

- ✅ groupHeightMode auto (riga 74→39)
- ✅ min/max scroll ±5 anni
- ✅ Click singolo label resource → popover esteso
- ✅ Filtro reparto multi (regressione fixata α.170.1, ma UX ridisegno → TL-1)
- ✅ Anomalie filtri cliente/progetto fallback
- ✅ Anomalie summary con filtri
- ✅ Anomalie auto-detect prima apertura
- ✅ Cashflow /by-department con filtri
- ✅ Cashflow CSS cut-off granularità/anno
- ✅ Cashflow refresh on-same-year (bottone Aggiorna)
- ✅ Checkbox "Nascondi non fatte" pill restyle
- ✅ Messaggio "quote APPROVATE" riscritto

## Ordine proposto affronto

**Sprint 1 (1-2 sessioni)** — CR data integrity P0:
1. CR-2 ore double-count (cambio aggregation cost_line_sync)
2. CR-1 voci stima senza booking (capire root cause + fix)

**Sprint 2 (2-3 sessioni)** — Phantom redesign P0:
Tutto il piano [[project-phantom-quote-redesign]] in un commit grosso (modello + 5 endpoint + UI + AI prompt + migration + tests).

**Sprint 3 (1-2 sessioni)** — Filtri planning P1:
3. TL-3 filtro lavorazione (subfiltro progetto)
4. TL-4 filtri "per progetto" view
5. TL-5 ricerca testuale full-text
6. TL-1 filtro reparto multi-chip restyle
7. TL-2 risorse limitate filtro reparto (indagine prima)

**Sprint 4** — Polish P2:
8. TL-6 risorse tronche in coda

Vedi anche [[project-integrity-invariants]], [[project-costreport-vs-timesheet]], [[project-reverse-quote-flow]].
