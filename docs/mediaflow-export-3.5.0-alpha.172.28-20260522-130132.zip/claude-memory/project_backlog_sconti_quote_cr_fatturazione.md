---
name: project-backlog-sconti-quote-cr-fatturazione
description: Backlog architettura — propagazione sconti quote (package/category/line) al cost report e alla fatturazione. Verificare incongruenze JCL.total_quoted (post-sconti?) vs Quote.total_after_discount. Da chiarire con Matteo 2026-05-20+.
metadata: 
  node_type: memory
  type: project
  originSessionId: ae7121f8-f3d5-4226-82f0-44f11f236422
---

Matteo (2026-05-20) chiede chiarimento sulla gestione sconti quote nelle dinamiche CR e fatturazione.

**Sconti esistenti nel modello**:
- `QuoteLine.allowance` (mark-up % per riga, positivo o negativo, applicato per primo)
- `QuoteLine.line_discount_pct` (sconto % per riga, applicato dopo allowance)
- `Quote.category_discounts` (JSON {categoria: pct} — sconto su sottototale categoria)
- `Quote.package_discount` (sconto % sul subtotal post-categoria)
- `Quote.subtotal_gross` (pre-sconti), `Quote.subtotal` (post-riga+categoria), `Quote.total_after_discount` (post-pacchetto = base IVA)

**Domanda aperta — da indagare**:
1. Al converti quote→job, `JobCostLine.total_quoted` = `QuoteLine.total` (post riga, pre categoria/pacchetto) o include anche category+package?
2. Nel CR `Σ JCL.total_quoted` quadra con `Quote.total_after_discount`?
3. Sconti category+package come si distribuiscono sulle JCL? Pro-quota? Riga "sconto" separata?
4. Fatturazione batch: applica sconti? Su quale base?

**Why:** se le JCL ereditano solo line_discount, gli sconti category+package "spariscono" lato CR (Σ JCL > Quote totale) o vengono persi in fatturazione (over-bill cliente).

**How to apply:** prima di toccare nuove feature CR/billing su quote scontate, fare audit dei 3 punti sopra + confermare comportamento con Matteo. Probabile fix con riga "Sconto package/categoria" auto-aggiunta come JCL negativa al convert, o pattern alternativo da decidere.
