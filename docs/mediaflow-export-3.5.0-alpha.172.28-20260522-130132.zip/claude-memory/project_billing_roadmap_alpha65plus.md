---
name: project-billing-roadmap-alpha65plus
description: OBSOLETO 13 mag 2026 — i punti 4/5/6 sono tutti implementati. Mantenuto per storia decisioni semantiche.
metadata: 
  node_type: memory
  type: project
  originSessionId: aee59fbb-738b-48af-9f45-73a48b33b3c4
---

> **⚠ MEMORIA OBSOLETA (marcata 2026-05-13).**
>
> La roadmap "punti 4/5/6" del 8 mag 2026 sera è stata interamente realizzata
> tra α.65 e α.93. Conservo questo file SOLO come storia delle 3 decisioni
> semantiche prese, perché la prossima persona che tocca quei flussi deve
> sapere PERCHÉ funzionano così. Per il backlog vivo, vedi `docs/STATO.md`
> e l'ultimo `project_session_*.md`.

## Stato reale (verificato contro codice α.93)

| Punto roadmap originale | Stato | Modello / route |
|---|---|---|
| 4. Weighted hours (multiplier OT/notte/festivo) | ✅ implementato | `Tenant.overtime_multiplier/night_multiplier/sunday_multiplier/holiday_multiplier`, `overtime_brackets` JSON, `BookingOvertimeStatus`, `Job.weighted_revenue` (α.65) |
| 5.a Cost-side risorsa | ✅ implementato | `Resource.internal_cost_hourly`, `JobCostLine.total_cost_accrued` (α.66.21) |
| 5.b InvoicePayment | ✅ implementato | `InvoicePayment` model (line 1515 in models.py) |
| 5.c Cashflow timeline | ✅ implementato | `/finance/cashflow` esistente con fixes α.88 |
| 6. SupplierInvoice modulo | ✅ implementato | `Supplier`, `SupplierInvoice`, `SupplierInvoicePayment` (lines 1358-1490), router `/suppliers` |

## Decisioni semantiche storiche (ancora valide)

Le decisioni prese al momento dell'implementazione, citate qui per
mantenere traccia (utili se si deve estendere o cambiare comportamento):

1. **Overtime conteggio** — solo `approved` conta col moltiplicatore;
   `pending` mostrato in tooltip "+€X pending approvazione" senza alterare
   numeri cost-report. Coerenza: i numeri restano stabili finché manager
   non firma. Vedi `app/services/billable_hours.py`.

2. **Conversione day-unit con OT** — lineare. Una giornata 8-22 con
   6h OT × 1.30 = 13.8h pesate → 1.725 giornate-equivalenti (per unit=day).
   Niente colonna nuova `weighted_hours` su JCL.

3. **Booking interni** (kind != project) — esclusi dal conteggio billable.
   Sono manutenzione/R&D/training, no JCL.

4. **Cost report categoria "Spedizioni"** (α.94) — auto-creata via
   `_get_or_create_shipping_price_item(db)` al primo Shipment con
   `shipping_payer=charged_to_client`. PriceCategory + PriceItem dedicati,
   markup di default 15% su `Project.shipping_markup_pct`.

## How to apply

Quando un'attività menziona "punto 4/5/6 della roadmap": rispondi che è
fatto, indica il modello concreto, e rimanda a STATO.md per il backlog
attuale. NON proporre re-implementazione.
