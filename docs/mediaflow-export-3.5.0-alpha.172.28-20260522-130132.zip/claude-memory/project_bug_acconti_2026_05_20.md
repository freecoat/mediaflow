---
name: project-bug-acconti-2026-05-20
description: "2 bug architetturali segnalati Matteo 2026-05-20 — Bug 1 allocation acconto su JCL sbagliate, Bug 2 maturato fantasma su voci non time-based. Findings code-only, DB inspect pendente."
metadata: 
  node_type: memory
  type: project
  originSessionId: ae7121f8-f3d5-4226-82f0-44f11f236422
---

Matteo segnala 2 bug durante uso remoto MediaFlow (alpha.171.11). Inspect DB pendente (richiede accesso macchina Mac).

## Bug 1 — Allocation acconto su JCL sbagliate

Sintomo:
- User crea quote, definisce schedule acconto 30% selezionando Dailies + LTO LTFS archive come copertura
- Quote convertita in job
- CR detail mostra "Saldato acconto" su Master DCP standard, Master ProRes 4444 XQ, Proxy ProRes 422 HQ, Manual QC
- NON mostra alcuna copertura su Dailies + LTO selezionati
- /finance mostra "bozza acconto pending" → AP esiste con status=pending

Findings code-only:
- (a) **PUT /quotes/api/advance-schedules/{id}** (`app/routers/quotes.py:1024-1071`) NON accetta `allocations` form param. Solo POST le salva. Modifiche post-create perdute silenziosamente.
- (b) **fill_sequential ignora pct user-defined per riga** (`app/services/advance_schedule_to_payment.py:151-180` + commento α.166). Itera QuoteAdvanceAllocation per `id ASC`, take = min(JCL.total_quoted, remaining). Pct dell'utente per riga viene scartato. Comportamento "intended" α.166 ma user-confusing.
- (c) **Idempotency block re-materialize**: se quote convertita PRIMA di definire allocations, AP_alloc nasce vuoto. Aggiunta allocations dopo non rigenera (skip su `quote_advance_schedule_id` esistente).
- (d) **Open question**: nessuna spiegazione code-only del perché badge appare su JCL DIVERSE da quelle in alcuna allocation. Possibili cause da verificare in DB:
  - residui vecchi AP/AP_alloc su DB remoto (progetti soft-deleted con AP non purgati)
  - bug versioning quote: JCL.quote_line_id punta a QuoteLine v1, AP_alloc create da quote v2
  - quote convertita 2 volte (rare path)

## Bug 2 — Maturato fantasma su voci non time-based

Sintomo:
- CR mostra maturato (total_accrued > 0) su LTO Archive, Master ProRes 4444 XQ, Proxy ProRes 422 HQ, Mastering DCP standard
- Nessun booking done su quelle voci

Root cause CONFERMATA:
- `app/services/cost_line_sync.py:386-393` (α.171 CR-1 — regola "binary unit"):
  ```python
  if is_time:
      new_qty_actual_final = new_qty_actual   # ore done convertite
  else:
      quoted_q = jcl.quantity_quoted or 0.0
      new_qty_actual_final = quoted_q          # SEMPRE = quoted
      expected_qty = quoted_q
  ```
- Per `unit ∈ {pc, lump, lot, shot, version, allow, TB, GB, fix}` → JCL nasce con `quantity_actual = quantity_quoted` SEMPRE, anche senza booking done.
- LTO Archive (TB), Master DCP/ProRes/Proxy (pc), Manual QC (lump) → tutti binary → 100% maturati appena JCL creata.

Decisione semantica originale (memory `project_session_15mag2026_audit_maratona`): "voce binary acconto/spento, se a preventivo è 'fatta'". Da rivedere con Matteo perché user-confusing.

## Stato

- Findings logged. NESSUN fix applicato.
- DB inspect pendente (Matteo torna su macchina Mac).
- Backlog: anche audit sconti quote→CR→Fattura (memory `project_backlog_sconti_quote_cr_fatturazione`).

## Riferimenti file

- `app/routers/quotes.py:1024-1071` — PUT update_advance_schedule (missing allocations)
- `app/routers/quotes.py:937-1021` — POST create_advance_schedule (OK)
- `app/services/advance_schedule_to_payment.py:89-227` — materialize_schedules
- `app/services/cost_line_sync.py:248-518` — recompute_cost_line_actual + binary unit branch
- `app/routers/cost_report.py:106-172,507-563` — CR aggregato + detail con AP coverage
