---
name: 17 capitolati reali disponibili in docs/capitolati_esempio/
description: Corpus completo per Fase 2 e refactor listino — copre cinema, TV, streaming, distribuzione internazionale
type: project
originSessionId: b023d553-0ef8-4520-b045-492feb89994c
---
In `docs/capitolati_esempio/` ci sono 17 capitolati reali da usare come fonte per: (a) estrarre voci ricorrenti per il nuovo `LISTINO_ESEMPIO` generico, (b) popolare `DeliveryTemplate` reali in Fase 2, (c) testare E2E il parser AI.

Copertura:
- Cinema theatrical: A24 Queer (Guadagnino), MUBI Queer Exhibit C, IRDA/PiperFilm, Vision Distribution Allegato A, Veterans Sales
- TV broadcast IT: RAI Specifiche 1.4, Sky Original, Sky 5.1 Audio
- Streaming globale: Netflix, Amazon MGM
- Distribuzione TV internazionale: BETA FILM, FREMANTLE DCP, NBCUniversal TechOps v2.8 + Metadata Template v1.3, ContentArmor Cheat Sheet

**Why:** Il listino attuale (`scripts/seed_demo.py:LISTINO_ESEMPIO`, 76 voci) è ancora basato sull'esempio TPR Berlin originale, non su un'analisi sistematica di capitolati reali. Matteo ha esplicitamente chiesto di "snellire con integrazione voci generiche estrapolate da analisi capitolati" — questo non è ancora avvenuto. Va fatto in F9–F12 prima di partire con Fase 2 vera.

**How to apply:** Quando si lavora su listino, quotazioni o `DeliveryTemplate`, attingere a questi capitolati. Per il nuovo seed: leggere i 17 documenti, identificare voci ricorrenti trasversali (DCP mastering, ProRes deliverables, audio mix Atmos/5.1, sottotitoli IMSC/SRT/STL, archive LTO, metadata XML, naming convention, QC) e proporre un listino generico ~50-60 voci coerente.
