---
name: Cost Report vs Timesheet — binari separati
description: Decisione architetturale chiarita 1 mag 2026. Cost report = quotazioni+booking (cliente/finance/fatturazione). Timesheet = HR (consulente lavoro/buste paga). Comunicano solo nel planning per disponibilità.
type: project
originSessionId: d71cc588-0b2e-4e14-9a7f-37d17ef8c470
---
**Decisione architetturale (chiarita da Matteo, 1 mag 2026)**: cost report e timesheet sono due binari separati comunicanti solo nel planning per coordinare disponibilità risorse.

- **Cost report** = quotazioni + job + **booking** (lavorazioni progetto) + hardcost. Lente: cliente / finance interno → fatturazione/invoice. Hardcost nascosti al cliente.
- **Timesheet** (TimePunch) = ore di lavoro del personale. Lente: HR + amministrazione → consulente del lavoro → buste paga.

**Why:** Eviti che le timbrature finiscano nei costi cliente. Le ore "lavorate sul progetto" sono BOOKING (intenzione effettuata), non punch (presenza fisica al lavoro).

**How to apply:**
- Quando lavori su cost report: parti da `Booking` + `JobCostLine` + `Expense`, NON da `Timesheet`.
- Quando lavori su HR/buste paga: parti da `TimePunch` + `WorkingHoursPolicy` (compute_overtime), NON da Booking.
- Il fatto che `app/routers/cost_report.py` attuale aggreghi `Timesheet` per ore è **legacy pre-booking** = tech debt da rifare in futuro.

**Conseguenza per overtime workflow (v3.4.32)**: gli straordinari da approvare/rifiutare riguardano i **booking** (overtime_status sul Booking), non i timepunch. Le timbrature mantengono il loro engine `compute_overtime()` separato per HR.
