---
name: DAM digital ≠ physical (modelli separati)
description: Asset digital e physical asset (LTO/HDD/CRU/Blu-Ray) sono modelli DB SEPARATI, non un discriminator. Entrambi possono essere archiviati internamente O consegnati al cliente
type: project
originSessionId: 32a94049-6da5-4a2f-9917-ca6eb4ce9eb0
---
L'asset library ha **due modelli distinti**:

1. **`Asset`** (esistente) — file digitali: ProRes, DCP, IMF, immagini, audio masters, sub files, ecc.
2. **`PhysicalAsset`** (nuovo, da α.66.9) — supporti fisici: LTO tape, HDD USB/EXT, CRU drive (DCP fisico), Blu-Ray, DVD, Cases/packaging

**Why:** Matteo decisione 10 maggio: "gli asset digital possono finire negli asset physical e questo creerebbe confusione". I due tipi si gestiscono differentemente (location fisica, courier tracking, batch number, expiry calibrazione tape vs metadata video, codec, container, durata) e mescolarli in un unico modello con discriminator porta a campi NULL sparsi e UI ambigua.

**How to apply:** in α.66.9 modellare `PhysicalAsset` con campi propri (kind, capacity, serial, manufacturer, batch, condition, location). `JobDeliverable` ha 2 FK opzionali mutually-exclusive: `digital_asset_id` o `physical_asset_id` (ma non entrambi). Ortogonale: ogni asset ha `is_internal_archive: bool` + `is_delivered_external: bool` perché un drive può essere SIA archiviato internamente SIA aver generato una copia consegnata. Stesso pattern applicato a entrambi i modelli.
