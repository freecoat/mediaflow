---
name: Funzione futura "Dialogo con il cliente" su DAM/Reportistica
description: Portale cliente con cost report, DAM viewer, info aggiuntive, scheda progetto a sezioni configurabili
type: project
originSessionId: 73b0a440-ba67-42e1-847b-2d242e61f050
---
Visione futura (post-F1/F2/F3): aprire una finestra "Dialogo con il cliente" come canale lato-cliente del progetto. Componenti:
- visualizzazione cost report (filtrato per ciò che il cliente può vedere)
- DAM viewer per asset condivisi del progetto
- form per inserimento informazioni aggiuntive da parte del cliente
- scheda progetto con sezioni/funzionalità abilitabili dall'utente interno (admin/manager) — il cliente vede solo ciò che è stato esposto

**Why:** Matteo l'ha menzionato il 2026-04-27 come direzione strategica successiva al refinement copilot+enrichment. Allinea con la visione "hub di coordinamento umano-AI" di MediaFlow estendendola al perimetro cliente.

**How to apply:** Quando si tocca DAM, cost report, o si progetta sharing/portali esterni, considerare questo orizzonte: serviranno permessi granulari per-progetto-per-cliente, link condivisione tokenizzati, e una "vista cliente" ridotta. Probabilmente Fase 5 o 6, dopo che gestione utenti+ruoli (F2) e cestino (F3) sono stabili.
