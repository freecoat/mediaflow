---
name: Invarianti di integrità Quote↔Job↔Booking↔Resource
description: Decisioni architetturali fissate in v3.4.55+v3.4.56 dopo paradossi cost-report. Vincoli HARD-BLOCK e auto-sync per evitare stato incoerente.
type: project
originSessionId: 9d06b2ee-2245-4126-a559-e060097d228f
---
Fissato in v3.4.55→v3.4.56 (3 mag 2026) dopo 5 paradossi segnalati da Matteo:

**Invariante 1 — Eliminazione QuoteLine/JobCostLine HARD-BLOCK su booking attivi**
- Una `QuoteLine` non può essere cancellata se la `JobCostLine` collegata ha `Booking` con `status != cancelled`. HTTP 409 con elenco booking ostativi.
- Stessa policy per `JobCostLine` (extras): no soft-detach `Booking.job_cost_line_id → NULL`. Quel pattern (v3.4.36) generava booking orfani senza lavorazione → cost report vuoto pur con booking nel planning.
- **Modifica resta consentita** (descrizione, qty, prezzo). Solo eliminazione bloccata. Per togliere la riga: cancellare prima i booking, poi la riga.
- TimePunch resta soft-detach (HR separato dal cost report).

**Invariante 2 — Vista lavorazione DEFAULT read-only**
- Click su riga in `/jobs/{id}` apre `modal-line-detail` (KPI Quotato/Maturato + booking + risorse + origine quote line).
- Bottone "Modifica" appare SOLO se `view_finance` (admin/manager/producer/accounting). Editor/operator vedono read-only.
- Endpoint canonico: `GET /jobs/api/{job_id}/cost-lines/{line_id}/detail`.
- Override `quantity_actual` richiede `edit_cost_actuals` (admin/manager/accounting; producer NO). Default = sync da booking done.

**Invariante 3 — Auto-assignment Resource → Job**
- Ogni booking che cita una risorsa su un job DEVE garantire l'esistenza di `JobResourceAssignment(job_id, resource_id)`. Senza questo, il report ore-per-risorsa-su-progetto non funziona.
- Service: `app/services/resource_assignment_sync.ensure_resources_assigned_to_job()` (idempotente, eredita role/rate da `Resource`).
- Hook in `POST /planning/api/bookings` (forward + recurrence). Reverse-flow è coperto perché il booking POST avviene DOPO il promote/reverse-attach.
- **v3.4.56**: aggiunto pre-save confirm client-side via `GET /planning/api/jobs/{id}/resource-coverage?resource_ids=...`. tlbSubmit chiede conferma esplicita all'utente quando ci sono risorse missing prima di salvare il booking.

**Invariante 4 — Maturato in man-hours, non shell-hours**
- `cost_line_sync._booking_hours(b)` = `sum(assignments durations)` (man-hours), allineato con `reverse_quote.compute_quantity_from_hours`.
- Esempio: 2 colorist × 8h booking → 16 man-hours → 2 giornate-colorist se `unit=day`. Era 1 giornata (shell-duration) → maturato sottostimato.
- Eccezione futura possibile: `PriceItem.aggregate_hours_per_resource: bool` per voci "una giornata di X" indipendenti dal numero di operatori. Non implementata in v3.4.55.

**Invariante 5 — Job nascosto, mai mostrato all'utente in booking** (da v3.4.53)
- Booking modal parla Quote+Lavorazione (con filtro reparto risorse). Job esiste solo come puntatore interno.

**Backlog chiuso in v3.4.56**:
- ✅ Notifica `quote_approved_no_resources` (NotificationKind nuovo, non bloccante): hook in `PUT /quotes/api/{id}/status` quando `status=approved` + job ha 0 `JobResourceAssignment` → `notify_permission(assign_resources, severity=action_required)` ad admin/manager/producer.
- ✅ Pre-save confirm risorse non assegnate (vedi Invariante 3).

**Docs di riferimento (v3.4.56)**:
- `docs/workflow.md` — 5 diagrammi Mermaid (state Quote, state Booking, flow forward+reverse+phantom, fonti Maturato, vincoli HARD-BLOCK).
- `docs/data-model.md` — erDiagram entità + classDiagram con flag/stati + tabella decisioni architetturali.
- `docs/permissions-matrix.md` — matrice permesso × ruolo + permessi gate-keeper per azioni critiche.
- Mermaid renderizza nativamente in GitHub. Snapshot, non fonte di verità (la fonte resta `app/services/rbac.py` + `app/models/models.py`).
