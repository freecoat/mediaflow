---
name: Port mobile — scope e tempistica
description: Valutazione port mobile rimandata a fine sviluppo. Scope ridotto: staff operativo first, finance read-only, planning limitato.
type: project
originSessionId: 0263d296-50b8-401c-b650-d6bee2f64a60
---
Port mobile **non in roadmap attiva**. Da valutare una volta completato lo
sviluppo desktop. Scope deciso il 6/5/2026:

**In scope mobile (priorità decrescente)**:
- **Parte "user" / staff operativo** — primary target: timbratura,
  "mie assegnazioni di oggi", richieste ferie, notifiche
- **Overview finance** — read-only: stato cost report, totali job, no editing
- **Planning** — **funzionalità limitate** (non drag pesante su timeline):
  vista lista verticale dei booking per giorno, accettare/rifiutare
  assegnazioni proprie, no editing massivo

**Fuori scope mobile**:
- Quote editing pesante (50+ righe), gestione listino, gestione clienti,
  ruoli/permessi, gestione capitolati, planning timeline drag-multi

**Why**: la complessità del planning desktop (vis-timeline, multiselect,
multidrag, bulk edit) non è trasportabile su touch in modo soddisfacente.
Meglio mobile come "compagno" del desktop per consultazione + azioni
rapide, non sostituto.

**How to apply**:
- Nelle decisioni di design correnti, **evitare di legare logica di
  business solo alle pagine ricche** — assicurarsi che gli endpoint REST
  espongano i dati in JSON pulito (oggi `/planning/api/bookings` ok,
  `/cost-report/...` da verificare quando serve)
- Se nuove feature toccano "mie ferie", "miei booking", timesheet o
  notifiche: tenerle endpoint-driven così la futura UI mobile può
  riusarle senza rifacimento
- Strada raccomandata quando arriveremo: **PWA con scope ridotto** (3–4
  settimane), Capacitor solo se serve App Store. Niente React Native.
- Promemoria: vis-timeline non è touch-friendly → la vista mobile
  planning sarà DIVERSA (lista verticale, non timeline)
