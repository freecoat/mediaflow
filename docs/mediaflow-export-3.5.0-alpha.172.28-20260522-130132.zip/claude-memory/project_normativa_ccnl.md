---
name: Normativa lavoro CCNL parametrizzata
description: Ferie/malattia → normativa italiana per ora. Straordinari → contratti CCNL caricabili in impostazioni. Matteo cerca i CCNL applicabili al post-prod.
type: project
originSessionId: d71cc588-0b2e-4e14-9a7f-37d17ef8c470
---
**Decisione (1 mag 2026)**: il calcolo di ferie/malattia/straordinari NON è hardcoded ma deve essere parametrizzato per normativa applicabile.

- **Ferie/malattia**: normativa italiana per default. Calcolo conteggio sempre conforme a legge.
- **Straordinari**: contratti nazionali (CCNL) come impostazione caricabile. Matteo sta cercando i CCNL applicabili al post-prod.

**Why:** Il prodotto deve essere portabile a case di post diverse, ognuna potenzialmente con CCNL differenti (CCNL Cinema, Industria, Audiovisivo Pubblicità, ecc.). Hardcoding = rifare ogni volta.

**How to apply:**
- I moltiplicatori `WorkingHoursPolicy` (overtime/night/sunday/holiday) sono già parametrizzabili → bene.
- Quando Matteo porta i CCNL, aggiungere preset/template scaricabili in `/settings#policies` (es. "Carica CCNL Cinema", "Carica CCNL Pubblicità") che popolano una WorkingHoursPolicy con i valori del contratto.
- Per ferie/malattia: leggere la normativa italiana per giorni minimi, cumulabilità, indennità → entità tipo `LeavePolicy` o estensione `WorkingHoursPolicy` con campi `paid_leave_days_per_year`, `sick_leave_max_days_paid`, ecc.
- v3.4.32 (overtime booking) **non implementa** il caricamento CCNL — usa policy default attuale. Quando i CCNL arrivano, è solo un nuovo seed di policy.
