---
name: project-pass-through-ot
description: "Pass-through OT al cliente — Matteo dice \"non sembra cambiare nulla\". Da spiegare con esempio numerico + verificare flusso UI domani."
metadata: 
  node_type: memory
  type: project
  originSessionId: 0e7f74d6-1669-407d-aeea-3310737e3d50
---

## Cosa fa il toggle (codice)

`Job.weighted_revenue: bool` (default False). Toggle UI: `/cost-report/api/job/{id}/weighted-revenue` POST `enabled=true|false`.

Quando ON: il maturato cliente (`JobCostLine.total_accrued`) viene
ricalcolato usando `compute_assignment_breakdown.weighted_factor`:
overtime/notte/domenica/festivo gonfiano il revenue cliente.

## Dove dovrebbe mostrare differenza

1. **Cost Report KPI**:
   - "Maturato totale" più alto quando ON
   - "Margine stimato" più alto
   - "Over/Under" cambia segno se sforamento si trasforma in extra fatturabile
2. **Voci di costo** colonna Maturato/Fatturato per ogni riga
3. **Export PDF cliente** mostra giornate equivalenti pesate

## Esempio numerico da preparare per Matteo

Booking 1 giornata 8:00-22:00 (14h):
- Ore regolari: 8h (giornaliero)
- OT: 6h (× 1.30 coefficiente)
- `weighted_factor` = 8 + 6×1.30 = 8 + 7.8 = 15.8h equiv → 15.8/8 = 1.975 giornate equiv
- JCL @ 500€/giorno:
  - **OFF**: total_accrued = 1.0 giorno × 500 = 500€ (giornata fisica)
  - **ON**: total_accrued = 1.975 giorni × 500 = 987.50€ (pass-through)
- Δ = +487.50€ fatturati al cliente

## Cosa verificare domani

1. UI mostra effettivamente differenza? Toggle scatena `recompute_for_job()` da `cost_line_sync.recompute_for_job(db, job_id)`. Verifica:
   - Bookings devono avere `overtime_status=approved` (pending non conta)
   - Verifica `working_hours_policy` su Resource: i coefficienti devono essere definiti
   - Recompute deve aggiornare `quantity_actual` su JCL con unit='day' o 'giornate'
2. Se nessun booking ha OT approved → differenza = 0 → "non sembra cambiare nulla" è atteso.
3. Test: trovare job con booking OT approved nel db, attivare toggle, ricaricare cost report, confrontare KPI.

## Possibili cause "non cambia nulla"

A. **Nessun booking con OT approved** sul job che Matteo stava testando → atteso 0 delta
B. **WorkingHoursPolicy mancante** sulla risorsa → `weighted_factor` = 0 (vedi `_resource_policy_for_cost`)
C. **JCL unit non in (day, giornate, giorno, d)** → conversione ore→giornate skipped (vedi `cost_report.py:621`)
D. **Bug**: `recompute_for_job` non propaga `weighted_revenue` flag correttamente

## File chiave
- `app/routers/cost_report.py:652+` toggle endpoint
- `app/services/cost_line_sync.py:recompute_for_job` ricomputa JCL.quantity_actual
- `app/services/overtime.py:compute_assignment_breakdown` calcola weighted_factor
- `app/models/models.py:1101 Job.weighted_revenue` flag

## Risposta breve da dare a Matteo

"Pass-through OT cambia solo quando: (a) booking ha overtime_status=approved,
(b) WorkingHoursPolicy della risorsa ha coefficienti OT definiti, (c) JCL è
in giornate (unit=day). Se mancano: delta=0 → 'nessuna differenza' è
corretto. Domani identifico un job con OT approved e mostro l'esempio
numerico (8h reg + 6h OT × 1.30 = 1.975 giornate equiv invece di 1.0
fisica). Differenza visibile in KPI 'Maturato totale' del cost report."
