---
name: project-phantom-quote-redesign
description: "Ridisegno semantico Phantom Quote (Quotazione a Consuntivo) — single-per-progetto, stand-by, accorpamento crea versione, propagazione su CR. Da implementare post-α.170."
metadata: 
  node_type: memory
  type: project
  originSessionId: 76dd9ecc-d850-456e-ad46-d0f8304818f4
---

Decisione Matteo 19 maggio 2026 durante test α.170. Phantom quote attuale (introdotta α.5 reverse-flow) ha semantica ambigua. Ridisegno completo:

**Naming**: `PHANTOM` → `Quotazione a Consuntivo` ovunque (label UI, AI prompts, tooltip, docs). DB enum `is_phantom` resta per back-compat, label cambia.

**Cardinalità**: SOLO 1 phantom per progetto (UNIQUE per `tenant_id + project_id WHERE is_phantom=True`). Tentativo creazione 2° → 409.

**Lifecycle**:
- Stato STANDBY (default alla creazione). Resta finché commerciale/account decide:
  - **Promozione**: phantom diventa quote effettiva (`is_phantom=False`)
  - **Accorpamento**: voci phantom mergiate su quote esistente del progetto → crea nuova VERSIONE della quote target (quote_versioning già esiste α.39). Voci phantom svuotate o phantom eliminata.

**Accorpamento su quote APPROVATE**: permesso. Crea nuova versione. Le voci CR già esistenti vengono aggiornate (link al nuovo quote_line_id).

**Voci**:
- Voci phantom legate a PriceItem (sempre via listino, mai voce libera per phantom)
- `quantity_quoted = 0` di default
- `quantity_actual` = ore "fatte" da booking done (sincronizzato live)
- Nuove lavorazioni che arrivano da booking → si auto-legano alla phantom esistente del progetto (via PriceItem categoria)

**Pre-condizioni creazione phantom**:
- Progetto NON deve avere quote attiva (status: sent/approved). Phantom solo se nessuna quote effettiva o tutte quote sono draft/rejected/expired.

**Modifica quote APPROVATA**:
- Permesso ma con doppia conferma UI: "Modifica quote approvata?" + "Salva nuova versione (vN+1)?"
- Elimina voce → propagazione automatica su CR:
  - Job che usa quella voce ma con `quantity_actual = 0` → ELIMINATO definitivamente
  - Job con `quantity_actual > 0` → voce si stacca dalla quote e si attacca alla phantom del progetto (creata automaticamente se non esiste)

**Implementazione tecnica**:
1. Add `phantom_status` enum su Quote: standby | promoted | merged_into (+ `merged_into_quote_id` FK)
2. Add unique partial index `uq_phantom_per_project`
3. Endpoint `POST /quotes/{id}/promote-phantom` (single Apply)
4. Endpoint `POST /quotes/{id}/merge-phantom-into/{target_quote_id}` (crea versione + sposta voci + dismiss phantom)
5. Pre-save validation `propose_new_item_and_line` AI: se progetto ha quote attiva, blocca creazione phantom
6. Booking creation flow: se non c'è quote_line → cerca phantom progetto → crea voce phantom con quantity_quoted=0
7. Quote approved edit: doppia confirm dialog + auto-versioning + propagazione delete voce
8. CR rendering: phantom voci visibili con badge "📌 a consuntivo" + flag su row

**Impatto su esistente**:
- Reverse-flow attach-implicit-approval (memory `project_reverse_quote_flow`) → ora va sotto phantom semantica nuova
- AI capability `propose_new_item_and_line` (memory M1 quick wins) → must check phantom existence
- Quote versioning (α.39) → estensione per accorpamento

**Backlog priority**: post test estensivo α.170. Lavoro grosso (modello + 5 endpoint + UI + AI prompt + migration). Stima 2-3 sessioni.

Vedi anche [[project-reverse-quote-flow]], [[project-integrity-invariants]], [[project-anomaly-workflow]].
