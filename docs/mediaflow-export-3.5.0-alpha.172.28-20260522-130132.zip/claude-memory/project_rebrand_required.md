---
name: Rebrand obbligatorio (mediaflow già preso)
description: "Il nome 'mediaflow' è già usato da altri prodotti, va sostituito prima di un eventuale lancio commerciale. Non proporre 'mediaflow' come nome ufficiale e tenere conto del rebrand quando si scrivono materiali pubblici."
type: project
originSessionId: 4b152a59-e33c-47b7-bf80-0617c93d8763
---
Il nome **mediaflow** non è disponibile per il prodotto: esistono già aziende/SaaS che lo usano. Va trovato un nuovo nome prima di qualsiasi uscita pubblica.

**Why:** Matteo lo ha confermato esplicitamente l'8 maggio 2026 mentre lavoravamo su α.55. Non è solo una preferenza estetica, è un vincolo legale/marketing.

**How to apply:**
- Non riferirsi a "mediaflow" come nome definitivo del prodotto in materiali pubblici (README pubblico, marketing copy, scheda tecnica progetto pubblica, copilot welcome message ecc.). Per ora il codice interno e le path lo conservano (working title), va bene così — il rename del codice è lavoro a sé quando il nuovo nome sarà scelto.
- Quando si toccano stringhe utente-visibili (titolo browser, footer PDF, email transazionali, header report cliente), preferisci formulazioni neutre tipo "il sistema" / "la piattaforma" se il contesto lo permette, oppure flagga la stringa come "da rebrandare".
- Se Matteo chiede brainstorming nomi, partire dal posizionamento: piattaforma di gestione + AI-copilot per case di post-produzione audiovisiva, italiano, evocativo del flusso pipeline post.
- Punti del codice dove il nome è hard-coded (NON refactoringli ora, solo per inventario al momento del rebrand): `app/main.py` FastAPI title, `app/config.py` `app_name`, `CHANGELOG.md` header, `docs/STATO.md` header, README, `app/templates/base.html` titolo + nav header, `scripts/seed_demo.py` email demo `@mediaflow.it`, `app/services/pdf_export.py` headers, `app/templates/components/copilot.html` welcome.
- Path filesystem `mediaflow_fase1bis` resta finché Matteo non rinomina la cartella di lavoro — rinominarla è destructive per i path nel `.claude/` e va fatto da lui di proposito.
