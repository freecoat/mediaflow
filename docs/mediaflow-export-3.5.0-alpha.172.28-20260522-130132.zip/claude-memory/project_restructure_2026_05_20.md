---
name: project-restructure-2026-05-20
description: "Ristrutturazione architetturale JCL→CR→Fatt→Cashflow decisa con Matteo 2026-05-20. JCL solo time-based, Deliverable per pc/TB/allow/shot. PhysicalAsset 1:1. Hard-delete admin cascade. Phantom Z esteso. Spec completa in docs/RESTRUCTURE_2026_05_20.md."
metadata: 
  node_type: memory
  type: project
  originSessionId: ae7121f8-f3d5-4226-82f0-44f11f236422
---

Sessione 2026-05-20 — restructure architetturale concordata con Matteo. Spec dettagliata in `docs/RESTRUCTURE_2026_05_20.md` (committata nel repo).

## Decisioni chiave

1. **JCL = solo unità temporali** (`hr`, `day`). Maturato deterministico da booking done. Fix Bug 2 maturato fantasma.
2. **JobDeliverable = consegne** (`pc`, `TB`, `allow`, `shot`, `lot`, `lump`, `version`, `fix`, `GB`). 1 row per qty unitaria. Maturato manuale (+ asset link verifica). Cost split equo dai booking M:N linkati.
3. **Booking ↔ Deliverable M:N** via nuova pivot `booking_deliverables`. Drop `Booking.job_deliverable_id` singolo.
4. **Asset digital cost=0**, verifica only. **PhysicalAsset 1:1 progetto**, drop AssetMembership N:M.
5. **Phantom Z esteso** a deliverable extra (non solo JCL).
6. **Hard-delete progetto** admin-only cascade FULL (anche fatture, nessun archivio orfane). Solo test-mode.
7. **DeliverableBilledSlice** separato da JCLBilledSlice (no polimorfismo).
8. **Tassonomia `unit`** configurabile via nuova `pricelist_units` (nature: time_based / deliverable_qty / deliverable_volume / manual_allow).
9. **DeliverableSpec** tabella richiamabile da booking (codec/resolution/framerate/naming/target_size_tb).
10. **VFX shots** anchor point ora, sistema completo dopo.
11. **Yoyotta MHL** preferito + CSV LTO fallback per auto-fill quantity_delivered su deliverable_volume.
12. **external_outsourced** migrato a JobDeliverable `lump` (manual confirm da SupplierInvoice).

## Sprint plan (5 sprint)

1. Schema + backfill (migrazione idempotente, JCL non-time → Deliverable)
2. Service layer (cost_line_sync rifatto, deliverable_cost_sync nuovo, reverse_quote esteso, project_purge)
3. Endpoint nuovi (hard-delete admin, confirm-delivery, link-deliverable, yoyotta-mhl, csv-lto)
4. UI (editor quote split JCL/Deliverable, CR sezioni separate, kanban consegne)
5. Migration UX (tool one-shot voci storiche, warning admin)

## Decisioni finali sessione 2026-05-20

- **AP per Deliverable**: tabella separata `advance_payment_deliverable_allocations` (no polimorfismo).
- **Sconti**: proporzionali spalmati DENTRO ogni sezione (JCL e Deliverable separate). Quote ha `subtotal_gross_jcl` + `subtotal_gross_deliverable`. PDF mostra 2 sezioni con sconti propri.
- **Cashflow horizon**: configurabile per-utente, default 90gg. Sub-categorie SEPARABILI (JCL maturato / Deliverable confermato / Acconti / Fatture emesse / Fatture passive / Stipendi / Overhead) + toggle aggregato opzionale. Salvato in `UserSettings.cashflow_horizon_days`.
- **Backfill migration**: autospawn JobDeliverable per ogni qty di JCL non-time esistente.

## Open items minori (sprint futuri)

- AI capabilities nuove (propose_confirm_deliverable, propose_link_asset_to_deliverable)
- Bug acconti (memory project_bug_acconti_2026_05_20): risolti strutturalmente dal restructure

## Bug aperti incrociati

- `project_bug_acconti_2026_05_20` Bug 1 (allocation AP wrong JCL) + Bug 2 (maturato fantasma): entrambi rientrano nello scope restructure.
- `project_backlog_sconti_quote_cr_fatturazione`: audit sconti da fare nello stesso giro.

## Riferimenti file

- `docs/RESTRUCTURE_2026_05_20.md` — spec completa
- `app/services/cost_line_sync.py:386-393` — branch binary da rimuovere
- `app/models/models.py` — JobDeliverable estendere, AssetMembership droppare, new pivot
- `app/services/advance_schedule_to_payment.py` — materialize esteso a deliverable
