---
name: Reverse-quote flow (booking-driven)
description: Decisione architetturale fissata in v3.4.52 — un Job non nasce mai dal nulla; deriva sempre da una Quote (forward o reverse via phantom/implicit-approval)
type: project
originSessionId: 9d06b2ee-2245-4126-a559-e060097d228f
---
Cambio architetturale fissato in v3.4.52 dopo discussione con Matteo (3 mag 2026).

**Regola**: un `Job` non nasce mai con valore commerciale arbitrario. Solo due genesi legittime:
- **Forward (canonica)**: `Quote.approved` → Job auto, budget = totale quote
- **Reverse (eccezione)**: booking su progetto senza quote attiva → genera SEMPRE una QuoteLine:
  - se esiste quote `draft|sent` → attach + approvazione implicita + notify `edit_quotes`
  - se nessuna quote → crea `Quote(is_phantom=True, status=approved)` + line + Job

**Why**: prima di v3.4.52 il job poteva esistere senza quote (es. seed Sky con `budget_quoted=18000` arbitrario); Matteo ha voluto eliminare la categoria "job senza quote né cost line" come fonte di valori inventati. Ora il valore commerciale del job nasce sempre da una QuoteLine — concreta, su una voce listino, con quantità tracciabile.

**How to apply**:
- NON creare Job direttamente da UI/seed/script senza una Quote che lo origini. Il modello "extra job standalone" è scartato.
- Reverse-flow va in `app/services/reverse_quote.py` + endpoint `POST /quotes/api/reverse-attach`.
- Quantità della line reverse = derivata da `booking_hours` + `price_item.unit` (8h/giorno per `day`, 1:1 per `hour`). Non chiedere mai qty/prezzo all'utente.
- `Quote.is_phantom=True` marca le quote create reverse senza una quote pre-esistente. Visibili in `/finance` come anomalia, promuovibili a quote di riferimento toggling il flag.
- Forward extras (cliente chiede upres in più dopo approvazione): aggiungere riga in editor della quote O usare `POST /jobs/api/{id}/cost-lines` con `is_extra=True`. Niente reverse-attach per questi casi (la quote è già approved, non in draft|sent).

**v3.4.53 — UI booking parla quote+lavorazione, Job nascosto**:
- Modal booking ha **Quotazione** (autocomplete QUOTES_SEED) + **Lavorazione obbligatoria** filtrata per reparto risorse.
- `tlb-job-id` hidden contiene `quote_id` (semantica cambiata, nome HTML invariato per compat).
- Lavorazione filtrata via `GET /quotes/api/{id}/booking-lines?dept_ids=...` (cost_line per approved, quote_line per pending).
- Save: se kind=quote_line, prima `POST /quotes/api/{id}/promote-line-to-cost-line` per materializzare (approva implicit + ensure Job + crea JobCostLine), poi POST booking standard.
- L'utente non vede mai il Job. Job esiste in DB come puntatore interno.

**Apertura backlog (Matteo direttiva 3 mag 2026)**: snellire il listino (troppe voci ridondanti) per rendere il flow più immediato. Strategia: meno voci di tipo generico, più dettaglio in `description`. Da affrontare dopo aver consolidato i bookings reverse.
