---
name: Sessione 1 maggio 2026
description: Riapertura post v3.4.27 con 5 task da Matteo, chiuse v3.4.28→v3.4.31
type: project
originSessionId: 837ca0a8-af09-4ebc-b184-98628df5b201
---
Sessione 1 maggio. Riapertura con 5 task da Matteo. Chiuse 4 versioni in fila.

## Versioni chiuse

- **v3.4.28** — Fix riordino sidebar (auto-discovery DOM + riordino per-sezione, niente più liste hardcoded che vanno fuori sync) + engine notifica `job_deadline_approaching` (servizio `app/services/job_deadline_check.py` con dedup payload + 3 soglie 1g/3g/7g + lifespan boot check + endpoint trigger `POST /admin/api/check-deadlines` + `scripts/seed_test_deadline.py` con voce `[T]` in strumenti).
- **v3.4.29** — Listino laterale + drag&drop in `/quotes`. Toggle "📋 Listino" in topbar editor, layout grid 2→3 col, ricerca + 80 voci max, drag HTML5 con MIME `application/x-mf-priceitem`, drop su `#lines-card` → POST `/quotes/api/{id}/lines` con `price_item_id`. Toggle persistito in localStorage.
- **v3.4.30** — Vista calendario complessiva `/hr`. Toggle "📋 Tabella | 📅 Calendario", endpoint `GET /hr/api/calendar` (single-resource via `compute_overtime`, all-resources somma cross-policy), 7 KPI cards (Reg/OT/Notturne/Ferie/Mal/Perm/Totale), griglia 7×6 con barre colorate per giorno, click giorno → drill-down tabella filtrata.
- **v3.4.31** — Scheda tecnica progetto. Modello `ProjectTechSheet` 1:1 con `Project`, schema JSON flessibile per varianti (cameras[] indipendenti A/B/C, looks[] multipli, audio, storage, dailies, contacts[], process, notes). Tab "🛠 Scheda tecnica" in `/projects/{id}` con sub-tabs e dirty/saved indicator. Link pubblico `/public/tech-sheet/{token}` readonly con scadenza configurabile (30/60/90/180/365gg o senza). Bottone rigenera token. PUBLIC_PATHS esteso. Estensione `api()` per JSON body via `{json: true}`.

## Decisioni architetturali (v3.4.31)

Confermate da Matteo:
1. Camere come **array JSON** (no tabella separata), più flessibile per varianti FUME-style A≠B.
2. Crew con **resource_id (FK opt) + name_text fallback**.
3. Link pubblico **con scadenza** (default 90gg).
4. Storage policy **inline** (estrazione futura se ricorrenza).
5. Datarate **manuale** (no autocompletato).

## Distinzione importante che Matteo ora ha modellato

`ProjectTechSheet` (catena di lavorazione, dai 3 PDF in `docs/workflow_esempio/`) ≠ `DeliveryTemplate` (specs di consegna Netflix/A24/ecc.). I due si linkano via `delivery_template_id` opzionale sul TechSheet.

## Da fare sul Mac

1. Pull (4 versioni nuove)
2. Riavvia server: `Base.metadata.create_all()` crea automaticamente `project_tech_sheets` al boot. `_auto_migrate_columns()` non serve modifiche perché sono solo nuove tabelle/colonne JSON.
3. Hard-refresh browser (cache-buster ?v=3.4.31)
4. Test:
   - `/settings#sidebar` → drag voci dentro le sezioni (Anagrafica, Operativo…), verificare che le altre pagine mantengono i raggruppamenti originali
   - `strumenti` opzione `[T]` → crea JOB-TEST-DEADLINE; riavvia server → arriva notifica deadline a manager/admin
   - `/quotes` → apri una quote → bottone "📋 Listino" → drag una voce nelle voci preventivo
   - `/hr` → toggle "📅 Calendario complessivo" → naviga mesi, vedi sommario ferie/malattia
   - `/projects/{id}` → tab "🛠 Scheda tecnica" → compila qualche campo, aggiungi camera, look, contatto → Salva → bottone "🔗 Link pubblico" → copia URL → apri in incognito

## Backlog rimasto / cantieri non aperti

- **Cost report doppio** (interno + esterno cliente, fondamenta v3.4.21 pronte)
- **booking_conflict notify** (immediato, estende pattern v3.4.27, la timeline rileva già conflitti)
- **quote_status_changed notify** (hook in quotes router)
- **AI auto-popolazione scheda tecnica** da capitolato/Netflix Specs (cantiere a sé)
- **Resource FK** in tech_sheet contacts[] (oggi solo name_text)

## Commit & Push

**Commit fatto** a fine sessione: `9cd606f` — "v3.4.28-31 — sidebar fix, deadline notify, drag&drop listino, calendario HR, scheda tecnica" — 23 file, +2431/-93. Le 4 versioni in 1 commit unico (file overlap su `main.py`/`base.html`/`CHANGELOG.md` rendevano artificiale lo split). Granularità per-versione preservata nel CHANGELOG.

**Push**: NON eseguito. Memoria dice "push solo a major bump". Matteo a fine sessione doveva riavviare il terminale; gli ho chiesto se voleva push per testare sul Mac. Ha scelto di **chiudere il terminale prima di rispondere**. → Alla riapertura riproporre la domanda push.

## Riapertura — parola chiave

"**Riprendi da v3.4.31 — apri con il tuo ultimo commento**".

## Il mio ultimo commento (testuale, da ripetere alla riapertura)

**Sessione 1 maggio — chiuse 4 versioni v3.4.28→v3.4.31, 1 commit unico `9cd606f` (non pushato).**

### Sommario versioni
- **v3.4.28** — Fix sidebar (auto-discovery DOM + riordino per-sezione) + engine `job_deadline_approaching` (dedup payload + soglie 1g/3g/7g + boot check + endpoint admin + `seed_test_deadline.py` con voce `[T]` in strumenti).
- **v3.4.29** — Listino laterale + drag&drop in `/quotes` (toggle "📋 Listino", layout grid 2→3 col, drag HTML5 → POST line con price_item_id).
- **v3.4.30** — Vista calendario complessivo `/hr` (toggle Tabella/Calendario, endpoint `GET /hr/api/calendar`, 7 KPI compatti, griglia 7×6, click giorno → drill-down).
- **v3.4.31** — Scheda tecnica progetto + link pubblico. `ProjectTechSheet` 1:1 con Project, schema JSON flessibile (cameras[]/looks[]/audio/storage/dailies/contacts[]/process/notes), tab editor in `/projects/{id}` con sub-tabs, link pubblico `/public/tech-sheet/{token}` readonly con scadenza configurabile (default 90gg) + rigenera token. Estensione `api()` per JSON body.

### Decisioni architetturali (v3.4.31, confermate da Matteo)
1. Camere come array JSON ✓
2. Crew con FK Resource opt + name_text fallback (per ora solo testo) ✓
3. Link pubblico con scadenza ✓
4. Storage policy inline ✓
5. Datarate manuale ✓

### Distinzione modellata
`ProjectTechSheet` (catena di lavorazione, dai 3 PDF in `docs/workflow_esempio/`) ≠ `DeliveryTemplate` (specs di consegna Netflix/A24). Linkati via `delivery_template_id` opt.

### Da fare sul Mac (al pull)
1. `git pull` → arrivano 4 versioni
2. Riavvia server: `Base.metadata.create_all()` crea automaticamente `project_tech_sheets`. Niente migration script.
3. Hard-refresh browser
4. Test:
   - **Sidebar**: `/settings#sidebar` → drag voci dentro le sezioni
   - **Deadline**: strumenti `[T]` → crea JOB-TEST-DEADLINE; riavvia server → 🔔 sui manager/admin
   - **Listino quote**: `/quotes` → "📋 Listino" → drag voce nella tabella preventivo
   - **Calendario HR**: `/hr` → toggle "📅 Calendario complessivo"
   - **Scheda tecnica**: `/projects/{id}` → tab "🛠 Scheda tecnica" → compila + "🔗 Link pubblico" → copia URL → apri in incognito

### Backlog rimasto
- Cost report doppio (interno + esterno cliente)
- `booking_conflict` notify (estende v3.4.27)
- `quote_status_changed` notify
- AI auto-popolazione scheda tecnica da capitolato
- Scheda tecnica: Resource FK in `contacts[]` (oggi solo `name_text`)

### Domanda aperta che ho posto a Matteo
**"Vuoi che pushi su origin per testare sul Mac, o prima provi locale e dopo decido?"**
→ Matteo deve rispondere su questo punto alla riapertura.
