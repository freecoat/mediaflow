---
name: Sessione 1 maggio 2026 (notte)
description: Maratona post-test sul Mac. 17 versioni v3.4.32→v3.4.38. Push completato su origin/main. Riapertura "Riprendi da v3.4.38 — apri con ultimo commento".
type: project
originSessionId: d71cc588-0b2e-4e14-9a7f-37d17ef8c470
---
Sessione 1 maggio 2026 sera→notte profonda. Ripresa dopo test Mac di v3.4.31 e proseguita fino a chiusura audit logico in 3 round. **Push eseguito a fine** (51 commit, da v3.4.32 a v3.4.38) su origin/main `60b2e09..e735495`.

## Versioni chiuse (cronologico)

- **v3.4.32** — Booking esecutivo: priorità (low/normal/high) + execution_status (planned/in_progress/done/not_done) + workflow approvazione overtime + pozzo not_done. Aggiunte 6 colonne a `bookings`, `BookingPriority`/`BookingExecutionStatus`/`BookingOvertimeStatus` enum, 3 NotificationKind (`booking_status_changed`/`overtime_pending`/`overtime_resolved`). Permesso `approve_overtime` su admin/manager/producer. Servizi `booking_cost.py` (engine costo per fascia oraria) + `booking_cascade.py` (cascade intra-day, split overtime al giorno successivo, limite night_end+1d). 6 endpoint planning + 2 cost-report. UI: `/planning` "Le mie" interattiva, dashboard "I miei booking di oggi", cost report sezioni "Ore booking per fascia" + "Pozzo not_done". Migrazione `[L]` idempotente.

- **v3.4.32.1** — Fix multi-risorsa (override permessi con cascade ristretto), bottoni durata −30/−15/+15/+30, auto-approve overtime se chi estende ha permesso, drop su festivo → workflow overtime invece di hard block, look timeline, 5 temi colori nuovi (Midnight/Copper/Plum/Teal/Mono) + 6 varianti font.

- **v3.4.32.2** — Listino flottante (position:fixed, sempre visibile), same-height top row, IVA spostata in Riepilogo (editabile inline), scaglioni overtime CCNL configurabili (`overtime_brackets` JSON + `ccnl_label`).

- **v3.4.33** — Cost report v2: refactor `/cost-report/api/job/{id}` con fonte ore = Booking. Nuovo summary canonico (bookings_hours, bookings_hours_cost, estimated_cost, margin). Endpoint `/client-pdf` con `generate_client_cost_report_pdf` (rendicontazione cliente: lavorazioni quote + extra + ore breakdown, NIENTE hardcost/rate/margine). UI: bottone "📄 Esporta PDF cliente" + KPI estesi a 8. Listino /quotes default aperto. Bug fix: `JobCostLine.price_item` relationship mancante.

- **v3.4.33.1** — Pannello "Aggiungi voce" laterale persistente (sostituisce sia il modal `#modal-add-line` che il mini-pannello `#side-pricelist`). Riusa GUI ricca con sidebar categorie + ricerca + risultati grandi cliccabili E draggable.

- **v3.4.34→.34.5** — Refactor layout editor /quotes (5 micro-fix in fila):
  - .34: Critical Assumptions compatto in topbar, "+ Aggiungi voce" rimosso, Riepilogo sopra Voci, Stato sopra Listino, riordino categorie con drag&drop multi-tbody (modello `Quote.category_order` JSON nuovo, auto-migrate)
  - .34.1: Stato a sinistra accanto a Riepilogo (grid 2 col)
  - .34.2: Listino flottante (position:fixed) + same-height top row + IVA in Riepilogo
  - .34.3: Critical Assumptions reagisce al toggle Listino (classe with-pricelist anche sul wrapper #quote-editor)
  - .34.4: Listino allargato +35% (480→650px, 440→600px sotto 1400)
  - .34.5: Fix drag&drop listino→voci (regressione v3.4.34: `#lines-body` non esisteva più)

- **v3.4.35** — Undo stack + Salva su /quotes editor. window._quoteUndoStack max 20 op invertibili: line_add, line_delete (con snapshot), lines_reorder, category_reorder. Bottoni "↺ Annulla" + "💾 Salva" in topbar. Toast post-azione con annulla cliccabile (5s).

- **v3.4.36** — Round 1 Audit (lifecycle Quote↔Job sano):
  - DELETE QuoteLine cascade JobCostLine (B1) + soft-detach Booking/TimePunch SET NULL
  - DELETE JobCostLine: stesso soft-detach
  - Auto-create JobCostLine su add QuoteLine post-Job (B3)
  - Auto-sync update QuoteLine→JobCostLine (B4), blocca 409 se job in completed/invoiced/cancelled
  - Margin cost report da total_quoted vivo (C2)
  - Script migrazione `[M]` cleanup orfani esistenti

- **v3.4.37** — Round 2 Audit (barra avanzamento job):
  - `_compute_job_progress(db, job_id)` aggrega ore booking done/totali (esclusi cancelled e pool not_done)
  - Endpoint GET `/planning/api/jobs/{id}/progress` + flag `?include_progress=true` su list
  - Colonna "Avanzamento" in `/planning?view=jobs` con barra CSS color-coded

- **v3.4.38** — Round 3 Audit (hardening logico):
  - R3.1 Invariante count_in_costs ↔ execution_status (force False quando ≠ not_done)
  - R3.2 RBAC `edit_quotes` su update_quote (PUT /quotes/api/{id})
  - R3.3 Reset original_end_datetime su shortening overtime
  - R3.4 FSM transizioni JobStatus con matrice esplicita JOB_STATUS_TRANSITIONS
  - R3.5 Cleanup Timesheet legacy nel cost report (rimossi hours_cost/hours_cost_legacy_timesheet/timesheet_summary)

## Audit logico — backlog rimasto (per round successivi)

Documentato nei limiti di v3.4.38:
- RBAC su add_quote_line/update_quote_line/delete_quote_line (lifecycle Quote)
- Pydantic schema su ProjectTechSheet.data e Notification.payload
- Asset.parent_asset_id controllo aciclicità
- Dead CSS `.side-pl-*` (mini pannello v3.4.29 obsoleto)
- FSM Job side-effect: transizione cancelled→approved non ricrea booking

## Cantieri ancora aperti / proposti ma non avviati

- **Look timeline restyle** (1+3 selezionati: deep restyle vis-timeline + storyboard view aggiuntiva) — in stand-by, attendo trigger Matteo
- **Brand & PDF customization** (BrandSettings per-tenant: logo, legal, colors, font, header/footer custom)
- **Capability AI `propose_working_hours_policy`** per preset CCNL Cinema (Distribuzione/Doppiaggio/Teatri di posa) — Matteo deve girare i CCNL applicabili
- **Cancellation Timesheet table** (Timesheet model esiste ma non più usato dopo R3.5)
- **Job side-effect su FSM** (riapertura cancelled→approved non ricrea booking; gestione delicata)
- **Step D cost report**: "Genera quote v2 dagli scostamenti" (fuori scope confermato, ricreabile manualmente)

## Decisioni architetturali consolidate (persistenti in memorie altre)

- Cost report (quote+booking+hardcost) ≠ Timesheet (HR/buste paga). Memoria `project_costreport_vs_timesheet.md`.
- CCNL parametrizzati (overtime_brackets), Matteo cerca i contratti applicabili. Memoria `project_normativa_ccnl.md`.

## Riapertura — parola chiave

"**Riprendi da v3.4.38 — apri con il tuo ultimo commento**".

## Il mio ultimo commento (da ripetere alla riapertura)

**Sessione 1 maggio sera→notte: 17 versioni chiuse v3.4.32→v3.4.38, push completato su origin/main `60b2e09..e735495`.**

### Cosa è andato in produzione

- **v3.4.32 e patch (.1/.2)**: Booking esecutivo (priorità + stato + workflow overtime + pozzo not_done) + scaglioni CCNL configurabili.
- **v3.4.33 e .33.1**: Cost report v2 con fonte Booking + PDF cliente + pannello "Aggiungi voce" laterale persistente.
- **v3.4.34 → .34.5**: Refactor layout editor /quotes (Critical Assumptions in topbar, riordino categorie drag&drop, listino flottante 650px, IVA in Riepilogo, fix regressione drag&drop).
- **v3.4.35**: Undo stack + Salva sul quote editor.
- **v3.4.36 (Round 1 Audit)**: Lifecycle Quote↔Job sano. DELETE QuoteLine cascade. Auto-create/sync JobCostLine. Soft-detach Booking/TimePunch su delete. Margine dinamico. Migrazione `[M]` cleanup orfani.
- **v3.4.37 (Round 2 Audit)**: Barra avanzamento job in `/planning?view=jobs` (verde/indigo/ambra/grigio).
- **v3.4.38 (Round 3 Audit)**: Hardening — invariante count_in_costs, RBAC edit_quotes, reset original_end_datetime, FSM JobStatus, drop Timesheet legacy dal cost report.

### Da testare sul Mac al pull (priorità)

1. Migrazione `[M]` cleanup orfani — `./strumenti.sh → m`. Idempotente, dovrebbe trovare 0 orfani sul DB Mac come ha trovato 0 in locale.
2. Lifecycle: cancella riga quote (con job collegato) → verifica che JobCostLine + booking si comportano bene.
3. Aggiungi riga quote a quote già con job approvato → verifica che JobCostLine viene creata automaticamente (`job_cost_line_created: true` nella response).
4. `/planning?view=jobs` → barra avanzamento per ogni job.
5. Layout `/quotes`: pannello listino flottante a destra (non scorre con la pagina), Riepilogo+Stato side-by-side a sinistra, IVA editabile dentro Riepilogo.
6. Modifica execution_status di un booking dal pool not_done a planned/done → verifica `count_in_costs` torna automaticamente a False.
7. Modifica status job con transizione invalida (es. completed → quoting) → 400 con messaggio chiaro.

### Backlog cantieri rimasti

- Look timeline restyle (stand-by, scelta 1+3 deep restyle + storyboard view)
- Brand & PDF customization (BrandSettings)
- Capability AI propose_working_hours_policy (Matteo cerca i CCNL Cinema)
- Round audit follow-up: RBAC su altri endpoint quote, Pydantic schema, dead CSS cleanup

### Domanda aperta che ho posto a Matteo

Niente di pendente. La sessione si chiude pulita: working tree pulito, push fatto, audit completo. Riapertura libera per scegliere il prossimo cantiere.
