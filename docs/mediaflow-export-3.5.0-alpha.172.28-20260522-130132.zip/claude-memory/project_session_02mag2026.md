---
name: Sessione 2 maggio 2026
description: 17 commit v3.4.39 → v3.4.50.1. Push completato origin/main. Matteo apre test estensivo locale Mac.
type: project
originSessionId: 22439bf8-a582-448b-9276-043107b35f6a
---
Sessione 2 maggio 2026. **Push completato `origin/main`** (17 commit cumulativi: v3.4.39 → v3.4.50.1).

## Versioni chiuse

- **v3.4.39** — Quote duplica + versioning (`parent_quote_id`, `superseded_by_id`, `parent_line_id`) + Floating Jobs + sezione "⚠ Anomalie" in `/finance` (Job orfani / Sforamenti / Extra). Migrazione `[N]` idempotente.
- **v3.4.40** — Searchable dropdowns globali in `global.js` (auto-attach a tutti i `<select>`) + Time picker popup HH:MM + split automatico `<input type="datetime-local">` in date+time affiancati.
- **v3.4.41** — Bug fix triplo: paste su ferie hard-block, Chrome timbratura layout (suppress webkit-calendar-picker-indicator), cost report ore done maturate (`app/services/cost_line_sync.py` + hook su `execution`/`extend` + endpoint `reconcile-actuals`).
- **v3.4.42** — Undo per paste timeline (type='paste_batch') + Le mie/Dashboard cliccabili → modal dettaglio booking + note booking inline.
- **v3.4.43** — Duplica quote con scelta progetto + endpoint `move-to-project` (solo draft + no job).
- **v3.4.44** — Indicatori execution_status sui booking timeline (pulse/✓/tratteggiato) + drilldown ore pianificate da `/planning?view=jobs` + tab "📂 Per progetto" (manager+/admin+/producer).
- **v3.4.45** — Look timeline deep restyle CSS + Storyboard view settimanale (7 colonne giorno).
- **v3.4.45.1** — Hotfix `/planning` 500 (`UserRole.code` accesso errato — sostituito con `is_producer()` da rbac).
- **v3.4.46** — Pannello ⚙ Look timeline customization (densità/font/accent/storyboard density/toggle anim/heatmap/today-glow/weekend-bg) persisted in localStorage `mf_tl_prefs`.
- **v3.4.47** — Filtri planning multi-select: 4 filtri autocomplete (cliente/progetto/job/risorsa) ora chip-based, hidden value comma-separated. Backend `_parse_id_list` accetta `None | int | "1" | "1,5,7" | list`.
- **v3.4.48** — Look timeline tweaks: rimossa densità, aggiunto colore sfondo (7 preset), 3D items (radius 7→9 + bevel multi-layer), fix accent "Per reparto" via CSS dinamico generato da DEPARTMENTS_SEED.
- **v3.4.48.1** — Hotfix bg timeline (libreria `.vis-timeline` ha gradient hardcoded → spostato selettore da `#tl-host` a `#tl-host[data-bg] .vis-timeline` con `!important`).
- **v3.4.48.2** — Famiglia font + colore testo nel pannello ⚙ (auto/DM Sans/Inter/System/Serif/Mono e auto/white/soft/amber/dark/indigo).
- **v3.4.49** — Script `scripts/reset_business_data.py` (voce `[O]` strumenti) per pulire entità business preservando configurazione (utenti, ruoli, listino, reparti, policy, AI settings, tenant).
- **v3.4.50** — `ResourcePreset` per selezioni multiple ricorrenti nel modal multi-risorsa booking + checkbox "🔗 Stesso orario per tutte le risorse" (preferenza localStorage `mf_tlb_sync_times`).
- **v3.4.50.1** — Audit pre-push 3 micro-fix: `seed_demo` tenant idempotente, `seed_demo` Booking+BookingAssignment coerenti, regex `-vN$` cleanup nel version number.

## Decisioni chiarite

- **Versioning quote**: numero `{root.number}-v{N}` con cleanup regex per evitare duplicati `-v1-v2`. Status `superseded` distinto da `rejected`.
- **Floating Jobs**: Job senza `quote_id` (NULL) sono leciti, vivono in `/finance > Anomalie > Job orfani`. Possono nascere da `migrate-job` con `orphan_strategy=floating_job` o da cancellazioni manuali.
- **Cost line sync**: la fonte canonica delle ore è il Booking. `JobCostLine.quantity_actual` viene aggiornato dai booking `done` via service `cost_line_sync.py`. Endpoint `reconcile-actuals` per fix retroattivo.
- **Reset business data NON cancella tenant**: scelta architetturale per mantenere config. `seed_demo` ora è idempotente sul tenant per supportare il flusso seed dopo reset (in realtà il caso d'uso reale è "reset + setup manuale", il seed è pensato per `[2] reset DB completo`).
- **No multi-tenant hard**: confermato che resta in Fase 7 opzionale. Per il test online estensivo Matteo conferma "tutti i tester nella stessa azienda virtuale" (single tenant=1).

## Esito audit pre-push

Smoke test su 19 pagine: tutte 200. Endpoint nuovi tutti funzionanti (Quote duplicate/version/migrate, Anomalies, Cost reconcile, Booking detail, Project bookings, Multi-id filter, Resource presets CRUD). Flow critici: booking done → cost line sync OK, FSM JobStatus OK, count_in_costs invariant OK, RBAC update_quote OK.

## Riapertura

Parola chiave: **"Riprendi da v3.4.50.1 — apri con il tuo ultimo commento"**.

## Mio ultimo commento

Sessione 2 maggio chiusa con **17 versioni e push completato**. Matteo apre test estensivo locale sul Mac con setup pulito (reset_business_data eseguito). Quando torna dai test mi manda funzionano/bug/idee per decidere se continuare bug-fix-round o pivot strategico (era emersa la richiesta "server online + onboarding email" ma rimandata dopo il giro di test).

## Cantieri rimasti aperti / proposti

- **Round 4 Audit logico** — RBAC su add/update/delete quote_line, Pydantic schema su `ProjectTechSheet.data` e `Notification.payload`, `Asset.parent_asset_id` aciclicità, dead CSS `.side-pl-*`, FSM Job cancelled→approved side-effect.
- **Capability AI `propose_working_hours_policy`** preset CCNL — Matteo deve girare CCNL applicabili al post-prod.
- **Brand & PDF customization** (BrandSettings per-tenant: logo, legal, colors, font, header/footer custom).
- **Multi-valuta** ECB cambio (modello + service + UI + capability AI).
- **Cost report doppio** (interno arricchito vs esterno cliente, era v3.4.14/15 nel piano legacy).
- **Gantt per job** in `/jobs/{id}` (Frappe Gantt).
- **Server-side abort** per Ollama/Claude (oggi solo `AbortController`).
- **Cestino per-tenant** con retention.
- **Online deploy + onboarding email** (cantiere strategico, prematuro fino a fine test estensivo).
