---
name: Sessione 3 maggio 2026
description: 21 commit v3.4.51→v3.4.56 + v3.5.0-alpha.1→alpha.8 (reverse-flow + invarianti integrità + AI tool-use nativo Anthropic + Cestino completo Quote/Project + retention auto). Push completato.
type: project
originSessionId: 67d5f425-dd8b-4031-bb7c-66c2d36eda72
---
Sessione 3 maggio 2026: 21 commit totali, working tree pulito, push completato su origin/main (richiesta esplicita Matteo).

**Cantieri chiusi**:
1. v3.4.51 — Reverse-flow v1: job extra da booking su progetto senza quote (poi rifattorizzato in v3.4.52)
2. v3.4.52 — Reverse-flow v2: booking → QuoteLine + approvazione implicita (`attach_existing` notifica AM) o phantom quote (`Quote(is_phantom=True, status=approved)`). `app/services/reverse_quote.py`. `Quote.is_phantom` auto-migrate. Eliminati `app/services/job_extras.py` + `POST /jobs/api/reverse-extra`.
3. v3.4.53 — Booking parla quote+lavorazione (Job nascosto in UI, esiste solo come puntatore interno). Filtro reparto risorse. `GET /quotes/api/{id}/booking-lines?dept_ids=...` + `POST /quotes/api/{id}/promote-line-to-cost-line`.
4. v3.4.54 — Project filter prima della Quote nel modal booking. Cost-line RBAC con permesso nuovo `edit_cost_actuals` (admin/manager/accounting; producer/operator NO). Lock `quantity_actual` per non finance.
5. v3.4.55 — Fix sistemico 5 invarianti: HARD-BLOCK delete QuoteLine/JobCostLine con booking attivi (no soft-detach); vista lavorazione read-only `modal-line-detail`; auto-assignment Resource→Job via `app/services/resource_assignment_sync.py`; man-hours canonico (`cost_line_sync._booking_hours` somma assignments durations).
6. v3.4.56 — Pre-save confirm risorse non assegnate (`GET /planning/api/jobs/{id}/resource-coverage`); notifica `quote_approved_no_resources` (NotificationKind nuovo); 3 docs Mermaid (`workflow.md`, `data-model.md`, `permissions-matrix.md`).

**Pomeriggio 3 maggio — refactor AI tool-use Anthropic (v3.5.0-alpha.1)**

Trigger: Matteo aveva configurato Sonnet 4.6 + Tavily key (in `.env` riga 41 c'era stata una vicenda di file salvato/non salvato — risolta scrivendola direttamente). Test "aggiungi cliente Cattleya": Tavily girava ma i risultati restavano nella card UI, non rientravano mai nel modello → Sonnet non poteva proseguire dopo l'azione applicata. Diagnosi: buco architetturale, non bug puntuale.

Decisione concordata (Matteo):
- **Refactor a tool-use nativo** Anthropic + OpenAI + Gemini. Ollama + Perplexity restano sul path legacy markdown.
- **Tool readonly per DB** lookup (lookup_clients/pricelist/projects) — Slice 5.
- **Streaming risposte** — Slice 6.

**Slice 1 chiusa** (v3.5.0-alpha.1, solo Claude end-to-end):
- `app/services/ai_tools.py` — registry 9 capability con JSON Schema canonico (formato Anthropic) + converter per OpenAI/Gemini + system prompt slim
- `AIProvider.chat_with_tools()` astratto + `ClaudeProvider` concreto (Messages API tool_use)
- `app/services/ai_loop.py` — `advance_loop()` itera fino a end_turn o mutation; readonly auto-eseguite con tool_result re-injectato; mutation salvate come AIAction e loop sospeso. `resume_after_action()` riprende dopo Apply/Reject.
- Modelli: `AIConversation.tool_state` + `AIAction.tool_use_id` (auto-migrate)
- Router: `/api/chat` dirotta al loop tool-use se `provider.supports_tools()`. `/apply` e `/reject` ritornano `continuation` (text + nuove cards) dopo aver ripreso il loop.
- Frontend `copilot.js`: `copilotApply`/`copilotReject` mostrano la continuation come bubble assistant aggiuntiva.

**Slice AI tool-use chiuse a v3.5.0-alpha.7.5**:
- alpha.1: foundation Anthropic (loop tool_use, mutation gated da Apply, readonly inline)
- alpha.2: hotfix persistenza storia conversazione fra turni
- alpha.3: hotfix errore Apply visibile + ordine azioni AI nel system prompt
- alpha.4: `propose_quote.lines` con `price_item_id` (eredità dal listino)
- alpha.6: hotfix tool_use orfani + sanitizer difensivo
- alpha.7.4: tool_result più espliciti (created/message) per evitare allucinazioni AI
- alpha.7.5: rinomina inline title/number quote nell'editor

**Slice AI rimanenti** (backlog):
- Estendi a OpenAI + Gemini (function-calling) — Slice 4 originale del refactor AI
- Tool readonly DB (lookup_clients/pricelist/projects) — Slice 5
- Streaming SSE — Slice 6
- Cleanup legacy markdown action — Slice 7 (opzionale)

**Cantiere "Cestino" completo** (v3.5.0-alpha.7 + alpha.8):
- Slice 1: soft-delete framework Quote (event listener filter, `_SOFT_DELETE_MODELS`, AIConversation.tool_state pattern, etc.)
- Slice 2: UI quote (tasto 🗑 lista + topbar editor, dialog 409 con can_force admin)
- Slice 3: pagina /admin/cestino con tab per entity-type
- Slice 4: Project soft-delete (HARD-BLOCK su quote attive, cascade purge_total)
- Slice 5: retention auto (`trash_retention_days`, dry-run preview, bottone "⏱ Purga scaduti")
- Hotfix: alpha.5 (sidebar section drag), alpha.7.1 (JSON.stringify in onclick), alpha.7.2 (escapeHtml block scripts), alpha.7.3 (collisione UNIQUE su number cestinato)

**Push completato**: tutti i 21 commit su origin/main (sera 3 maggio).

**Riapertura**: "Riprendi da v3.5.0-alpha.8 — apri con il tuo ultimo commento" (test estensivo locale Matteo: cestino quote/progetto + AI Cattleya/Gomorra/ISIDE flow + rinomina inline editor).

**Test sul Mac (priorità)**: vedi sezione "Da testare sul Mac" in docs/STATO.md. Casi chiave:
- Reverse-attach quote draft/sent (implicit approval + notifica AM)
- Phantom quote (Quote.is_phantom=True)
- Booking parla quote+lavorazione (Job nascosto)
- HARD-BLOCK delete QuoteLine con booking attivo (409 con elenco)
- Vista lavorazione read-only per non finance
- Auto-assignment + pre-save confirm
- Man-hours: 2 colorist × 8h → quantity_actual=2 giornate
- Cost-line RBAC: editor/operator non può editare quantity_actual
- Notifica quote_approved_no_resources
- Workflow docs Mermaid renderizzati su GitHub
