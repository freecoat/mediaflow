---
name: Sessione 5 mag 2026 sera-notte
description: Maratona Round 9 (17 punti) + Round 10 (7 punti) chiusi tra v3.5.0-alpha.22→alpha.25; push fatto con DB snapshot alpha.25; Matteo testa domani su altra macchina.
type: project
originSessionId: 8f04dc07-7db0-4b20-9824-5cbac3081f6c
---
Sessione 5 maggio 2026 sera-notte tardi. **6 commit pushati** a origin/main:

- `93f5920` alpha.22 — Round 9 part 1/3: HR pausa pranzo + ferie/malattia in lista + conflict block + 5 quick wins timeline UX (doppio click edit, hover orari, semaforo priorità, booking detail più info, sort priorità)
- `4a331f9` alpha.23 — Round 9 part 2/2: timeline drag bugs (cross-resource refresh, multi-select drag, dept-compat block, split-pause unit drag, click+drag create) + ombra timbrature toggle + DB snapshot iniziale
- `dee044c` alpha.23.1 — hotfix `/health` version hardcoded
- `299caa9` alpha.24 — Round 10: planning UX refinement (look ferie uniformato, hover ferie/malattia/festivo, hover job orari espliciti, dedupe risorse split-pause, semaforo più grande, pannello selezione filter-style con glow animato)
- `2bb2eff` alpha.25 — Scheda cliente AI con filmografia (cantiere medio, modello ClientWork + service filmography + 5 endpoint + tab UI + 2 modal). Tavily `include_domains` ristretto a filmitalia.org / cinema.cultura.gov.it / imdb.com / mymovies.it. Smoke test live: 14 fonti consultate, 6 opere proposte per "RAI Documentari".
- `75e21f1` db_snapshots refresh — snapshot DB allineato ad alpha.25 (con tabella `client_works` + record di smoke test).

**Why:** Matteo ha dato 3 tornate di feedback successive (post-test alpha.21, alpha.23, alpha.24). Tutti i punti chiusi tranne uno discusso e poi confermato (filmografia AI con fonti pubbliche italiane).

**How to apply:**
- Riprendere da test Matteo su altra macchina (porting via `db_snapshots/snapshot-3.5.0-alpha.25.db`).
- Punti aperti per la prossima sessione = quelli che emergeranno dal test su altra macchina.
- Cantieri ancora rinviati (non urgenti): KDM form in DAM (rimasto da alpha.21).

**Cose nuove introdotte da non dimenticare:**
- `time_punches.break_minutes` (auto-migrate al boot) — pausa pranzo sottratta da overtime engine
- `client_works` table (auto-create al boot) — filmografia per scheda cliente
- Helper backend `_parse_priority` in `app/routers/planning.py` per priority form param
- `_dedupeBookingSegments` in planning.html per gestire booking split-pause multi-segmento
- Pannello selezione filter-style: `tlSelectPanelToggle` + animazione `tl-pulse-glow`
- ROI Alt/Shift+drag DISABILITATO (non rimosso, codice in archivio nel template)
- `db_snapshots/` con eccezione `!db_snapshots/*.db` in .gitignore

**Stato push:** repo freecoat/mediaflow privato. v3.5.0-alpha.x è la serie aperta verso 4.0.0. Push fatto stanotte via richiesta esplicita Matteo (deroga alla regola "push solo a major bump") perché serviva il DB snapshot per porting test domani.
