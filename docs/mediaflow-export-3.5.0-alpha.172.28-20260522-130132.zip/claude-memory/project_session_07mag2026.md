---
name: Sessione 7 mag 2026
description: Maratona α.41→α.51 (15 versioni). Font HTMLElement, multi-move atomico, sticky multi, sidebar collapse, manuale wiki, freeze Chrome (heatmap toggle/light mode/Bitwarden falso positivo), avvio billing flow 4 step (modello+API+UI cost+UI finance+ritira+preview periodo), copilot in-depth planning, upload documenti.
type: project
originSessionId: fca8b616-da35-4723-a2de-0b4205dd63c7
---
Sessione 7 maggio 2026, lunghissima. Aperto su 2 bug da ieri (font + multidrag), chiuso con 15 commit + 5 epic feature.

## Commit (15) e cosa hanno chiuso

**Round bug-fix planning (mattina):**
- α.41 — Font label timeline via HTMLElement. Diagnosi: vis-timeline 7.7.3 strippa class+style annidati negli HTML string passati come `group.content`. Fix: passare `HTMLElement detached` con `document.createElement` + `style.cssText` + `textContent` invece di stringa concatenata. `tlHeatmapHTML` → `tlHeatmapElement`. Header reparto invariato (single `<span>` root, già funzionante).
- α.42 — Multi-move atomico + sticky multi-selection. Diagnosi: `onMove` chiamava 3 funzioni separate (`_tlDoMove` + `_tlApplySplitPauseShift` + `_tlApplyMoveToOthersInSelection`) → push frammentato (14 undo per ripristinare!), conflitti spurii (check su stato intermedio), booking spariscono (render parziale). Fix: nuovo endpoint `POST /planning/api/multi-move` atomico transazionale con conflict check escludendo TUTTI gli aids della transazione + frontend `_tlApplyMultiMove` con dedup automatico (anchor + sibling split + altri della selezione + loro sibling) + 1 push undo + 1 renderTimeline. Sticky multi: `tlInstance.on('select')` con loop guard sincrono `window._tlSuppressSelect` — click su item della multi → preserva. Rimosse 2 funzioni legacy.

**Round UI quality-of-life (pomeriggio):**
- α.43 — Sidebar collassabile + Manuale d'uso wiki. Toggle topbar Ctrl+B, larghezza 64px, label nascoste via `font-size:0` (mantiene textContent per tooltip), tooltip flottante hover 1s, `localStorage.mf_sidebar_collapsed`. Pagina `/manuale` (router help.py): TOC sticky + content + search client-side + IntersectionObserver + 11 sezioni con bozze contenuti.
- α.44 — Heatmap toggle + altezza dinamica + finestra standalone. Bottone 📊 Heatmap toolbar (default OFF), `tlComputeHeight(host)` da viewport con resize listener debounce 150ms, route `/planning/full` (refactor `_planning_render` helper), bottone ⛶ Finestra `window.open('/planning/full')` con popup features.
- α.45 — Bulk visibile + sort "Fatto" in fondo. Bottone Bulk sempre presente disabled+grigio, attivo+indigo+counter `(N)` su selezione. Sort `_cmpByPrioThenDate`: execution_status terminale (done/not_done) sempre in fondo.

**Round freeze Chrome (sera):**
- α.44.1 — HOTFIX rangechanged DOM thrash. Skip rebuild groups se heatmap OFF, dedup range signature, throttle 500ms, batch update.
- α.46.1 — Mitigazione Bitwarden DOM observer (data-bwignore + autocomplete=off). FALSO POSITIVO: in incognito (no estensioni) il freeze persiste.
- α.46.2 — Modalità leggera timeline (vera causa). Bottone 🪶 Light: `stack:false` (no overlap O(N²)), skip background items (ferie/festa/punch × risorse), no animation/transition CSS. Trace mostra PageAnimator rAF da 225ms picco. Conclusione finale: freeze SOLO Chrome/Mac specifico (PC funziona, Firefox funziona) — non bug MediaFlow.

**Round Cost Report → Billing flow (notte):**
- α.46 — Step 1 modello dati: enum (JCLBillingStatus, BillingBatchStatus, LossReason), modelli BillingBatch, BillingBatchLine, LossEntry. JobCostLine esteso (billing_status/billing_batch_id/billed_amount). Auto-migrate al boot per le 3 colonne JCL. Script `scripts/migrate_billing_flow.py`.
- α.47 — Step 2 API: 9 endpoint sotto `/finance/api/billing` (transmit, list, get, edit-line con LossEntry auto, approve, invoice con number manuale, cancel rilascia JCL, override jcl status, project loss summary). Auto-numero BB-{anno}-{NNN}. Snapshot immutabile lines. Cap sicurezza approved ≤ proposed × 1.5.
- α.47.1 — HOTFIX Bulk button non attivava dopo ROI/Esc. Vis-timeline non emette `select` event per `setSelection()` programmatico. Helper wrapper `_tlSetSel(ids)` che wraps setSelection + tlOnSelectionChange + sync `_tlPrevSelection`. Sostituite 2 chiamate "nude" (ROI + Esc clear). Le 4 select-by-* funzionavano già.
- α.48 — Step 3 UI Cost Report: colonna `Fatt.` con badge colorato per JCL stato, marcatore `[extra]` arancio, widget Fatturazione (5 card sommario + lista batch cliccabili `/finance#batch-{id}`), bottone 📤 Trasmetti con modal periodo/extras/note.
- α.48.1 — Bottone ↩ Ritira su card batch (visibile solo draft|approved). Confirm + cancel endpoint α.47 → JCL rilasciate, LossEntry cancellate, batch → cancelled.
- α.48.2 — Periodo trasmissione auto da work_date booking (richiesta Matteo). Endpoint `GET /finance/api/billing/preview` calcola period_start/end da min/max work_date JCL candidate (popolate da cost_line_sync su booking done). Modal mostra anteprima count/totale + label sorgente periodo (📅 from_bookings vs ⚠ fallback). Submit disabilitato se zero candidate.
- α.49 — Step 4 UI /finance batch. Tab `📦 Batch fatturazione` con badge giallo count draft, lista filtrata, modal dettaglio (920px) con lines editabili inline (manager+ su draft, prompt loss_reason se ridotto), bottoni dinamici per status (Approva/Cancel/Emit/Vai a fattura), modal emit con anteprima IVA live, pannello Perso aggregato per progetto con breakdown by_reason. Auto-load batch al boot per badge tab + deep-link.

**Round copilot integration (notte tardi):**
- α.50 — Copilot in-depth planning. Sezione PIANIFICAZIONE VIVA in `build_context` (booking 14gg, conflitti top10, carico per risorsa con badge 🟢🟡🔴 vs cap 40h, indisponibilità, job critici deadline ≤30gg, filtri project/job). 3 capability nuove: `propose_move_booking` (shift/new_date/new_resource/remap), `propose_resize_booking` (delta_minutes su ultimo segmento per preservare split pause), `propose_delete_booking` (soft + recompute_for_booking). Tool spec `ai_tools.py` + handler `ai_assistant.py`. System prompt rinforzato con 7 regole planning. Quick prompts contestuali nel drawer per pagina (`/planning` ha 7, `/cost-report` 3, `/quotes` 3, ecc.). Renderer card UI per le 3 nuove.
- α.51 — Upload documenti per copilot. Servizio `copilot_attachments.py`: save → uploads/copilot/{uuid}.{ext}, extract testo PDF (pypdf) / DOCX (python-docx) / TXT/MD raw, dimensioni immagini (Pillow), embed inline `📎 ALLEGATO: header + content`. Endpoint `POST /ai/api/upload`. Frontend: bottone clip + drag&drop overlay + lista allegati pending con badge tipo/size/× rimuovi + stati uploading/error. Snapshot+reset on send. Cleanup auto > 7gg in lifespan. Mount /uploads pubblico. Limiti MVP: 20MB, 50k chars estratti, niente persistenza DB, immagini con placeholder testuale (vision integration in α.52).

## Lezioni dure / non-ovvie

- **Vis-timeline 7.7.3 strippa class+style negli HTML string annidati** (header reparto sopravvive perché single `<span>` root). Soluzione: HTMLElement detached.
- **Vis-timeline 7.x emette `select` event SOLO per click utente**, non per `setSelection()` programmatico. Wrapper helper obbligatorio per ROI/clear/select-by-*.
- **Multi-move atomic richiede `~BookingAssignment.id.in_(aids_set)` nel conflict check** server-side, altrimenti gli assignment in volo si "vedono" tra loro come conflitto.
- **Freeze Chrome/Mac**: causa profonda è hardware/Metal renderer + interazione vis-timeline molti DOM nodes. NON bug MediaFlow (PC e Firefox OK). Workaround: light mode toggle.
- **Performance trace Chrome**: numeri vis-timeline (FunctionCall) sono i tempi DENTRO le sue funzioni JS — i RunTask dominanti sono task NATIVE del browser (Layout/Paint/Composite) triggerati dalle DOM mutations. Quindi 2.4s vis-timeline ≠ 33s totali RunTask.

## Aperti per domani

1. **TEST tutto α.41→α.51 sul Mac** — Matteo riprende dopo il test
2. **Fattura formale PDF** — rimandato da stasera (Matteo stanco):
   - PDF stampabile da batch invoice α.49
   - Anagrafica cliente (P.IVA, codice fiscale, indirizzo, PEC, codice destinatario SDI)
   - Dati aziendali del proprietario software (configurazione tenant settings: ragione sociale, P.IVA, sede, IBAN, logo, ecc.)
   - Estensione modello Client per dati fiscali completi (se mancanti)
   - Settings registry tenant_company per dati aziendali
   - Generazione PDF via ReportLab (già usato per quote PDF)
3. **Vision integration immagini copilot α.52** — Anthropic Messages API + OpenAI vision: image_url block nei messages. Modificare `build_messages` per provider con vision capability. Senza vision, le immagini caricate restano solo placeholder testuale.
4. **Capability copilot avanzate** (futuro):
   - `propose_recurring_bookings` (serie ricorrente lun-ven X-Y)
   - `propose_bulk_move` (sposta N booking di delta)
   - `analyze_conflicts` (read-only: trova + suggerisci risoluzioni)
   - `find_free_slots` (cerca slot liberi per risorsa/reparto/giorno)
   - Notifiche proattive sul FAB se rilevati problemi
5. **Step 5 Cost Report flow** (α.50 originale, sospeso per copilot in-depth):
   - Notifica fine mese auto → suggerisce trasmissione batch
   - Producer "Chiudi progetto" → fattura finale + perso aggregato
   - Report finanziario annuale completo

## Stato attuale

- Versione: **v3.5.0-alpha.51**
- Branch: `main`, pushato fino a `e9ea999`
- Database: nuove tabelle billing_batches/lines/loss_entries auto-create al boot. JCL estesa.
- Niente migrate manuale richiesta (auto in `_auto_migrate_columns`)
- Test in attesa: tutto, ma in particolare il flow billing end-to-end e il copilot in-depth planning
