---
name: Sessione 8 mag 2026
description: v3.5.0-alpha.56 — chiusura loop operativo cost report→fatturazione (4 micro-feature richieste da Matteo)
type: project
originSessionId: 99c41df6-99ab-4999-a488-ffb3b2bc33b8
---
v3.5.0-alpha.56 chiusa con 4 micro-feature in singola iterazione che chiudono
il loop "booking eseguiti → cost report → trasmissione → fatturazione":

1. **Cost report — bottone "Scarta tutte" su pool not-done.**
   Endpoint nuovo `POST /cost-report/api/job/{id}/not-done-pool/discard-all`,
   bottone in card pool. Bulk equivalente alla scarta-singola.

2. **Planning — filtro "Nascondi non fatte".**
   Checkbox sidebar `f-hide-not-done` persistito in URL. Helper
   `filterBookingsHideNotDone(bookings)` riusabile in 5 viste. Calendar
   FullCalendar richiede `events:` function source perché URL sources non
   permettono filtro post-fetch.

3. **Cost report transmit preview — breakdown quote/extra/sforamento.**
   Il toggle "Includi extra" funzionava già (verificato), ma il preview
   mostrava aggregato unico ("una unica cifra" cit. Matteo). Ora preview API
   espone `quote_count/total`, `extra_count/total`, `overrun_total`,
   `total_quoted` per riga. UI mostra pillole separate.

4. **Fatturazione batch detail — Over per riga + Rimanda.**
   Endpoint nuovo `POST /finance/api/billing/{batch_id}/lines/{line_id}/defer`
   rimuove line dal batch (draft only), JCL → not_billed, LossEntry collegate
   cancellate. Reversibile via ri-trasmissione. UI: 2 colonne Quotato+Over
   nella tabella, card aggregate Over+Extra a livello batch, bottone
   "↪ Rimanda" per riga con conferma.

**Why:** Matteo voleva chiudere il loop end-to-end con visibilità esplicita
del "fuori budget" (extra/over) e potere di decisione granulare per riga
(fattura subito vs rimanda al consuntivo).

**How to apply:** "Defer" è SEMANTICAMENTE diverso da "loss" (defer =
rimando reversibile, loss = scarto definitivo con LossEntry). Tenerli
distinti sempre. Auto-cancel batch vuoti dopo defer NO — il manager decide.

**File toccati:** cost_report.py, billing.py (con `object_session(b)` per
hydration JCL.total_quoted nel `_batch_to_dict`), 3 template
(cost_report.html, planning.html, finance.html).

Niente migrazioni DB. Niente breaking change su API esistenti (solo
add-fields).

Smoke test: 264 routes, app boot OK.
