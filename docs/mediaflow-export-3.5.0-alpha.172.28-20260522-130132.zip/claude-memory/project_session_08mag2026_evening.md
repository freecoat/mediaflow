---
name: Sessione 8 mag 2026 sera
description: Terza sessione 8 mag 2026 — α.63 (planning fix) + α.64 (billing trasmissione granulare + refer-to-sales completo). 2 commit, niente push.
type: project
originSessionId: 8562d19a-6b69-47cd-b411-574e1d20a8be
---
Sessione di sera 8 mag 2026, post sessione "8 mag notte" (riarchitettura
billing α.58→α.62). 2 commit chiusi e committati, NIENTE push (è alpha,
push solo a major).

**v3.5.0-alpha.63** — Planning fix da feedback Matteo dopo α.62
- Bulk-edit "Cambia lavorazione": dropdown candidati cross-job dello stesso
  progetto. Re-sync man-hours su VECCHIA + NUOVA cost_line. Auto-assignment
  risorse → nuovo job. Endpoint nuovo `GET /api/bookings/bulk-edit/eligible-cost-lines`.
- Guard intra-payload: stessa risorsa con OVERLAP nello stesso booking → 400.
  Segmenti contigui (split pranzo) restano permessi. Cleanup dati storici
  pre-α.63: bottone UI "🧹 Rimuovi duplicati" → `cleanup-duplicate-overlaps`.
- Feedback chiaro skip/conflict bulk: `skipped_locked_count` separato +
  `reason` umano per ogni `failed[i]`. Pannello esiti dentro modal.
- Extend-as-series: il PUT booking ignorava `recurrence_*`. Nuovo endpoint
  `POST /api/bookings/{id}/extend-as-series` chiamato dopo PUT in edit mode.
- Smoke: 268 routes (+3 vs α.62). No migration. Commit `77002c8`.

**v3.5.0-alpha.64** — Trasmissione granulare + refer-to-sales completo
Bundle 1+2+3 dalla discussione propositiva 6 punti (vedi
project_billing_roadmap_alpha65plus.md per i punti rimasti aperti):

1. Link strutturale [EXTRA] → JCL: nuova colonna
   `quote_lines.referred_from_jcl_id` (FK + ALTER al boot via _auto_migrate).
   Refer-to-sales α.62 ora valorizza il link. Badge bidirezionali viola UI:
   "↪ Da JCL #X" in /quotes (apre cost-report) e "↪ Q-NNN-NN v2" in
   /cost-report (apre quote). Risolve "vedo voce extra, a cosa corrisponde?".
2. Trasmissione granulare: modal Trasmetti diventa tabella editable con
   checkbox per JCL, subtotale dinamico, bottoni tutti/nessuno.
   `_transmit_core` accetta `jcl_ids` opzionale (CSV nel form). Back-compat
   preservata se omesso.
3. Refer-to-sales DA batch detail: nuovo bottone `↪ AM` viola in /finance
   batch detail su righe in over o extra. Atomico (rollback se refer fallisce).
   Refactor: estratto `_refer_jcl_to_sales_core` per riuso.

Smoke: 271 routes (+3 vs α.63). Migrazione idempotente al boot.
Commit `f779e83`. Niente push.

**Endpoint nuovi α.64** (totale 3):
- `GET /finance/api/billing/jcl/{id}/origin-info`
- `GET /finance/api/billing/jcl/{id}/referrals`
- `POST /finance/api/billing/{batch_id}/lines/{line_id}/refer-to-sales`

**Pattern di sessione che ha funzionato bene**:
Matteo ha chiesto "valutazione propositiva" su billing → analisi codice +
6 punti elencati (1 voce extra confusa, 2 scelta voci trasmissione,
3 refer-AM da fatturazione, 4 overtime weighted, 5 cashflow completo,
6 supplier invoice futuro) → AskUserQuestion per priorità → bundle 1+2+3
implementato come α.64. I punti 4/5/6 documentati ma NON implementati,
richiedono decisioni semantiche da fare con Matteo prima.

**Stato repo**: 2 commit avanti origin/main (α.63 + α.64). Push da fare
quando Matteo decide (regola: push solo a major bump).

**Test live richiesto a Matteo** (in STATO.md sezione α.64):
1. Trasmetti con tabella checkbox + decheck 1-2 righe → subtotale aggiornato
2. Badge bidirezionali su quote/cost-report cliccabili
3. Refer-to-sales da /finance batch detail su riga in over → atomico
4. Back-compat trasmissione classica (tutto checked di default)
