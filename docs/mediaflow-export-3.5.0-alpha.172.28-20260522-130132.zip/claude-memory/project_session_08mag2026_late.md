---
name: Sessione 8 mag 2026 (riarchitettura billing α.58→α.62)
description: Maratona 5 versioni notturne — JCLBilledSlice foundation, hard-block 409, 3 colonne, notifica extra, rimanda al commerciale
type: project
originSessionId: b93d22ee-2051-425b-84cf-787d227113bc
---
5 commit α.58→α.62 in sessione consecutiva, riarchitettura billing
concordata l'8 maggio 2026 chiusa per intero. Push NON eseguito su
richiesta esplicita di Matteo a inizio sessione.

**α.58** — `JCLBilledSlice` foundation. Modello nuovo (jcl/batch_line/
invoice/period/qty/amount). Hook in `emit_invoice`. Backfill al boot da
batch invoiced (idempotente, marker file). NO behaviour change.

**α.59** — HARD-BLOCK 409 booking dentro periodo già fatturato. Nuovo
servizio `app/services/billing_slice_guard.py` (find_blocking_slice,
find_blocking_slice_for_dates, slice_lock_message/payload). Helper
`_assert_no_blocking_slice` in router planning + ai_assistant. Applicato
a update_booking, update_assignment, delete_*, execution, bulk_edit,
multi_move, AI move/resize/delete/bulk_move. `_assert_jcl_not_locked`
rifocalizzato solo su `in_batch`. UI: classe `.tl-slice-locked` (bordo
viola + 🔒) in timeline.

**α.60** — Cost report 3 colonne slice-based. billed_locked /
accrued_post_period / forecast_future. Identità:
billed_locked + accrued_post_period = total_accrued.
billed_locked + accrued_post_period + forecast_future = total_expected.
Pre-fetch bulk in singola query GROUP BY (no N+1). KPI grid + tabella
cost lines: 3 colonne nuove sostituiscono Maturato + Stimato.

**α.61** — Notifica `extra_after_billed`. Nuovo NotificationKind. Hook
in `cost_line_sync.recompute_for_booking` (try/except non bloccante).
Idempotente: skippa se già notifica non-archiviata per la stessa JCL.
Destinatari: admin/manager/producer/accounting.

**α.62** — Bottone "↪ Rimanda al commerciale" da cost report. Endpoint
nuovo `POST /finance/api/billing/refer-to-sales` (manager+, mode
`extend_existing` | `new_linked`, optional notes). extend → nuova
versione della quote del job (parent_quote_id). new → quote indipendente
sul project. Riga `[EXTRA]` derivata da JCL.accrued_post_period.

**Decisioni semantiche di sessione**:
- Lo slice è IMMUTABILE (snapshot fattura). Modifiche post-emissione
  passano per nota credito/cancel fattura (out of scope α.62).
- Convention over_under (positivo=OVER, negativo=UNDER) invariata.
- Notifica EXTRA è action_required. Re-emit solo dopo archive/cleanup.

**Aperti per dopo test Matteo**:
- (α.59.x) endpoint di rettifica per sbloccare periodo (se richiesto).
- (α.62.1) bottone Rimanda anche in /finance batch detail.
- Push GitHub (Matteo dirà quando).
