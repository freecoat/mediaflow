---
name: Sessione 10 mag 2026 — cantiere Listino & Deliverable
description: 8 commit α.66.6→α.66.13 push fatto. Backup listino + lean 43 voci + JobDeliverable+PhysicalAsset+cost-rate + UI cost-rate + cost report split + PhysicalAsset CRUD UI + branding completo. DB di Matteo era vuoto.
type: project
originSessionId: 32a94049-6da5-4a2f-9917-ca6eb4ce9eb0
---
Sessione del 10 maggio 2026. Cantiere multi-versione **"Listino & Deliverable"** aperto su richiesta di Matteo (semplificare listino + dare modello strutturato per deliverable file/fisici + branding documenti).

**8 versioni chiuse + push a origin/main**:

| Versione | Cantiere |
|---|---|
| α.66.6 | Modello `PricelistSnapshot` + UI snapshot in `/pricelist` + opt-in Export ZIP |
| α.66.7 | Preset `legacy_2026q2_full.json` (79 voci) committato + bootstrap idempotente al boot |
| α.66.8 | Listino lean 79→43 voci (-46%) con descrizione modulare + `seed_demo.py` rifattorizzato (carica da preset) |
| α.66.9 | Modelli `JobDeliverable` + `PhysicalAsset` (separati) + cost_type Resource + naming helper 34 token / 9 preset (Netflix Picture Archival + ISDCF DCP v9) + UI MVP "Consegne" in /jobs/{id} |
| α.66.10 | UI cost-rate Resource modal /resources con live preview calcolo employee (mensile × 13 × 1.30 / 1720h) |
| α.66.11 | Cost report split cliente vs interno: helper `is_time_based_unit`, `_bookings_hours_cost(client_view=True)`, `_client_filtered_report()`, KPI viola "Hardcost ore deliverable" in /jobs/{id} per finance |
| α.66.12 | Pagina `/physical-assets` CRUD completa (LTO/HDD/CRU/Blu-Ray) con flag is_internal_archive + is_delivered_external ortogonali + tracking courier |
| α.66.13 | Tenant esteso con tagline + brand_color + show_powered_by + document_header. Service `branding.py` single source of truth. quote_pdf + cost_report PDF + invoice_pdf usano branding completo |

**Decisioni architetturali fissate**:
- DAM digital ≠ physical: modelli SEPARATI (`Asset` vs `PhysicalAsset`), entrambi con flag `is_internal_archive` + `is_delivered_external` ortogonali (memoria `project_dam_physical_assets`).
- AI derivazione costi da visura amministrativa: capitolo futuro post α.66.10 (memoria `project_ai_cost_derivation`).
- Cost-rate per tipo: employee (calcolato da mensile lordo × 13 × 1.30 / 1720h) / freelance (tariffa pagata, ≠ vendita) / studio (allocazione fissa) / external (fallback hourly_rate).
- Naming file: 34 token + 9 preset built-in. Tool generazione completo (regole, batch rename) rinviato a α.66.14+.
- Hardcost interno: ore booking attribuiti a deliverable × Resource.internal_cost_hourly. Solo cost_report INTERNO, cliente non vede.
- Distinzione time-based vs non-time-based via `unit`: day/hr/h/ore = time. pc/min/TB/GB/shot/version/allow = non-time.

**DB stato pre-sessione**: completamente vuoto sul Mac di Matteo (lui ha resettato per test estensivo).

**DB stato post-sessione**: 4 tabelle/colonne nuove auto-migrate al boot:
- `pricelist_snapshots` (tabella nuova) + 1 record preset legacy + 1 preset lean caricati al boot
- `job_deliverables` (tabella nuova)
- `physical_assets` (tabella nuova)
- `bookings.job_deliverable_id` (col nuova)
- `assets +7 col` (job_deliverable_id, is_internal_archive, is_delivered_external, delivered_at/to/method/tracking)
- `resources +7 col` cost-rate (cost_type, monthly_gross_salary, annual_bonus_months, cost_multiplier_oneri, annual_working_hours, freelance_hourly_cost, studio_hourly_cost)
- `tenants +4 col` branding (tagline, brand_color, show_powered_by, document_header)

**Riapertura concordata**: parola chiave **"Riprendi da v3.5.0-alpha.66.13 — apri con il tuo ultimo commento"**. Il "ultimo commento" è scritto in `docs/STATO.md` sezione "Prossimo step concordato".
