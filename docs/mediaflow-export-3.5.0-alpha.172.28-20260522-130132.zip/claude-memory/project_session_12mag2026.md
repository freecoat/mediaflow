---
name: project-session-12mag2026
description: Sessione 12 mag 2026 — purge DB + seed stress massivo + AI E2E + push (commit 27dd068)
metadata: 
  node_type: memory
  type: project
  originSessionId: 500648d1-0ad1-4b64-ba42-071421048286
---

Sessione 12 maggio 2026. Matteo apre MediaFlow su una nuova macchina, login admin fallito (DB residuo con password admin ignota, editor mancante). Niente bump versione, lavoro solo su dataset.

**Cosa fatto:**
- `scripts/seed_stress.py` (1.6K righe, 16 stage deterministico seed=4242): 152 user, 500 risorse, 100 clienti+748 filmografie, 1000 progetti, 1230 quote, 759 job, 8.6k JCL, 8.4k booking+20k assign, 80k TimePunch, 1.3k ferie, 1.9k invoice 5 stati+1.2k payments, 3k PhysicalAsset, 5k digital, 977 movimenti, 100 billing batch, 1.1k JCLBilledSlice. Run 131s.
- `scripts/test_copilot_stress.py`: 9 query Claude Sonnet 4.6 (3 clienti+3 progetti+3 plannings) — risposte ricche, ping OK.
- API key Anthropic incollata in chiaro da Matteo nel prompt → salvata in `.env` + UserAISettings Fernet cifrato per admin+matteo.
- `docs/users_stress.csv` (152 utenze password chiare), `docs/stress_test_report.md`, `docs/copilot_test_report.md`.
- `docs/mediaflow-stress-export-3.5.0-alpha.83-*.zip` via `build_export_zip()` ufficiale → 100% compatibile `/settings/admin/data/import` UI (8.4MB, no .env nel zip).
- Untrack `.env` (era trackato dal 5 mag commit `b087bf3`, policy ribaltata per evitare leak key).
- Push fatto `b8b8bb6 → 27dd068`.

**Credenziali demo dataset:**
- admin@mediaflow.it / admin123
- matteo@mediaflow.it / matteo123
- 150 user interni: `pwd001..pwd150` (vedi CSV).

**Sicurezza:** API key Anthropic da ruotare su https://console.anthropic.com/settings/keys — era in chiaro nella conversation log.

**Open:** test smoke UI sul dataset (1000 progetti, 80k punches, 8k booking) — non fatto questa sessione, suggerito a Matteo. Vedi [[feedback-env-untracked]].
