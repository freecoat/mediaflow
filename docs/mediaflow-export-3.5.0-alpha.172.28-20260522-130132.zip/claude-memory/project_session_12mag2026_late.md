---
name: project-session-12mag2026-late
description: Sessione 12 mag 2026 sera — maratona S1→S8 (perf planning + MFAutocomplete + MFFilterBar + plugin ecosystem + OverheadCost). 6 commit non pushati.
metadata: 
  node_type: memory
  type: project
  originSessionId: 500648d1-0ad1-4b64-ba42-071421048286
---

Sessione 12 maggio 2026 sera (post-stress test mattina, vedi [[project-session-12mag2026]]).

**Ticket Matteo 12 mag — apertura:** 18 issue raggruppate in 5 cluster (A perf planning, B search dropdown, C filtri standard, D anomalie+merge, E asset hub). Decisioni semantiche prese inizio sessione: D.1 OK / D.2 stand-by / D.3 OK / E.1 combinato / E.2 OK / F.1 yoyotta indagine futura / F.2 backlog. Screenshot planning/calendario in `docs/Logs-temp/Screenshots/` analizzati (calendario disastro: tutti 8k booking impilati = card 4px illeggibili).

**6 commit chiusi (no push, alpha bumps):**

1. **dcd43f4 v3.5.0-alpha.84 — Sprint S1 Performance planning**
   - Calendario FullCalendar: `events:` callback passa `info.startStr`/`endStr` come from_date/to_date → fetch limitato finestra visibile. `dayMaxEvents:5` + `slotEventOverlap:false` → overflow "+N altri".
   - Agenda: default range oggi → +30gg se filtri vuoti. IntersectionObserver lazy chunks (primi 7 giorni eager, restanti placeholder auto-hydrant rootMargin 300px). DOM-safe rendering (`replaceChildren` + `addEventListener`, no `innerHTML` con interpolazione `onclick`).
   - Timeline vis-timeline `tlBuildResourceGroups`: con >100 risorse senza filtro dept/risorsa, auto-filtra solo risorse con booking nel range. Override `localStorage.setItem('tl_show_all_resources','1')`. Aggiunti `maxHeight` + `verticalScroll:true`.
   - Sidebar filtri: `setView()` auto-collapse su tab `calendar`/`timeline`, auto-expand su `jobs`/`agenda`/`todo`. Override via marker `pl-filters-collapsed-user-set` localStorage.
   - File: solo `app/templates/pages/planning.html`. No DB migration.

2. **138f106 v3.5.0-alpha.85 — Sprint S2 MFAutocomplete (cashflow+forecast)**
   - Helper `MFAutocomplete({host, hidden, data, search, display, render, placeholder, onChange, multi})` in `global.js`. Single OR multi-select. DOM-safe.
   - CSS classi `mf-ac-*` + `fa-*` spostate da `planning.css` a `main.css` (ora globali).
   - Applicato `cashflow.html` + `finance_forecast.html` cf-client/cf-project. Bug "filtro non mostra clienti dopo typo" risolto (native `<select>` typeahead rotto con 100+ opt).
   - Cache-buster bump.

3. **30a0a75 v3.5.0-alpha.86 — Sprint S3 MFFilterBar + filtri standard 5 pagine**
   - Helper `MFFilterBar({host, filters:[spec...], onChange})` in `global.js`. Spec kinds: `autocomplete` (single+multi) / `date` / `select` / `text`. `dependsOn` per filtri concatenati (project_id rinfresca quando client_id cambia). `buildQS()` centralizzato.
   - Server-side: 7 endpoint estesi (`/finance/api/invoices`, `/finance/api/timesheets`, `/finance/api/billing`, `/suppliers/api/invoices`, `/dam/api/assets`, `/physical-assets/api/movements/all`, `/cost-report/api/job/{id}/booking-summary`) con filtri opzionali (client_id, project_id, from_date, to_date, tech grep).
   - UI: `/finance` filtri globali sopra tab (applicano a tutti). `/suppliers` filtri cliente/progetto/periodo. **`/cost-report` LAYOUT SWAP**: Voci di costo + Risorse/Timesheet ora SOPRA "Ore booking per fascia" (era invertito, richiesto Matteo). Filtri sezione "Ore booking" via toggle (periodo + risorse multi). `/dam` filtri standard + 12 quick chips tecnici (HDR/SDR/Dolby/Atmos/2K/4K/UHD/24fps/25fps/ProRes/DCP/IMF) grep su filename+description (Asset model no metadata strutturate — TODO `job_deliverable.spec_json`). `/physical-assets/inout` filtri cliente/progetto/periodo via IngestBatch.project_id.

4. **0e7bcd1 Sprint S7 — Claude Code plugin ecosystem (NO bump, config-only)**
   - **MCP server `mcp-fattura-elettronica-it`** (locale, 21 tool SDI/FatturaPA v1.6.1) — config in `.mcp.json` project + allowlist `enabledMcpjsonServers` in `.claude/settings.json`. Launcher `uvx` (uv 0.11.13 installato in user site `C:\Users\frico\AppData\Roaming\Python\Python314\Scripts\`). Tool: build_transmission_header, validate_cedente/cessionario, P.IVA mod-10, get_regime_fiscale_codes (RF01-19), get_tipo_documento_codes (TD01-28), get_natura_codes (N1-7), generate_fattura_xml, validate_fattura_xsd, get_sdi_filename, ecc.
   - **VoltAgent subagent marketplace** GLOBALE in `~/.claude/settings.json`. Repo `VoltAgent/awesome-claude-code-subagents`. 4 plugin enabled: voltagent-lang, voltagent-qa-sec, voltagent-data-ai, voltagent-domains (~60 subagent).
   - **3 custom skill project-scoped** in `.claude/skills/`:
     - `mediaflow-finance-feature-dev` — checklist 13-step (tenant scope, RBAC, soft-delete, JCLBilledSlice, AI capability, migration, filter-bar, notification, cache-buster, commit)
     - `italian-tax-compliance` — validazione P.IVA mod-10, CF, IBAN mod-97, codici RF/TD/N, SDI 7-char. Delega a MCP quando disponibile
     - `sdi-xml-builder` — pipeline 5-step Invoice MediaFlow → XML FatturaPA via MCP tool chain. Defaults FPR12/RF01/TD01/MP05/TP02

5. **babfc79 v3.5.0-alpha.87 — Sprint S8 Pozzo costi / Spese aziendali (OverheadCost)**
   - Cluster D.2 ticket Matteo. Decisione architetturale Matteo: design B (modello standalone), naming `OverheadCost` (code) + "Spese aziendali" (UI), threshold CAPEX configurabile in Tenant, **NO doppia tracciatura write-off** (LossEntry single source of truth, summary UNION).
   - Modello `OverheadCost` (53° classe ORM) con: code auto-num `OH-YYYY-NNNN`, category enum 11 valori (maintenance/software_license/rent_utilities/staff_overhead/capex/training/marketing/legal_admin/bank_fees/tax/other), amount + cost_date, ricorrenti (is_recurring + recurrence_interval + next_due_date + parent_recurring_id), CAPEX (is_capex + useful_life_months + amortization_method), FK contestuali opzionali (department/supplier/supplier_invoice/booking/physical_asset/source_project). Soft-delete + audit.
   - Tenant: `capex_threshold_eur` default 500€.
   - RBAC: 2 nuove perm `view_overhead` + `edit_overhead`. **Admin role auto re-sync `ALL_PERMISSION_KEYS`** (fix architetturale per nuove perm — admin deve sempre averle tutte). Manager + accounting full, producer view-only.
   - Router `/overhead` con GET page + 5 API endpoint + categories enum.
   - UI `/overhead/` con MFFilterBar + KPI 5 card (Totale/OPEX/CAPEX/Write-off LossEntry/Ricorrenti) + breakdown categoria + tabella + modal full conditional fields. Sidebar link "💸 Spese aziendali".
   - Cashflow: aggiunti `overhead_paid` + `capex_paid` per mese.
   - Migration script `migrate_overhead_costs.py` idempotente + backfill opt.

**Cluster RIMANENTI (S4 + S5 + S6):**

- **S4 — Anomalie fatturazione workflow** (decisione D.2 ORA RISOLTA via OverheadCost). Tassonomia anomalie (extra-after-billed / over-budget-rampa / quote-discrepancy / mancato-recupero / sforamento-monte-ore — Matteo OK) + 3 azioni (rimanda commerciale | rivaluta producer | pozzo costi). Multiselect. L'azione "manda al pozzo costi" ora ha 2 strade: write-off → LossEntry esistente, costo recurring/aziendale → OverheadCost nuovo.
- **S5 — Cashflow + Forecast/Pipeline merge** in 1 pagina con tab "Combinato" default (Matteo OK).
- **S6 — Asset Media Hub** (BACKLOG, yoyotta/Frame.io/MediaShuttle/Pix/Mnemonica — indagine API necessaria, post lancio).

**Memory aggiornate questa sessione:** [[feedback-env-untracked]] (mattina), questa sessione_late (sera).

**Open su riapertura:**
1. Matteo testa S8 `/overhead/` su dataset stress (oppure salta a S4 senza test).
2. Decisioni semantiche S4 da confermare: anomaly types nomi finali + esistono già altre? Mantenuto in attesa.
3. API key Anthropic ancora da ruotare (vedi [[project-session-12mag2026]]).

**Stack tecnico aggiunto:**
- Helper UI riusabili: `MFAutocomplete`, `MFFilterBar` (entrambi in `global.js`).
- `.mcp.json` + MCP `fattura-elettronica-it` (per restart Claude Code).
- 4 plugin VoltAgent globali + 3 custom skill project-scoped.

**6 commit non pushati** (b8b8bb6 → babfc79). Push rinviato a major bump (memory [[feedback-push-solo-major]]).
