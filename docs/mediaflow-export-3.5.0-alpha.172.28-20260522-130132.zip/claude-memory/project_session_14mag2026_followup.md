---
name: session-14mag2026-followup
description: Backlog confermato Matteo notte 13-14 mag — temi chiari aggiuntivi + analisi timeline ordinata. Da affrontare giornata 14 mag.
metadata: 
  node_type: memory
  type: project
  originSessionId: fa24e2d1-492d-44f7-9d34-b3258d8b1b39
---

Backlog confermato Matteo notte 13-14 mag 2026 (post α.111.2 push):

**Temi chiari aggiuntivi** (confermato):
- Oggi solo `sand` chiaro in `app/templates/pages/settings.html` (lista THEMES riga 707).
- Aggiungere: `paper`, `ivory`, `light-mono` (palette light bilanciate).
- File coinvolti: `settings.html` (lista THEMES) + `app/static/css/main.css` (data-theme="paper|ivory|light-mono" blocks).

**Why:** Matteo vuole più scelta nei temi chiari per setup studio diversi (DI/grading vs commerciale vs broadcast).

**How to apply:** quando si torna a /settings, aggiungere i 3 temi nella lista THEMES + relative CSS variables. Mantenere stesso pattern degli scuri.

**Timeline — analisi ordinata** (rinviato a domani):
4 problemi tracciati in tabella T1-T4 (vedi conversazione):
- T1 altezza non adattiva
- T2 linee separazione sovrapposte ai nomi risorsa
- T3 heatmap sparito
- T4 sovrapposizione bookings

**Why:** Matteo a rischio di chiedere reset frontend totale timeline se i fix iterativi non bastano.

**How to apply:** prima di toccare codice, fare diagnosi con screenshot reali + console output `JSON.stringify({h, gs, items})`. Identificare se problema è DOM/CSS/JS/library. Solo dopo proporre fix mirato O reset chirurgico per componente (non bulk).

Vedi anche: [[feedback_vis_timeline_quirks]] per i 3 limiti documentati vis-timeline 7.x.
