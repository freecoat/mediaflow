---
name: project-session-16mag2026
description: Sessione 16 mag 2026. Chiusa α.119 (2 fix smoke E2E) + ARCHITETTURA.md PDF condivisione team + checklist post-audit α.114-118 eseguita batch 1-5 + 24 finding accumulati α.120 backlog. Interrotta a metà fix F14 PDF cancelled. Riprendere da stato WIP.
metadata: 
  node_type: memory
  type: project
  originSessionId: 2d02b59b-3641-44fa-b273-ba15559e468d
---

# Sessione 16 maggio 2026

## Lavoro chiuso

### v3.5.0-alpha.119 (commit `22c8334`)
Cost_external priority ranking + auto-dismiss drift self-healed. 2 finding smoke E2E post-α.118:
- F1: total_cost_external double-counted su JCL multiple stesso job (filtro OR-soup).
- F2: anomaly cost_estimate_vs_real_drift open zombie post-fix causa.

Fix:
- `cost_line_sync.py`: priority ranking esclusivo (jcl > job > project) + helper `_count_jcl_matching_resources` pro-quota.
- `anomaly_detector.py`: auto-dismiss block in `detect_cost_estimate_vs_real_drift` (status=dismissed + handled_action=auto_resolved).
- `models.py`: nuovo enum `AnomalyAction.auto_resolved`.

### docs/ARCHITETTURA.md + .pdf (commit `2985157`)
Doc sintesi condivisione team:
- Mindmap visione completa 9 rami funzionali
- Layer diagram, ER, flusso operativo, sequence AI co-pilota
- 8 diagrammi mermaid embedded in PDF 476 KB
- `scripts/build_arch_pdf.py` pipeline riproducibile (mmdc → HTML → Chrome headless)

## Lavoro in corso (interrotto)

### Checklist post-audit α.114-118 — eseguita
- Round α.113 Q1-Q11: 3 pass, 8 con finding
- Round α.114 A1-A16: 6 pass, 4 con finding maggiore (A4 = F12-F15)
- Round α.115-118: server-side ✅, UI con F3 conferma + F24
- Trasversali: T1 ✅

**24 finding accumulati** classificati P0 (6 bloccanti), P1 (8 UX), P2 (10 architetturali).
Vedi [[project_alpha120_backlog]] per dettaglio completo.

### α.120 fix P0 — in corso
- ✅ F22 Resource.supplier_id delink — `resources.py` raw form parsing, distingue '' clear da missing. Test E2E completo passato.
- 🔄 F14 PDF cancelled block — `finance.py` + `billing.py` modificati con check 409. UI hide bottone DA FARE.
- ⏳ F15 NC PDF
- ⏳ F12+F13 Cashflow NC + status real-time
- ⏳ F3 CR list valori falsi (CRITICO)

**Modifiche uncommitted** (da committare in α.120 finale):
- `app/routers/resources.py`
- `app/routers/finance.py`
- `app/routers/billing.py`

## Punto di ripresa per prossima sessione

1. **Restart server** `cd <proj> && .venv/Scripts/python.exe -m uvicorn app.main:app --port 8000 --log-level warning`
2. **Verifica F14 backend** — test E2E: pick invoice cancelled, tentativo download PDF → atteso 409
3. **F14 UI** — `app/templates/pages/finance.html:1196` aggiungere condizione `i.status === 'cancelled'` per hide bottone download
4. **F15** — leggi `app/services/invoice_pdf.py` + `pdf_export.py`, capire come NC genera linee. Fix: branch is_credit_note → solo voci della fattura stornata + intestazione progetto/cliente
5. **F12+F13** — leggi cashflow query (probabile `app/services/financial_reports.py` o router `finance.py` cashflow endpoint). Fix: subtract NC, refresh status real-time
6. **F3** — debug `app/templates/pages/cost_report.html` JS init + `/cost-report/api/reconcile-status` polling. Root cause: first load non triggera reconcile, mostra JCL stale
7. **Commit α.120** — bump main.py + CHANGELOG + STATO + commit + export ZIP

## DB state side-effect minori (informativi)

- invoice 111 status=`overdue` (era sent, transition legit α.114 test)
- supplier_invoice 131+132 soft-deleted
- 2 anomaly entries `cost_estimate_vs_real_drift` dismissed `auto_resolved`
- numbering_configs `overhead_cost` esplicito = default (no-op)
- backup locale `mediaflow.db.bak-pre-smoke-20260516-094339` untracked

## Comando rapido per riaprire

```bash
cd "C:/Users/frico/OneDrive/Documents/Claude/Projects/mediaflow_fase1bis"
git status
.venv/Scripts/python.exe -m uvicorn app.main:app --port 8000 --log-level warning &
# nuova sessione Claude: "leggi project_alpha120_backlog + project_session_16mag2026, riprendi da F14 UI hide bottone"
```
