---
name: project-session-16mag2026-maratona
description: "Maratona 16 mag 2026: 17 commit α.119→α.134. Backlog P0/P1/P2 chiuso + Fase 5 capitolati + 2 AI capability + i18n base + finding Shadow. Punto ripresa α.135 documentato."
metadata: 
  node_type: memory
  type: project
  originSessionId: 2d02b59b-3641-44fa-b273-ba15559e468d
---

# Sessione 16 maggio 2026 — Maratona α.119 → α.134

17 commit accumulati, 24 finding chiusi nei round audit, 2 AI capability nuove (filesystem + send invoice), i18n base IT/EN/FR/DE, sweep terminologia JCL→Lavorazione, refactor architettura cashflow + cost_external + naming builder + supplier↔resource flow + Fase 5 capitolati corpus + QoL template.

## Lista commit cronologica

```
f1d914e α.134 — F25 widget Quotato vs Fatturato + analisi Shadow Stagione 3
38b3431 α.133 — i18n GUI base (IT/EN/FR/DE) switcher topbar
cff114e α.132 — DeliveryTemplate export JSON + duplica
328b653 α.131 — Fase 5 corpus diagnostica + parse on-demand
f06fc95 α.130 — AI capability propose_send_invoice_email + refactor helper
7558eb1 α.129 — AI capability query_filesystem (asset library locale)
e2a74f5 α.128 — Fase 5 quick-load esempi nel wizard import
ad908b5 α.127 — P2.C F11 supplier↔resource inverso + F6 invio email SMTP
749d5ea α.126 — P2.E revamp /team /resources /departments + filtri
e35e361 α.125 — P2.A.2 sweep fallback id + F19 ratio_net precision
f9e514b α.124 — F7a/F7b naming builder modal + editor inline
039e46e α.123 — F16 IVA toggle + F19 split cashflow per reparto
92ebac7 α.122 — F17/F24 sweep terminologia JCL→Lavorazione
19bdef9 α.121 — 7 fix UX P1 da backlog α.120
e29bd59 α.120 — 6 fix bloccanti P0 da checklist post-audit α.114-118
22c8334 α.119 — Cost_external priority ranking + auto-dismiss drift
2985157 docs: ARCHITETTURA.md + build single PDF script
```

## Stato finale

**Branch**: `main` 17 commit ahead di `origin/main` → PUSHED al termine sessione.

**Capabilities AI totali**: 33 (era 30 pre-sessione).

**Documentazione**: docs/ARCHITETTURA.md (~430 righe) + ARCHITETTURA.pdf (476 KB, 8 diagrammi mermaid) — primary share document per team.

**i18n**: scaffolding base completato (sidebar+topbar+login). Espansione TUTTA UI → F29 in α.135 backlog.

## Backlog α.135+ (priorità)

Findings nuovi da uso reale 16 mag tarda (Matteo). Salvati in memoria [[project_alpha134_findings]]:

### Urgenti
- **F26** disaccoppiamento Invoice.lines vs JCLBilledSlice (3 pattern candidate, raccomandato B = visibilità UI)
- **F27** JCL billing_status="paid" + bookings 0 done → semantica fuorviante. Distinguere billing vs execution status.
- **F28** mismatch slice.billed_amount vs Invoice.subtotal quando emit usa line manuale. Investigare flow batch→invoice.
- **F30** CR voci fatturazione "non riportano niente di corretto" — generalizzazione F26/F27/F28. Investigare quali campi specifici del cost report sono sbagliati e fix.

### Importanti
- **F29** i18n incompleto: estendere `data-i18n` a TUTTI i template (41 pagine + modal + toast). ~500-1000 chiavi dictionary. Lavoro pesante, spalmare su più round per priorità d'uso.

### Già in backlog (rimandati)
- Parse batch capitolati 1-by-1 manuale
- OAuth Gmail/Outlook + Drive/OneDrive (richiede design provider)
- Automazione portali consegne

## Side-effect DB cumulativo sessione

(per cleanup futuro, non bloccanti):
- Invoice 111: status overdue (era sent, transition legit α.114 test immutability)
- Supplier invoice 131+132: soft-deleted (test smoke α.119)
- Anomaly entries 235+236: status=dismissed handled_action=auto_resolved (test α.119)
- NumberingConfig overhead_cost: configurato esplicito `OH-{YYYY}-{NNNN}` (= default, no-op)
- Supplier #11 "Francesca Ferrari": creato + linkato Resource 26 (test α.127 generate-supplier)
- Tenant 1 fs_scan_allowed_paths: ripristinato a NULL dopo test α.129

## Comando rapido per riaprire α.135

```bash
cd "C:/Users/frico/OneDrive/Documents/Claude/Projects/mediaflow_fase1bis"
git pull && git log --oneline -3
.venv/Scripts/python.exe -m uvicorn app.main:app --port 8000 --log-level warning &
# In Claude: "leggi project_session_16mag2026_maratona + project_alpha134_findings,
#  priorità F30 (CR voci fatturazione errate) + decisione design F26/F27/F28"
```

## Roadmap raccomandata α.135

1. **F30 investigazione** (prerequisito): pick 2-3 progetti, confronto campi CR vs Invoice/Slice, identificare colonne sbagliate.
2. **F26/F27 decisione design**: Matteo sceglie pattern (A strict / B visibilità / C reconcile). Implementazione conseguente.
3. **F29 i18n sweep**: priorità pagine alto uso (dashboard, clients, projects, quotes, planning, cost-report, finance).
