---
name: Sessione 28 aprile 2026 — riassunto + ripresa
description: Stato a fine sessione 28/04, cosa fare nella prossima
type: project
originSessionId: 2b4b36bf-a717-4764-bc5b-89f52b45072e
---
Sessione lunga: chiuse 7 versioni (v3.4.5 → v3.4.11) + 2 hotfix.

**Cantiere "Calendario e Pianificazione"** (v3.4.5–v3.4.7, v3.4.10): modal "Aggiungi voce" ridisegnato, Booking multi-tenant, sezione HR `/hr` con TimePunch separato (Opzione 2), booking legati a lavorazione + booking interni.

**Cantiere "Quote → Job → Cost Report"** (v3.4.8–v3.4.10): re-design fondamentale del flusso operativo dopo chiarimento di Matteo. Job non si crea più a mano: nasce automaticamente da quote approvata. Lavorazioni first-class su `/jobs/{id}`. `is_extra` flag + extra calcolato per riga. Step rimanenti: ferie bloccanti (v3.4.13), cost report interno arricchito (v3.4.14), cost report esterno cliente (v3.4.15).

**Cantiere "Visualizzazioni Pianificazione"** (in corso): hub `/planning/` con 5 viste tab + 9 filtri trasversali (v3.4.11 chiusa). v3.4.12 = parte 2 del top 6 split: Resource Timeline (vis-timeline, righe verticali risorse raggruppate per reparto), Kanban per stato job, Gantt per job dentro `/jobs/{id}`. **vis-timeline@7.7.3 già caricato CDN nel template hub** — pronto da usare.

**Why:** Matteo voleva flessibilità nelle visualizzazioni e poter vedere fino al trimestre. Architettura C scelta (singola entry sidebar con switcher). 9 filtri tutti, viste totali 8 (5 v3.4.11 + 3 v3.4.12).

**How to apply:**
- All'inizio prossima sessione: leggere `docs/STATO.md` (è la fonte primaria) — è già aggiornato.
- Verifiche sul Mac sono **9 cumulative** sospese — Matteo le farà in batch quando apre il Mac.
- Working tree pulita, ultimo commit: `60b2e09 v3.4.11`.
- Prossimo step concordato: **v3.4.12 — Resource Timeline + Kanban + Gantt**.
- Le 9 verifiche sospese sul Mac sono elencate in `docs/STATO.md` sezione "Verifiche sul Mac sospese".
