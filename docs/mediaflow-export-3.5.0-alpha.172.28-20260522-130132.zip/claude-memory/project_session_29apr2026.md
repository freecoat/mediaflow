---
name: Sessione 29 aprile 2026 — chiusura serale
description: Stato a fine sessione 29/04, cosa c'è da testare e da riaprire alla prossima sessione
type: project
originSessionId: 4b126f6c-507b-4b34-bd8f-deba2c329ef3
---
Sessione lunghissima di **20+ commit consecutivi**. Repo GitHub privato `freecoat/mediaflow` creato in apertura sessione (push solo a major bump — regola di Matteo). Nessun push fatto: 21 commit locali ahead.

## Versione corrente
**v3.4.20.4** — 29 aprile 2026.

## Cantiere principale chiuso: piano "Core Planning" E1→E6
Plan rivisto dopo analisi top vendor (Float/Runn/Productive/Mosaic/Ftrack). Tutte 6 fasi chiuse:

- **E1 v3.4.14** — Editing diretto: drag/resize/delete con `PUT /booking-assignments/{id}`, snap adattivo 15/30/60min, conflict viz live, undo toast 5s, Alt+drag duplica, doubleClick vuoto = nuovo
- **E2 v3.4.15→16.1** — Click&drag create, capacity heatmap %/giorno, menu contestuale Sposta/Duplica/Annulla cross-resource, **multi-resource** (cambio architetturale: BookingAssignment table, Booking.resource_id rimosso), modal multi-row con righe dinamiche, edit mode precarica
- **E3 v3.4.17** — `WorkingHoursPolicy` globale+override per-risorsa, ferie/malattia bloccanti, festività italiane auto via lib `holidays`, smart split server-side, hard block drag su ferie
- **E4 v3.4.18** — Multi-select Ctrl+click, bulk paste Ctrl+C/V, undo Ctrl+Z, nudge frecce ±15min, bulk delete, Esc cancel
- **E5 v3.4.19** — Booking ricorrenti (DAILY/WEEKDAYS/MON/CSV+CSV until-date), tentative visivo (bordo tratteggiato), audit log `BookingChange`
- **E6 v3.4.20** — AI capability `propose_booking` + endpoint `/api/suggest-resources`

Subito dopo, 4 commit di rifinitura UX:
- v3.4.20.1 autocomplete filtri sidebar (Cliente/Progetto/Job/Risorsa con FA_CONFIG riusabile)
- v3.4.20.2 modal multi-row scroll+numerazione+counter, right-click status tentative↔confirmed
- v3.4.20.3 UI settings tab "Orari lavorativi" (form policy editabile)
- v3.4.20.4 form ferie/malattia + dropdown override policy nel modal `/resources`

## Migrazioni DB nuove (devono girare sul Mac di Matteo)
1. `[F]` strumenti — `migrate_multi_resource.py` (rimuove Booking.resource_id, popola booking_assignments)
2. `[G]` strumenti — `migrate_working_hours.py` (crea WorkingHoursPolicy default Italia + Resource.working_hours_policy_id + ResourceUnavailability.kind)
3. `pip install -r requirements.txt --upgrade` (per `holidays>=0.60`)

`booking_changes` non ha migration esplicita (Base.metadata la crea al boot).

## Backlog aperto (al prossimo giro)
- Cost report doppio (interno con rate×ore+hardcost+booking interni vs esterno cliente solo ore+extra). Era v3.4.14/15 nel plan precedente.
- Overlay "prenotato vs effettivo" (Booking vs TimePunch) + funzione "adeguamento" (era nel feedback iniziale di Matteo).
- v3.4.20.5 Snap line visiva durante drag (skipped: basso ROI vs sforzo).
- AI capability `propose_unavailability`, context AI arricchito timeline.
- Major bump v4.0.0 = push GitHub triggerato (decidere quando).

## Da riaprire alla prossima sessione (parole chiave da darmi)
**"Riprendi da v3.4.20.4 — feedback test core-planning"**.

Matteo ha chiuso con: "Bene. Chiudiamo qui per stasera. Fai pulizia, salva tutto e riapri con il tuo ultimo commento alla prossima sessione."

Il mio ultimo commento conteneva:
1. Riepilogo 4 versioni patch v3.4.20.1-4
2. 6 punti da testare end-to-end (autocomplete sidebar, modal scroll, right-click status, settings working hours, form ferie/policy, timeline ferie striate)
3. Backlog rimanente (snap line skip, cost report doppio, overlay prenotato vs effettivo, AI propose_unavailability)
4. Soglia "v4.0.0 + push GitHub" quando Matteo conferma test OK

## How to apply
Quando rientri in sessione e Matteo chiede di riaprire:
- Saluto + leggi `docs/STATO.md` (versione corrente v3.4.20.4)
- Riapri esattamente con i 4 punti del riepilogo + i 6 test + il backlog
- Domanda esplicita: "test andato? Si va a v4.0.0 + push, o rimaniamo a 3.4.x e attacco un altro cantiere?"
