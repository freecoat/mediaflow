---
name: Sessione 30 aprile 2026
description: Stato fine sessione 30/04, riapertura con ultimo commento prima del riavvio terminal
type: project
originSessionId: a2b34b7a-371a-4852-a07c-3e22c12b62ca
---
Sessione 30/04 maratona — chiusi 12 commit (v3.4.21 → v3.4.27). Push eseguito a fine sessione su richiesta esplicita di Matteo.

## Versione corrente
**v3.4.27** — 30 aprile 2026 notte tarda.

## Commit della sessione (cronologia)
- `9c2e671` v3.4.21 — Soglie + moltiplicatori straordinari (overtime engine)
- `feb74da` v3.4.21.1 — Auth guard middleware + UX login + topbar utente
- `7c509a2` v3.4.22 — RBAC base (producer) + workflow ferie + timbratura semplificata
- `e94c5b8` v3.4.23 — Permessi configurabili + pannello /admin/users + /admin/roles + auto-User Resource
- `44c261e` docs: chiusura STATO
- `c3a9b30` v3.4.24 — Fix escapeHtml globale + ferie/malattia in Le mie ore + cleanup overtime + anteprima permessi modal
- `f7d4233` v3.4.24.1 — hotfix cache-buster global.js
- `9fba7eb` v3.4.25 — Permessi extra per-utente (additivi sopra il ruolo)
- `4795804` v3.4.25.1 — hotfix auto-bootstrap users.extra_permissions
- `09aa1ce` v3.4.26 — Sposta richiesta ferie da planning a /hr (Le mie ore)
- `5bf73cb` v3.4.27 — Sistema notifiche generico + UI approvazione ferie

## Lezioni della sessione (memoria persistente aggiunta)
- `feedback_global_helpers_centralizzati.md` — escapeHtml & co. sempre in global.js, mai locale (3 bug-sintomo da una sola causa)
- `feedback_cache_buster_static.md` — modificare static/js/*.js → bumpa SEMPRE ?v= in base.html
- `feedback_auto_migrate_columns.md` — aggiungere colonna a modello → check anche in _auto_migrate_columns() main.py lifespan
- `feedback_approccio_generico.md` — Matteo vuole architetture riusabili, in-depth, proposte ampie. NON tappare buchi singoli. Direttiva chiave per tutto il futuro.

## Da riaprire alla prossima sessione
**Parola chiave**: "Riprendi da v3.4.27 — apri con il tuo ultimo commento".

## Il mio ultimo commento (riepilogo testuale)
**v3.4.27 chiuso e pushato.** 33 commit ahead pushati su origin/main.

### Cosa è entrato nella sessione

1. **v3.4.21**: overtime engine deterministico (no AI) con soglie/moltiplicatori in `WorkingHoursPolicy`
2. **v3.4.22**: RBAC base + workflow approvazione ferie/malattia (backend)
3. **v3.4.23**: sistema permessi configurabili (modello Role + 23 permessi + 6 preset + pannelli /admin/users e /admin/roles + auto-User da Resource)
4. **v3.4.24**: bug fix `escapeHtml` globale (sbloccava /admin/users e /admin/roles), rimozione manuale "Straordinario" dal modal timbratura, ferie/malattia in "Le mie ore" + nel conteggio rendicontazione, anteprima permessi modal
5. **v3.4.24.1**: hotfix cache-buster global.js (lezione: bumpare sempre ?v=)
6. **v3.4.25**: permessi extra per-utente (additivi sopra il ruolo)
7. **v3.4.25.1**: hotfix auto-bootstrap colonna users.extra_permissions
8. **v3.4.26**: sposto card ferie da /planning/ tab "Le mie" → /hr/ pagina "Le mie ore" (giusto secondo nomenclatura sidebar)
9. **v3.4.27** (cantiere finale generico): sistema notifiche completo
   - Modello `Notification` con tenant_id/user_id/kind/severity/title/body/link/payload/is_read
   - Servizio `notifications.py` con notify/notify_permission/notify_role/mark_read/unread_count/cleanup_old
   - Endpoint REST `/notifications/api/*`
   - 3 hook nei workflow ferie (create pending → manager, approve/reject → richiedente)
   - UI: campanella topbar con badge (giallo se action_required), drawer laterale, polling 30s
   - Card "Richieste in attesa" in /hr/ con bottoni Approva/Rifiuta
   - 4 NotificationKind riservati per cantieri futuri (booking_conflict, quote_status_changed, job_deadline_approaching, custom)

### Da fare sul Mac
1. Pull (33 commit nuovi)
2. Riavvia server: `_auto_migrate_columns()` aggiunge `users.extra_permissions` se manca; `Base.metadata.create_all()` crea tabella `notifications`
3. Hard-refresh browser
4. Test:
   - Login admin → vedi 🔔 campanella topbar
   - Reset password Luca da `/admin/users`, logout, login Luca
   - Da `/hr/` (per Luca, "Le mie ore") fai richiesta ferie
   - Logout, login admin → badge giallo su campanella; in `/hr/` vedi card "Richieste in attesa"
   - Approva → notifica torna a Luca al prossimo polling 30s
   - In `/admin/users` apri Luca in edit → vedi sezione "Permessi extra" → spunta `view_finance` → Luca al prossimo login dovrebbe vederlo

### Backlog (in ordine di valore)
- **booking_conflict** notify (immediato — la timeline rileva già conflitti, basta cablarci `notify_permission("edit_planning_all")`)
- **Cost report doppio** v3.4.28+ (sospeso, fondamenta v3.4.21 pronte). Cost report **interno** rate × ore + hardcost + booking interni; cost report **esterno cliente** solo ore + extra + bottone "Genera quote v2"
- **Scheda tecnica progetti + link pubblico cliente** (cantiere G) — Matteo allegherà PDF (quello del 30/04 era erroneamente quote_Q-LFSB-1.pdf)
- **job_deadline_approaching**: cron via /schedule, notify PM
- **quote_status_changed**: hook in quotes router
- Affinamento granulare 23 permessi se Matteo lo chiede (in `app/services/rbac.py:PERMISSIONS`)
- Eventuale "messaggi tra utenti" (ora gli endpoint esistono lato modello, basta UI)

## How to apply
Quando Matteo torna in sessione e dice "Riapri con ultimo commento":
- Saluto + leggi `docs/STATO.md` (versione v3.4.27)
- Riapri esattamente con il riepilogo qui sopra (cosa è entrato, da fare sul Mac, backlog)
- Domanda esplicita: "Test sul Mac fatti? Tutto OK? Procediamo con booking_conflict notify (immediato + estende il pattern v3.4.27) o cost report doppio (cantiere grosso) o scheda tecnica progetti?"
