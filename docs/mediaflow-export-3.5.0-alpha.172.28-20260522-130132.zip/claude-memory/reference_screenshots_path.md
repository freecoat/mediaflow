---
name: reference-screenshots-path
description: "Path standard dove Matteo salva gli screenshot per condividere bug visivi (errori formattazione UI, regression visivi, layout problems)."
metadata: 
  node_type: memory
  type: reference
  originSessionId: bfbe3a2b-5cad-4cca-9cf6-ba0233c6c163
---

# Screenshots path

**Sempre qui**: `C:\Users\frico\OneDrive\Documents\Claude\Projects\mediaflow_fase1bis\docs\Logs-temp\Screenshots`

Quando Matteo dice "ti ho copiato uno screenshot" o "screenshots" senza specificare path, vai a leggere da qui. Tipicamente ordinati per nome con timestamp o tema.

Uso:
- `ls C:\Users\frico\OneDrive\Documents\Claude\Projects\mediaflow_fase1bis\docs\Logs-temp\Screenshots`
- Read tool su file `.png` (multimodal vision di Claude lo legge come immagine)

Errori UI ricorrenti che Matteo screenshotta:
- Formattazione menu select a tendina
- Layout dashboard
- Cost report rendering colonne
- Anomalie display
