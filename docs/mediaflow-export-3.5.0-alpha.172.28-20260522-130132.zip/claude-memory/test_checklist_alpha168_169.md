---
name: test-checklist-alpha168-169
description: Lista test punto per punto α.168 + α.169 da eseguire alla prossima sessione. 15 step T1-T15 + 5 regressioni R1-R5.
metadata: 
  node_type: memory
  type: project
  originSessionId: b84d08fd-79e6-406b-aee6-fedbf85ceef4
---

Test checklist sessione 18 mag 2026 — chiusa α.169 commit `7f30015`.

Lista completa in `docs/test_checklist_alpha168_169.md` (15 step + 5 regressioni).

Aree coperte:
- α.169 UI: T1 timeline sticky axis, T2 CR refresh button, T3 anomalie filtri cliente+progetto
- α.169 detector: T4 sforamento €-over, T5 extra puro fatturato, T6 auto-trigger post emit
- α.168 vasi comunicanti: T7 preview saturate escluse, T8 default billable_now, T9 billed/paid trasmissibile
- α.168 auto-numero: T10 4 modal, T11 tenant-scoped+anno-rotation
- α.169 invoice qty: T12-T14 quantity=total/unit_price, T15 slice sync

Regressioni: R1 PDF cliente, R2 cashflow, R3 SDI XML, R4 reverse-flow Quote→Job, R5 storno NC TD04.

**Why:** Matteo chiude sessione 18 mag sera, riprende stasera/domani con test estensivo. Vuole lista punto per punto da spuntare senza dover ricostruire mentalmente i cambi α.168+α.169.

**How to apply:** Alla riapertura, leggere prima `docs/test_checklist_alpha168_169.md` + segnalare a Matteo "ti aspetto i risultati". Se Matteo riporta failure su un punto, root-cause + fix mirato. Niente nuove feature finché checklist non chiusa (o esplicitamente skippata).

Stima: 60-90 min sequenziale, 30 min "happy path" minimo. Serve progetto con AdvancePayment pagato per T7-T9 (creare se manca).
