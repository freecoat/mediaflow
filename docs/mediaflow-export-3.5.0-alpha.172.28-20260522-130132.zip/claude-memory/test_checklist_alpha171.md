---
name: test-checklist-alpha171
description: "Checklist completa test α.171.x da eseguire alla prossima sessione. Coperti Sprint 1 (CR data integrity), Sprint 2 (Phantom redesign Steps 1-8 incluso UI), Sprint 3 (filtri planning + scroll timeline TL-2/TL-6)."
metadata: 
  node_type: memory
  type: project
  originSessionId: 76dd9ecc-d850-456e-ad46-d0f8304818f4
---

Test backlog 19 mag 2026 — eseguire alla riapertura. Backlog post tutti gli sprint α.171.x (CR + Phantom + Filtri).

## Setup pre-test (Mac di Matteo)

```bash
git pull
python scripts/migrate_phantom_redesign.py
python scripts/recompute_all_jcl.py
# Restart server
```

Verifica: server boot v3.5.0-alpha.171.9 (o successiva).

## Sprint 1 — CR data integrity (α.171)

**T1 CR-1 stima fantasma 0**:
1. Apri CR Job `2026-0008 Voice of Silence Vol. 2`
2. Voci TIME-based senza booking (Transfer Elettronico, Re-recording Dolby Atmos, Proxy ProRes 422 HQ, Auto-QC Baton/Vidcheck): **stima = 0 €** (non più = quotato)
3. Over/Under colonna: mostra `−€{quoted}` (UNDER chiaro)

**T2 CR-1 voce binaria (lump/forfait)**:
1. Trova JCL con `unit` non time-based (lump/pc/shot/version/allow/TB/GB/fix/lot)
2. Anche con 0 booking, mostra `actual = expected = quoted` (modello binario)
3. Over/Under = 0 sempre

**T3 CR-2 ore double-count sala+risorsa**:
1. Crea booking con Sala A (8h) + Carlo Carosa (8h) su JCL Production (hr-based)
2. Marca booking done
3. CR: `quantity_actual = 8h` (non 16h)
4. `total_cost_accrued` = (Carlo rate) × 8h + (Sala rate) × 8h — cost-side somma entrambi

**T4 CR-2 multi-umana + sala**:
1. Booking Carlo 4h + Mario 6h + Sala 8h
2. CR: `quantity_actual = 6h` (max umana, sala ignorata)

**T5 CR-2 solo sale (no umana)**:
1. Booking Sala A 8h + Sala B 4h (nessuna persona)
2. CR: `quantity_actual = 8h` (max non-umana)

## Sprint 2 — Phantom redesign (α.171.1 → .8 + Step 8 AI + Step 5 UI + Step 6 propagation)

**T6 Migration applicata**:
1. SQL diretto: `PRAGMA table_info(quotes)` → ha colonne `phantom_status`, `merged_into_quote_id`
2. SQL: `SELECT name FROM sqlite_master WHERE type='index'` → presenti `uq_phantom_standby_per_project`, `ix_quotes_phantom_status`

**T7 Creazione Consuntivo da booking reverse-flow**:
1. Trova progetto SENZA quote attiva (status quote = draft/rejected/expired)
2. Da timeline planning crea booking su una risorsa, lavorazione = voce listino
3. Apri modal "+ Genera Quotazione a Consuntivo" → conferma
4. **Aspettati**: nuova quote con `is_phantom=True`, `phantom_status=standby`, title "Consuntivo — {progetto}"
5. Voce nella Consuntivo: `quantity_quoted = 0` (non = ore booking)
6. Job creato. JCL collegata. Cost report del Job mostra: ore booking via `quantity_actual`

**T8 Pre-check Consuntivo bloccata se quote attiva**:
1. Progetto con quote `sent` o `approved` non-phantom
2. Tenta creare Consuntivo → 409 "Impossibile creare: progetto ha già quote NNN (sent|approved)"

**T9 Auto-attach 2° booking → voce esistente Consuntivo**:
1. Progetto con Consuntivo standby già esistente
2. Crea secondo booking via reverse-flow
3. **Aspettati**: NUOVA voce aggiunta alla Consuntivo esistente (NON nuova phantom). Notifica info "Voce aggiunta a Consuntivo NNN".
4. UI Consuntivo mostra 2 voci, entrambe con `quantity_quoted = 0`

**T10 1-per-progetto enforced (DB index)**:
1. SQL tentativo manuale: `INSERT INTO quotes ... is_phantom=1 phantom_status='standby' project_id=X` per progetto X che già ha standby
2. **Aspettati**: errore UNIQUE constraint `uq_phantom_standby_per_project`

**T11 Badge CR Consuntivo**:
1. Apri CR di Job legato a Consuntivo
2. Titolo CR mostra: `[CODE] · [TITLE] — [CLIENTE]` + `📌 CONSUNTIVO · standby` (indigo)
3. Se Consuntivo `promoted` → badge `✅ CONSUNTIVO · promosso` (verde)
4. Se `merged_into` → badge `🔗 CONSUNTIVO · accorpato` (grigio)

**T12 Endpoint promote**:
1. `POST /quotes/api/{phantom_id}/promote-phantom`
2. Response 200: `{is_phantom: false, phantom_status: 'promoted', promoted: true}`
3. UI quote: badge sparisce, quote appare in lista normale `/quotes`
4. Re-tentativo promote → 400 "non standby"

**T13 Endpoint merge**:
1. Progetto con Consuntivo standby + quote target non-phantom (anche approvata)
2. `POST /quotes/api/{phantom_id}/merge-into/{target_id}`
3. Response 200: `{new_version_number: "Q-XXX-v2", lines_from_target: N, lines_from_phantom: M}`
4. Verifica: target ora `status=superseded`, Consuntivo `phantom_status=merged_into, merged_into_quote_id=new_version.id`
5. Nuova versione: N+M righe, target lines hanno `parent_line_id`, phantom lines hanno `detail` con `[da Consuntivo NNN]`

**T14 Step 5 UI doppia conferma modifica quote approved**:
1. Apri quote `approved` in `/quotes#{id}`
2. Modifica un field meta (es. notes, payment_terms, vat_rate, shipping_markup_pct, billing_frequency)
3. **Aspettati**: prima confirm "Quote APPROVATA — Modifica metadata quote. Le modifiche su una quote approvata richiedono una NUOVA VERSIONE..."
4. Click OK → seconda confirm "Confermi creazione nuova versione vN+1?"
5. Click OK → toast "Nuova versione Q-XXX-v2 (v2) creata"
6. UI switcha automaticamente sulla nuova versione, modifica applicata
7. Click Cancel su una delle due confirm → operazione abortita, quote originale invariata

**T15 Step 6 delete voce quote approved → propagazione CR**:
1. Quote approved con linea X legata a JCL con `quantity_actual > 0` (booking attivi/done)
2. DELETE `/quotes/api/{quote_id}/lines/{line_id}`
3. **Aspettati**: 200 con `{propagated_to_phantom: true, phantom_quote_id, cost_lines_moved}`
4. Verifica:
   - Voce X eliminata dalla quote originale
   - Consuntivo standby creata o riusata
   - JCL ora ha `quote_line_id` puntante alla nuova line nella Consuntivo
   - Booking restano funzionanti (no orfani)
5. CR del Job mostra ancora la voce, ora sotto Consuntivo (badge presente)

**T16 Delete voce quote NON approved → hard-block (regressione)**:
1. Quote `draft` o `sent` con linea con booking attivi
2. DELETE line → 409 con messaggio "booking ostativi"
3. **Aspettati**: nessuna propagazione su Consuntivo (behavior pre-α.171.8 invariato)

**T17 Step 8 AI capability promote**:
1. Apri AI copilot, chat: "Promuovi la Quotazione a Consuntivo Q-2026-XXX a quote effettiva"
2. AI risponde con tool call `propose_promote_phantom(quote_id=N)`
3. Card di conferma in UI con bottoni Applica/Rifiuta
4. Click Applica → executa → Consuntivo promossa

**T18 Step 8 AI capability merge**:
1. AI chat: "Accorpa la Consuntivo Q-2026-X nella quote Q-2026-Y"
2. Tool call `propose_merge_phantom(source_quote_id, target_quote_id)`
3. Apply → nuova versione creata

**T19 Step 8 AI system prompt — blocco proposta nuova phantom**:
1. Progetto con Consuntivo standby già esistente
2. AI chat: "Aggiungi una voce Color grading al progetto X via Consuntivo"
3. **Aspettati**: AI NON propone `propose_new_item_and_line` (creerebbe nuovo phantom). Invece propone `propose_quote_line` su Consuntivo esistente con `quantity=0`.

## Sprint 3 — Filtri planning (α.171.7 + α.171.9 timeline)

**T20 TL-1 Filtro reparto chip-multi**:
1. Sidebar planning → campo Reparto
2. **Aspettati**: input testuale con autocomplete (no più `<select multiple>`)
3. Cerca "DI" → suggestions popup con badge colore reparto
4. Click 2 reparti → 2 chip visibili con `✕` per rimuovere
5. Timeline filtra solo risorse appartenenti ai reparti selezionati

**T21 TL-3+TL-5 Filtro ricerca testuale**:
1. Sidebar → input "Cerca"
2. Digita "dolby" → timeline mostra solo booking con notes/JCL description/PriceItem name contenente "dolby"
3. Digita "carlo" → match Resource.name
4. Digita "QC" → match Job.code/title o JCL description

**T22 TL-4 Filtri vista "Per progetto"**:
1. Tab "Per progetto" → seleziona un progetto
2. Sidebar: filtra dept "DI/Video" + risorsa specifica + status "confirmed"
3. **Aspettati**: vista mostra solo i booking di quel progetto che matchano TUTTI i filtri
4. Pre-α.171.9 mostrava tutti i booking del progetto ignorando filtri tranne resource_id

**T23 TL-2+TL-6 Timeline scroll risorse + axis sticky**:
1. Apri planning con N risorse > viewport (es. 20 risorse)
2. **Aspettati**: timeline cresce per coprire TUTTE le risorse (no scroll interno widget)
3. Scrollando la PAGINA: l'axis data/ora resta sticky in alto (visibile durante page-scroll)
4. Label colonna sinistra risorse scorrono con la pagina (vedi ogni risorsa accanto a suoi items)
5. Toolbar pagina sopra resta accessibile

**T24 TL-2 con filtro reparto attivo + tante risorse**:
1. Filtra reparto con tante risorse (es. DI/Video se 30+)
2. Scrolla la pagina verticalmente
3. **Aspettati**: vedi tutte le risorse del reparto. Pre-α.171.9 limit α.84 + maxHeight nascondevano le ultime risorse.

## Regressioni da verificare

**R1 Vasi comunicanti billing α.168**:
1. Job con JCL UNDER → batch transmit normale (T1.1 base già passato 19 mag)
2. Job con JCL paid + extra qty arrivato → trasmissione supplemento, status JCL non cambia (T1.2)
3. Job con APA (acconto preallocato) → `already_filled = slice + APA × paid_ratio` (T1.3)

**R2 Anomalie filtri α.170**:
1. Apri tab `/finance#anomalies`
2. Filtri cliente/progetto → lista E chip cambiano
3. Auto-detect alla prima apertura tab (toast "Detect completato")

**R3 Cashflow filtri α.170**:
1. `/cashflow` → seleziona cliente
2. "Split per reparto (anno)" si aggiorna con i filtri
3. Click stesso anno corrente → "🔄 Aggiorna" forza reload (oppure focus/blur)

**R4 Timeline `groupHeightMode: 'auto'` α.170**:
1. 1 risorsa con 2 booking overlap → riga 74px
2. Zoom-out → 1 booking visibile → riga torna a 39px (NON resta a 74px)

**R5 Click singolo label risorsa α.170**:
1. Click su nome risorsa nella colonna sinistra timeline
2. Popover mostra: tipo (interno/freelance/studio/...), cost type, email, telefono, interno

**R6 Quote/Job CRUD baseline**:
1. Crea quote draft → add lines → set approved → genera Job
2. Verifica JCL create, Job code generato
3. Edit voce quote draft → modifica salvata diretto (no doppia conferma)

**R7 Reverse-quote attach approval implicit**:
1. Progetto con quote `sent` → booking via reverse-flow → seleziona "Attach esistente"
2. Quote passa a `approved` (implicit approval), Job creato, JCL collegata

## Sprint 2 — Step 5 extended (α.171.10)

**T25 Step 5 estensione a tutti i mutator linee**: ripeti T14 su:
1. saveLineField (modifica description / quantity / unit / unit_price su quote approved → doppia conferma)
2. saveLineDiscount (modifica % sconto riga)
3. addLine (aggiunta nuova riga)
4. toggleLineOptional (toggle voce opzionale)
5. saveLineSection (modifica section label)

Per ognuno: doppia confirm → toast `"Nuova versione creata. Ripeti la modifica sulla nuova versione (caricata ora)."` → DOM ricaricato sulla v+1 → ripeti l'edit manualmente. Se cancel: modifica abortita, quote originale invariata.

**T26 Step 5 deleteLine warning approved**:
1. Quote approved, line con booking attivi: click Elimina
2. Confirm specifico: "Voce su quote APPROVATA... Se ha booking attivi, JCL spostate alla Consuntivo del progetto. Continuare?"
3. OK → toast info `"Voce spostata a Quotazione a Consuntivo NNN (X JCL trasferite)"`

## Sprint 2 — Step 6 batch delete (α.171.10)

**T27 Batch delete multi-lines quote approved**:
1. Quote approved con 3 linee X, Y, Z (X+Y hanno booking attivi, Z non ha)
2. `POST /quotes/api/{quote_id}/lines-batch-delete` Form `line_ids=X,Y,Z`
3. Response: `{ok: true, deleted: 3, propagated_to_phantom: true, phantom_quote_id, cost_lines_moved: N, details: [...]}`
4. Verifica:
   - Consuntivo standby creata o riusata (UNA per tutto il batch, non 3 phantom)
   - JCL di X+Y spostate sulla Consuntivo
   - Z eliminata + JCL pulite cascadea
   - Quote originale: 3 linee eliminate

**T28 Batch delete quote non-approved + booking attivi → rollback**:
1. Quote draft con 2 linee X+Y, X ha booking attivi
2. `POST /quotes/api/{quote_id}/lines-batch-delete` Form `line_ids=X,Y`
3. Response 409 con messaggio "Line #X ha N booking attivi: impossibile eliminare in batch su quote non-approved"
4. Verifica: ENTRAMBE le linee X+Y NON eliminate (rollback)

## Sprint 3 — TL-3 dropdown lavorazione (α.171.10)

**T29 Filtro lavorazione standalone**:
1. Sidebar planning → campo "Lavorazione"
2. Click input → suggestions popup vuoto (no progetto selezionato)
3. Digita "color" → fetch async, mostra JCL contenenti "color" (description o PriceItem.name)
4. Click su una JCL → chip aggiunto, timeline filtra solo booking di quella JCL

**T30 Filtro lavorazione come subfiltro progetto**:
1. Seleziona prima 1 progetto in sidebar
2. Click campo Lavorazione → suggestions limitate alle JCL di quel progetto
3. Cerca testo → ulteriore filtraggio match
4. Add chip lavorazione → vedi solo booking di quella JCL all'interno del progetto

**T31 Lavorazione multi-select**:
1. Selezione 2-3 JCL come chip
2. Timeline mostra booking di TUTTE le JCL selezionate
3. Rimuovi chip ✕ → filtro aggiorna

**T32 Lavorazione persiste in URL**:
1. Filtra lavorazione X+Y
2. URL contiene `?jcl=X,Y`
3. Refresh pagina → chip ricaricati (placeholder "JCL #X" se cache async vuota)

## Backlog dopo test

- Eventuali bug emersi nei test T25-T32
- Sprint 2 testing AI capability T17/T18 dipende da provider configurato
