---
name: test-checklist-post-audit-alpha114-118
description: "Checklist completa test post-audit dopo 6 round alpha.113→118. Da eseguire prima di considerare il ciclo audit chiuso. Salvato 15 mag 2026 fine sessione, Matteo testerà 16 mag."
metadata: 
  node_type: memory
  type: project
  originSessionId: 350b73c9-561c-427c-b075-37e84c689813
---

# Test checklist post-audit alpha.113→118

**Snapshot DB** disponibile: docs/mediaflow-export-3.5.0-alpha.118-20260515-185917.zip

Test divisi per round. **Eseguire IN ORDINE** (alcuni test 117 dipendono da 114-115 funzionanti).

## ROUND α.113 (11 punti Q1-Q11) — base verifiche UI

- [ ] **Q1 Header temi chiari**: switcha tema su paper/sand/linen/sage. Icone topbar (sidebar toggle, palette, bell, logout) devono essere VISIBILI con contrasto pieno (`var(--text)`).
- [ ] **Q2 Vedi Progetti filtro**: apri /clients → scheda cliente → "Vedi progetti" → /projects deve aprirsi CON FILTRO cliente già attivo.
- [ ] **Q3 Email amministrazione fattura**: /clients edit → campo "Email amministrazione" → salva. Emit fattura per quel cliente → PDF stampato deve mostrare "Att.ne Amministrazione · <email>".
- [ ] **Q4 Naming builder drawer**: /settings → tab "Naming conventions" → click su regola → drawer drag&drop si apre A SINISTRA flush con sidebar (NON sopra sidebar).
- [ ] **Q5 CR list maturato stale**: muovi un booking done in /planning → torna a /cost-report. Lista deve mostrare valore corretto SUBITO (no più "vai in dettaglio per allineare").
- [ ] **Q6 Spese aziendali dettaglio**: /overhead → click su card categoria → drawer apre con elenco voci della categoria.
- [ ] **Q7 Fatture passive no project**: /overhead → cerca card "📄 Fatture passive (no progetto)" se hai fatture passive senza project_id. Click → drawer con elenco.
- [ ] **Q8 Lista fatturazione titolo progetto**: /finance → tab Fatture → colonna Progetto mostra `codice` (mono) + `titolo` (text-muted sotto).
- [ ] **Q9 Lista fornitori progetto**: /suppliers → tab Fatture passive → colonna "Progetto" presente con codice+titolo.
- [ ] **Q10 Job select fattura passiva**: /suppliers → nuova fattura → seleziona progetto → dropdown Job ora popolato con job del progetto.
- [ ] **Q11 Resource link in modal supplier**: /suppliers → modal fornitore → campo "Risorsa associata" + bottone "+ Crea risorsa" (disabled finché supplier salvato).

## ROUND α.114 (16 fix audit deep-dive) — invariants

- [ ] **A1 Card alignment quote**: /quotes → apri quote → cards "Riepilogo" e "Stato & azioni" allineate stessa altezza (no più disallineamento da `.card + .card`).
- [ ] **A2 PDF drift read-only**: simula drift (modifica InvoiceLine.total via API o DB). Download PDF → log warning ma Invoice.subtotal NON mutato in DB. Lista fatture mostra badge ⚠ drift con tooltip.
- [ ] **A3 Invoice immutability**: prova PUT /finance/api/invoices/{id}/lines su fattura sent → deve dare 409 con messaggio "Le fatture emesse sono immutabili".
- [ ] **A3 Transizioni stato**: prova `paid→draft` o `cancelled→sent` → 409. `draft→sent` OK. `sent→paid` OK.
- [ ] **A4 Cashflow include storno NC**: emit fattura €1000 gennaio. Storna via NC TD04 a marzo. Vai /finance#cashflow → gennaio +1000, marzo -1000, saldo annuale netto 0.
- [ ] **A5 Q5 root cause**: in /planning seleziona N booking DONE in bulk → shift temporale (drag o azione "shift days"). Torna a /cost-report lista. Maturato deve essere allineato SENZA reconcile-all manuale.
- [ ] **A6 Storno NC closing reset lost**: emit closing invoice progetto (alcune JCL con total_approved=0 marcate `lost`). Storna NC TD04 → progetto torna active. Verifica JCL `lost` con `billed_amount=0` siano tornate `not_billed`.
- [ ] **A7 Double-close race**: hard da testare manualmente. Almeno verifica che emit_closing chiamato 2× consecutivamente sullo stesso progetto dia 409 al secondo.
- [ ] **A8 OverheadCost code soft-delete**: crea spesa OH-2026-0001 → cestina → crea nuova spesa. Codice deve essere OH-2026-0002 (non collidere con cestinata).
- [ ] **A9 update_booking re-assign JCL**: in /planning booking done → cambia job_cost_line_id senza toccare assignments. Vecchia JCL deve perdere ore, nuova acquisisce. Verifica in /cost-report dettaglio entrambi.
- [ ] **A10 Resource delink supplier**: /suppliers modal fornitore → cambia "Risorsa associata" da A a B → salva. Verifica Resource A.supplier_id ora NULL, Resource B.supplier_id puntato.
- [ ] **A11 job_id senza project**: /suppliers nuova fattura → seleziona project+job → toglie project (lascia job select valued). Submit → invoice salvata SENZA job_id (no orphan).
- [ ] **A12 /projects?client_id sconosciuto**: apri /projects?client_id=999999 → toast warning "Cliente non trovato" + mostra tutti i progetti.
- [ ] **A13 + Crea risorsa deferred**: /suppliers nuovo fornitore (mai salvato) → bottone "+ Crea risorsa" deve essere DISABLED + tooltip. Salva → bottone si abilita.
- [ ] **A14 Drawer naming sidebar**: /settings → tab "Naming conventions" → click regola. Drawer da sinistra ma flush DOPO sidebar (left = var(--sidebar-w)).
- [ ] **A15 Tenant scope sweep**: prova POST SupplierInvoice con resource_id di tenant diverso (manuale via API direct) → 400.
- [ ] **A16 Zero-accrued JCL precheck closing**: progetto con alcune JCL quotate ma `total_accrued=0` (mai eseguite). Apri closing-precheck → banner ⚠ "X voci preventivate ma non eseguite" + confronto quotato.

## ROUND α.115 (Q11 cost-side + NumberingConfig core + reconcile dirty)

- [ ] **Q11 cost_external base**: /suppliers nuova fattura passiva con `resource_id` linkata a una risorsa che ha booking sul job. Salva. → /cost-report dettaglio quel job → stat card "Costo reale (fatture)" mostra €X (= total fattura).
- [ ] **Q11 Δ vs stima**: stesso scenario sopra. Verifica stat card mostra "Δ vs stima: +/-€Y" se cost_external ≠ cost_accrued.
- [ ] **Q11 update fattura**: aggiorna importo SupplierInvoice → cost_external auto-aggiornato in CR.
- [ ] **Q11 delete fattura** (α.118 fix): cestina SupplierInvoice → cost_external ridotto (no più sporco).
- [ ] **NumberingConfig core quote**: /settings#numbering → cambia format Quote a `Q-{YYYY}-{NNN}-prova` → salva. Crea nuova quote → numero contiene "-prova".
- [ ] **NumberingConfig core batch**: stesso pattern su BillingBatch → crea trasmissione CR → codice batch riflette config.
- [ ] **Reconcile dirty flag**: GET /cost-report/api/reconcile-status → stale_count visibile. Dopo modifica booking → stale_count > 0. Dopo reconcile-all → stale_count = 0.

## ROUND α.116 (NumberingConfig cabling 6 generator + UI vars validation)

- [ ] **11 doc_type in UI**: /settings#numbering → vedi 11 doc type (era 8): quote, billing_batch, invoice, invoice_closing, invoice_credit_note, job, cost_report_export, supplier_invoice, **overhead_cost, ingest_batch, ddt** (3 nuovi).
- [ ] **UI vars greyed**: apri builder per `overhead_cost` → variabili `{PROJECT_CODE}` e `{CLIENT_CODE}` DEVONO essere greyed-out (opacity 0.5, cursor:not-allowed, tooltip "non disponibile").
- [ ] **Backend validation 400**: tenta save `OH-{PROJECT_CODE}-{NNNN}` per overhead → backend rifiuta 400 con messaggio variabili valide.
- [ ] **Cabling job code**: /settings#numbering → cambia format Job a `J-{YYYY}-{NNN}` → crea job da quote → code riflette config.
- [ ] **Cabling overhead**: cambia format → crea nuova spesa → code riflette.
- [ ] **Cabling ingest_batch**: /assets ingest fisico → nuovo batch → code riflette config se settata.
- [ ] **Cabling DDT**: emit DDT → number riflette.
- [ ] **Fallback su collision**: con format problematico, sistema deve NON crashare ma usare fallback legacy.

## ROUND α.117 (anomaly cost_drift + UI background reconcile)

- [ ] **Anomaly chip "⚖ Drift costo"**: /finance#anomalies → nuovo chip filtro presente.
- [ ] **Anomaly trigger detection**: crea fattura passiva con resource_id linked > 15% stima (es. stima €2000, fattura €2500 = 25% drift). Click "🔄 Rileva" → anomaly emessa con descrizione "stimato €X vs reale €Y (Z% off)".
- [ ] **Anomaly summary card**: vedi "⚖ Drift costo (Q11)" in summary.
- [ ] **UI background reconcile indicator**: /cost-report apertura → IMMEDIATA. Top-right vedi badge "🔄 Sincronizzazione cost report (N righe)" con spinner se ci sono JCL stale.
- [ ] **UI background auto-refresh**: aspetta che stale_count=0 → indicator scompare + lista auto-refreshata.
- [ ] **Performance stress**: usa snapshot stress DB (1000 jobs, 80k JCL). /cost-report apertura deve essere <500ms (pre-117 era 15-30sec freeze).

## ROUND α.118 (audit M-findings)

- [ ] **Delete supplier invoice recompute**: cestina SupplierInvoice con resource_id → cost_external delle JCL coinvolte deve essere ricomputato (ridotto).
- [ ] **Preview placeholder esplicito**: /settings#numbering → builder per `invoice_closing` (usa {PROJECT_CODE}) → preview mostra `CL-«PROJ»-2026` + nota italic "I valori «PROJ»/«CLI» sono placeholder esempio…".
- [ ] **Quote pattern validation**: tenta save Quote format `Q-{PROJECT_CODE}` (no NNN finale) → backend 400 "DEVE terminare con blocco progressivo".

## Test trasversali integrazione

- [ ] **Auto-migrate boot**: avvia uvicorn su DB pre-114. Verifica log `[auto-migrate]` per: `clients.admin_email`, `invoices.client_admin_email_snap`, `invoices.is_closing/closing_project_id`, `projects.finance_status/finance_closed_at/finance_closing_invoice_id`, `supplier_invoices.resource_id`, `resources.supplier_id`, `job_cost_lines.total_cost_external/accrued_stale`. Tutte presenti dopo restart.
- [ ] **Tab Naming conventions** rename: /settings → tab si chiama "Naming conventions" (era "Numerazione").
- [ ] **Cashflow snapshot**: verifica saldo annuale con storno NC vs senza. Compara con calcolo manuale.
- [ ] **End-to-end flow completo**:
  1. Crea client + admin_email
  2. Crea quote (code custom config)
  3. Approva → Job (code da config)
  4. Booking done → JCL accrued
  5. Crea fattura passiva con resource_id linked
  6. /cost-report dettaglio → vedi cost_external + drift
  7. Trasmetti CR → BillingBatch (code da config)
  8. Approva batch → emit Invoice → PDF stampato include admin_email
  9. Storna via NC TD04 → cashflow ridotto + Project se closing → riaperto
  10. Cestina fattura passiva → cost_external ridotto

## Note critiche

- **Hot reload**: alcuni fix sono in CSS/JS — fare Ctrl+F5 (hard refresh) per evitare cache.
- **Stress DB**: import via /settings>Dati lo ZIP `mediaflow-export-3.5.0-alpha.118-...` per partire da stato pulito + auto-migrate.
- **AI guard rail**: AI tools non hanno propose_invoice_update. Verifica che nessun nuovo tool aggiunto futuro tocchi invoice post-draft.
- **Order**: testare nell'ordine α.113→118. Alcuni test 117 (background reconcile) richiedono che α.115 dirty flag funzioni.

## Roadmap dopo test

Se test rilevano bug:
- Bug bloccanti → fix immediato in α.119 + nuovo round audit
- Bug minori → documentare e accumulare per round successivo

Se tutti pass:
- Closing of audit cycle. Si passa a nuove feature (es. AI capabilities estese, Email integration, Knowledge Base capitolati F14/F15).
