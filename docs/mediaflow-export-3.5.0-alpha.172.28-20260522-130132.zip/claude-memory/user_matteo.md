---
name: Matteo Lepore — profilo utente
description: Manager italiano di casa di post-produzione audiovisiva, project owner MediaFlow, lavora su Mac con Python 3.14
type: user
originSessionId: b023d553-0ef8-4520-b045-492feb89994c
---
Matteo Lepore — manager esperto del settore post-produzione cinema/TV/pubblicità in Italia. Espertise di dominio profonda: capitolati, formati, flussi di lavoro, terminologia tecnica.

- Lingua: italiano. UI in italiano, codice in inglese.
- Sviluppo principale: Mac (Python 3.14, no permessi admin). Sviluppo parallelo: Windows 11 con Claude Code, hostname `fricot-blade` (anche nome Tailscale per accesso remoto).
- Stile: risposte dirette, conciso, no preamboli, no self-deprecation.
- Approccio: "AI propone, utente dispone" — anche tra Claude e lui. Vuole conferma esplicita prima di azioni non banali.
- Driver del prodotto: la sua expertise di dominio guida le decisioni di design.
