---
name: Roadmap billing α.65+
description: Punti 4/5/6 della valutazione propositiva 8 mag 2026 sera — overtime weighted, cashflow completo, supplier invoice. Decisioni semantiche da prendere PRIMA di codice.
type: project
originSessionId: 8562d19a-6b69-47cd-b411-574e1d20a8be
---
Da analisi propositiva 8 mag 2026 sera (sessione α.63→α.64). Bundle 1+2+3
implementato in α.64. **I 3 punti restanti hanno decisioni aperte da fare
con Matteo prima di scrivere codice.**

**Why**: Matteo ha chiesto "valutazione propositiva di come adattare al
meglio" il modello cashflow. Le decisioni semantiche (es. solo overtime
approvato vs anche pending) cambiano completamente la lettura dei numeri
in cost-report, e una scelta sbagliata = dover rifare. Memoria
`feedback_approccio_generico` impone "domande esplicite, niente buchi
singoli".

**How to apply**: Prima di partire con α.65 (engine billable_hours),
RIAPRIRE la conversazione con Matteo su questi 3 trade-off.

---

## Punto 4 — Overtime con coefficiente (cashflow accurato)

**Stato modello**: TUTTO PRONTO lato Tenant (`models.py:686-708`):
- `daily_hours_threshold` (default 8h)
- `weekly_hours_threshold` (40h)
- `overtime_multiplier`, `night_multiplier`, `sunday_multiplier`,
  `holiday_multiplier`
- `overtime_brackets` JSON per CCNL (es. Cinema Doppiaggio: 0-2h base,
  2-4h +30%, 4+ +60%)
- `BookingOvertimeStatus` enum (none/pending/approved/rejected) già esistente

**Cosa manca**: `app/services/cost_line_sync.py:_booking_hours()` somma ore
lineari, ZERO moltiplicatori. Una giornata 8-22 vale 14h pure.

**Proposta engine** (file nuovo `app/services/billable_hours.py`):
```python
def billable_hours_for_assignment(a, tenant) -> dict:
    # ritorna {regular_h, overtime_h, night_h, holiday_h, sunday_h,
    #          weighted_total_h, multiplier_avg}
```

**3 DECISIONI APERTE con Matteo (necessarie prima di α.65)**:

1. **Solo overtime APPROVED conta col moltiplicatore?** Oppure anche PENDING?
   - Se solo approved: cost report stabile ma "in attesa di approvazione"
     non si vede nei numeri finché manager non firma
   - Se anche pending: cost report mostra il "peggior caso" subito ma può
     rivelarsi sbagliato post-rifiuto
   - Mia raccomandazione: solo approved. Pending lo metto in tooltip "+€X
     pending approvazione" senza alterare i numeri.

2. **Conversione day-unit**: una giornata 8-22h con 6h overtime × 1.30 =
   13.8h pesate. Come la traduce JCL.unit="day"? Oggi `_qty_from_hours(unit,
   hours, n)` per "day" fa `hours / 8`. Opzioni:
   - A) Conversione lineare: 13.8/8 = 1.725 giornate (aumenta il maturato
     della % overtime). Coerente con il "costo aumentato" dell'OT.
   - B) Resta 1 giornata "fisica" + esponi un campo separato `weighted_hours`
     in JCL (cambia il modello).
   - Mia raccomandazione: A (lineare), zero migrazione. Il segno è chiaro
     ("una giornata con 6h OT vale 1.725 giornate-equivalenti").

3. **Booking interni** (`kind != project`, no JCL associata): fuori dal
   conteggio? Sono manutenzione/R&D/training, non hanno cost-line.
   - Mia raccomandazione: SÌ, esclusi (non c'è dove sommarli).
   - Eventualmente esposti separatamente in un report HR-side futuro.

**Costo implementativo**: ~150 righe nuovo file billable_hours.py +
modifica `_booking_hours()` per opzionale tenant param + integrazione in
`recompute_cost_line_actual`. Test approfonditi, niente migrazione DB.

---

## Punto 5 — Cashflow completo

**Cosa abbiamo già**:
| Cosa | Modello | Stato |
|---|---|---|
| Quotato (revenue plan) | JobCostLine.total_quoted | ✅ |
| Maturato (revenue earned) | JobCostLine.total_accrued | ✅ |
| Forecast revenue | JobCostLine.total_expected | ✅ |
| Fatturato | JCLBilledSlice.billed_amount | ✅ α.58 |
| Incassato | — | ❌ |
| Costo diretto ore | — | ❌ |
| Costo indiretto/spese | — | ❌ |
| Fatture passive (esterne) | — | ❌ (punto 6) |

**5.a — Costo risorsa cost-side** (più invasivo):
- Aggiungi a Resource: `hourly_cost`, `daily_cost`
- Aggiungi a JobCostLine: `total_cost_accrued` (somma per assignment)
- Margine reale per riga = `total_accrued − total_cost_accrued`
- Migrazione DB. Cambia la lettura del cost-report.

**5.b — InvoicePayment** (isolato, sblocca cashflow revenue-side):
- Modello nuovo `InvoicePayment` (invoice_id, amount, payment_date, method)
- `Invoice.amount_paid` denormalizzato + `payment_status` enum
  (unpaid/partial/paid)
- Endpoint `POST /finance/api/invoices/{id}/payments`
- Sblocca: DSO per cliente, atteso-incasso

**5.c — Cashflow timeline** (`/finance/cashflow`):
- Vista calendario settimana/mese
- Righe: Fatturato emesso, Atteso da emettere (accrued_post_period),
  Incassato, Atteso incasso (unpaid + due_date), Costi diretti pagati,
  Costi diretti maturati, Cassa netta
- Per progetto + aggregato tenant
- Implementabile in step (1: revenue-only / 2: cost-side / 3: esterni)

**Mia raccomandazione**: in α.66 fare 5.b + 5.c base (revenue-only).
È fattibile senza 5.a e dà subito valore. Lasciare 5.a per dopo perché
richiede `Resource.hourly_cost` con valori reali (Matteo deve riempire
i tariffari interni — opera lunga).

---

## Punto 6 — Commesse esterne / supplier invoice (modulo nuovo)

**Modello** (2 tabelle nuove):
```
Supplier: id, name, vat_number, contact_email, default_payment_terms
SupplierInvoice: id, tenant_id, project_id (opt), supplier_id, number,
  issue_date, due_date, amount_net, amount_vat, amount_total, currency,
  payment_status, notes, attachment_path, job_cost_line_id (opt FK)
```

**Flow**: producer carica PDF → (futuro: AI parser) → assegna a
project + opt JCL → `cost_external_accrued` sul progetto → cost report
nuova riga "Costi esterni" sotto "Costi diretti", in negativo sul margine.

**Costo**: 2 tabelle + 1 router CRUD + UI. Isolabile dal flow esistente.
Idea per α.67 o α.68 dopo aver fatto 4 e 5.b.

---

## Sequenza proposta

1. **α.65** — Punto 4 (weighted hours) DOPO discussione 3 trade-off
2. **α.66** — Punto 5.b + 5.c base (InvoicePayment + cashflow revenue-only)
3. **α.67** — Punto 5.a (cost-side risorsa)
4. **α.68** — Punto 6 (supplier invoice)

Ordine motivato: 4 prima perché senza moltiplicatori l'accrued è sbagliato
e tutto il resto si appoggia su numeri scorretti. 5.b dopo perché sblocca
cashflow senza migrazioni invasive. 5.a dopo perché serve dato anagrafico
(tariffari) che Matteo deve riempire. 6 ultimo perché modulo nuovo
isolabile.
