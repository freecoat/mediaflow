================================================================
 MEDIAFLOW — MIGRAZIONE SU MAC (bundle completo)
================================================================

Questo .zip porta TUTTO il necessario per continuare MediaFlow su un'altra
macchina con Claude Code: codice (via git), segreti, database, file caricati,
storico/memoria di Claude, plugin e configurazione.

!!! CONTIENE SEGRETI (.env con API key, chiavi di cifratura, JWT) !!!
- Trasferisci OFFLINE (AirDrop / USB). NON via email, NON su cloud pubblico.
- NON committare nel repo (.env e' volutamente non tracciato).
- Cancella lo zip dopo aver finito la migrazione.

----------------------------------------------------------------
 CONTENUTO DEL BUNDLE
----------------------------------------------------------------
  install-plugins.sh        Script: ricrea marketplace + plugin Claude Code
  README.txt                Questo file
  secrets/.env              Variabili ambiente + CHIAVI (critico, vedi sotto)
  db/mediaflow.db           Database SQLite corrente (v3.5.0-alpha.172.238)
  db/data/                  File caricati: capitolato_uploads/ + previews/
  claude-history/memory/    Memoria persistente di Claude (140 file di contesto)
  claude-config/
     global-settings.json       Copia di ~/.claude/settings.json (permessi, tema, plugin)
     known_marketplaces.json    Riferimento marketplace installati
     installed_plugins.json     Riferimento plugin installati (con versioni)
     project-settings.local.json  Settings locali di progetto (.claude/settings.local.json)
     skills/graphify/           Skill custom GLOBALE (non e' un plugin)

NOTA: codice sorgente, .claude/settings.json di progetto, .claude/skills custom
(italian-tax-compliance, mediaflow-finance-feature-dev, sdi-xml-builder) e .mcp.json
sono GIA' nel repo git -> arrivano con `git clone`. Non sono nello zip.

----------------------------------------------------------------
 LA CHIAVE PIU' IMPORTANTE  (leggi prima di tutto)
----------------------------------------------------------------
In secrets/.env c'e' AI_KEY_ENCRYPTION_KEY. Cifra le API key salvate nel DB.
Se porti db/mediaflow.db DEVI usare lo STESSO .env, altrimenti le API key
nel DB diventano illeggibili e l'AI smette di funzionare.
=> Porta SEMPRE .env e db insieme. Non rigenerare le chiavi.

----------------------------------------------------------------
 PREREQUISITI SUL MAC
----------------------------------------------------------------
  - Git
  - Python 3.14 (consigliato; il progetto e' 3.11+ ma testato su 3.14)
  - Claude Code CLI installato e loggato:  https://claude.com/claude-code
  - uv / uvx  (per il server MCP fattura-elettronica):  brew install uv
  - (opzionale) graphify CLI, per il knowledge graph

----------------------------------------------------------------
 PROCEDURA PASSO-PASSO
----------------------------------------------------------------

1) CLONA IL CODICE
     git clone https://github.com/freecoat/mediaflow.git
     cd mediaflow

2) SEGRETI
     cp /percorso/bundle/secrets/.env  ./.env
   (la stessa .env che cifra il DB — vedi sopra)

3) DATABASE + FILE CARICATI
     cp /percorso/bundle/db/mediaflow.db  ./mediaflow.db
     mkdir -p data
     cp -R /percorso/bundle/db/data/*  ./data/
   In alternativa (DB pulito da zero, NON porti dati):
     ./strumenti.sh   -> opzione 2 (reset + seed_demo)

4) AMBIENTE PYTHON
     python3.14 -m venv .venv
     source .venv/bin/activate
     pip install -r requirements.txt

5) PLUGIN CLAUDE CODE
     bash /percorso/bundle/install-plugins.sh
   Poi verifica:
     claude plugin list

6) SKILL GLOBALE 'graphify' (non e' un plugin)
     mkdir -p ~/.claude/skills
     cp -R /percorso/bundle/claude-config/skills/graphify  ~/.claude/skills/

7) MEMORIA / STORICO DI CLAUDE  (opzionale ma consigliato)
   Su Mac il path del progetto sara' diverso, quindi cambia anche il nome
   della cartella memoria. Trova il nome corretto cosi':
     - apri Claude Code dentro la cartella del progetto una volta,
     - poi guarda in ~/.claude/projects/ la nuova cartella creata.
   Copia dentro la sua sottocartella memory/:
     cp -R /percorso/bundle/claude-history/memory  ~/.claude/projects/<NOME-PROGETTO-MAC>/

8) CONFIG GLOBALE CLAUDE (opzionale)
   global-settings.json contiene permessi/tema/plugin abilitati.
   NON sovrascrivere ciecamente ~/.claude/settings.json sul Mac (i path Windows
   non valgono). Apri global-settings.json e copia a mano solo i blocchi utili
   (es. "permissions", "theme"). I plugin li gestisce gia' install-plugins.sh.

9) KNOWLEDGE GRAPH (graphify-out/) — non incluso, si rigenera:
     graphify update .

10) AVVIA
     ./strumenti.sh          (menu) — oppure avvio diretto uvicorn da requirements
   Verifica:  http://localhost:8000/health  -> deve dire v3.5.0-alpha.172.238

----------------------------------------------------------------
 MCP SERVER
----------------------------------------------------------------
  - fattura-elettronica-it: definito in .mcp.json del repo, usa `uvx`.
    Serve `uv` installato (brew install uv). Prima esecuzione scarica il pacchetto.
  - serena / playwright / supabase: forniti dai rispettivi plugin (passo 5).

----------------------------------------------------------------
 CHECKLIST FINALE
----------------------------------------------------------------
  [ ] git clone ok, `git log` mostra v3.5.0-alpha.172.238
  [ ] .env copiata (stessa AI_KEY_ENCRYPTION_KEY del DB)
  [ ] mediaflow.db + data/ al loro posto
  [ ] venv + pip install ok
  [ ] claude plugin list mostra ~18 plugin
  [ ] skill graphify in ~/.claude/skills/
  [ ] /health risponde v3.5.0-alpha.172.238
  [ ] AI copilot risponde (conferma che la chiave di cifratura e' giusta)
  [ ] CANCELLA questo zip (contiene segreti)

================================================================
