---
name: feedback_ai_maxtokens_and_decouple
description: Output AI troncato = max_tokens basso; mai estrazione AI lenta sincrona dentro endpoint save
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 802ccdf3-eef2-42a2-921c-3e1181a9c46f
---

Due trappole confermate sul parse capitolati (α.172.233, commit 52b0582), riproducendo il Paramount 8-blocchi.

**1. Output AI troncato = max_tokens troppo basso.** `parse_delivery_template` usava `max_tokens=8000`: per template grossi l'output JSON (~22k char) superava il ceiling → JSON incompleto → `safe_json_parse` None → parse fallito (flaky: a volte stava sotto, "al secondo parsa"). Fix: 8000→32000. `safe_json_parse` toglie già la fence ```json (riga 1122-1123), quindi None su risposta ```json = troncamento, NON fence. Soglia: ClaudeProvider.complete fa streaming solo se max_tokens>16000 → usare ≥32000 per JSON grandi. Allineare i max_tokens tra parser fratelli (item-parser pass2 era già 32000).

**Why:** un None silenzioso da safe_json_parse maschera il troncamento. Verifica empirica: dump tail della risposta — se finisce a metà valore = troncato, alza max_tokens.

**2. Mai eseguire estrazione AI lenta SINCRONA dentro un endpoint di save.** `/api/save` faceva auto-extract item sincrono (~7 min: pass1 16k + pass2 32k) DOPO il commit → save multi-minuto → su tunnel cloudflared timeout di gateway → il client crede fallito → retry → 409 (code già esistente). Il template ERA salvato (id19 con 35 item provava il save ok). Fix: disaccoppiare. Il save committa solo (0.0s) e ritorna `needs_item_extraction`; il frontend chiama lo step esistente `/api/{id}/items/ai-extract` con progresso.

**How to apply:** endpoint mutator devono tornare veloci; lavoro AI multi-minuto = step separato esplicito col suo progresso, mai dentro la stessa request del save. Vedi [[feedback_anthropic_streaming_threshold]] [[project_session_23giu2026_parser_robusto]].

PENDENTE: estrazione item resta ~7 min (pass1+pass2 su 126k char) — ottimizzazione futura (chunk/parallelo/background). id18 leftover (0 item, 23 giu) cancellabile a mano.
