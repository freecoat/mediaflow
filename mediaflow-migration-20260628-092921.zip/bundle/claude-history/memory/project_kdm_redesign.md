---
name: project_kdm_redesign
description: "Decisioni redesign UX KDM/DKDM concordate 24 giu 2026 — flusso, emissione esterna, step incrementali"
metadata: 
  node_type: memory
  type: project
  originSessionId: 802ccdf3-eef2-42a2-921c-3e1181a9c46f
---

Redesign KDM/DKDM deciso con Matteo 24 giu 2026 (parte da [[project_session_19giu2026_kdm]] + [[project_session_23giu2026_kdm_i18n]]).

**Flusso target**: cliente/producer compila form pubblico (link) → producer+operatore vedono/ampliano/correggono (detail editabile) → operatore "Emette" + "Conferma consegna" → KDM = deliverable (già a `generated` via kdm_materialize).

**Decisioni firme**:
- **Emissione = puro registro/metadato.** KDM Studio (tool esterno) emette+consegna. Claqo NON carica il file .kdm. "Emetti" registra solo metadati (chi/quando/rif). `kdm_file_asset_id` resta inutilizzato.
- **Producer = entrambe le strade**: via link pubblico (come cliente) + account interno. Interno riusa permesso `manage_kdm` (no nuovo ruolo salvo richiesta).
- **Incrementale.**

**Step 1 FATTO** α.172.230 (commit 972f6d2): detail-view editabile (GET/POST /kdm/api/requests/{id} + timeline) + azioni leggibili Emetti(emit→generated+materializza)/Conferma(confirm-delivery→confirmed) via _advance_to su FSM + filtri MFFilterBar (testo/stato/tipo, client-side) + badge tipo + fix form pubblico (carica i18n.js+global.js → mfApplyTimePickers + i18n 5 lingue). FSM dropdown resta "Stato avanzato…".

**Step 2 FATTO** α.172.231 (commit 96cdc91): modello KdmRequestCertificate (N per richiesta, kind cert|serial, PEM thumbprint/scadenza via kdm_cert.parse_cert, o serial + label). Tabella via create_all al boot (no migration). Endpoint GET/POST/DELETE /kdm/api/requests/{id}/certs. Gate emit: 400 senza ≥1 credenziale (riga cert/serial o legacy client_cert_pem). Form pubblico: cert multipli (<input multiple>) + textarea serials (uno per riga). Detail operatore: sezione Certificati/Serial lista/aggiungi/rimuovi + warning. 69 test KDM, smoke browser live verde.

**Batch FATTO** α.172.232 (commit f6ccefe, PUSHATO): link con attributi (label+duration_days→expires_at, project_id da UI; auto-migrate colonne; form pubblico rifiuta scaduti 410) + filtri MFFilterBar in tab CPL + richieste collegate per CPL (GET /api/cpl/{id}/requests) + selezione multipla (bulk-delete richieste salta completate / bulk-revoke link) + completate (generated/delivered/confirmed) non cancellabili (400/skip) + tab Archivio (list ?archived=1, attiva le esclude). 76 test KDM. ROUTING: rotte literal (bulk-delete) PRIMA della parametrica POST /api/requests/{rid} o {rid} cattura 'bulk-delete'.

Step1+2+batch PUSHATI (origin f6ccefe). Step 3 possibile: producer-role dedicato se serve (ora riusa manage_kdm).

**Whenever**: mfApplyTimePickers (global.js:1746) wrappa datetime-local/time col look MF su load+openModal; opt-out data-no-time-picker. Form standalone no-auth devono includerlo o restano grezzi.
