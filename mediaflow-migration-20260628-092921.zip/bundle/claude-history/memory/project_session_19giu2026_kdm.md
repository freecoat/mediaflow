---
name: project_session_19giu2026_kdm
description: "19 giu 2026 — feature KDM/DKDM completa (v3.5.0-alpha.172.226), 21 task subagent-driven, merged su main NON pushato"
metadata: 
  node_type: memory
  type: project
  originSessionId: 38a14ea3-33a7-4e4d-a651-20215d0d2123
---

19 giu 2026. Feature **KDM/DKDM request tracking** per DCP. Mergeata su `main` (fc5939a), **NON pushata** (Matteo ha scelto merge locale). Branch feat/kdm-dkdm cancellato.

**Cosa fa:** lab post crea DCP cifrati; cliente (distributore/cinema) chiede chiavi (KDM=1 server cinema, DKDM=master distributore). Tracking-only, **zero crypto** — la KDM la genera l'operatore con tool esterno e la carica.

**Architettura (21 task, subagent-driven, TDD):**
- 6 modelli: `DcpCpl`, `CinemaFacility`, `CinemaServer`, `KdmRequest` (FSM), `KdmRequestEvent`, `KdmRequestLink`. Tabelle nuove, `_auto_migrate_kdm_tables()` lifespan + `scripts/migrate_kdm.py`.
- Servizi: `cpl_parser` (defusedxml anti-XXE/billion-laughs), `kdm_match` (UUID esatto=100, fuzzy difflib, soglia auto-link 95 configurabile), `kdm_state` (FSM received→matched→keys_pending→generated→delivered→confirmed +rejected/expired), `kdm_cert` (PEM thumbprint/scadenza best-effort), `kdm_adapters` (manual v1, pluggable per Qube/Gofilex fase 2), `kdm_pricing`, `kdm_notify`, `kdm_materialize`.
- Router admin `/kdm` (RBAC `manage_kdm`) + router pubblico no-auth `/public/kdm/{token}`.
- **Form pubblico via link**: `KdmRequestLink` token 64-hex, riusabile per-progetto + standalone, operatore pre-compila. Cliente carica cert/date/CPL/contatti → crea KdmRequest → auto-match → notifica finishing (in-app `notify_permission` + email best-effort SMTP).
- A `generated` → materializza `JobDeliverable` (KDM 20€/DKDM 300€ listino, emission=delivered_date) nella lista consegne prodotte.
- UI tabbed 3 tab + i18n 5 lingue + bottone "Genera link KDM" su scheda progetto. 2 AI capability (`propose_kdm_request`, `propose_cinema_server`).

**Trappole emerse (riusabili):**
- `PriceItem` NON ha colonna `code` → key = `name`, money field = `price_list`. Lookup voci via `KDM_NAME`/`DKDM_NAME` da `kdm_pricing`.
- `notify_permission(db, *, permission, **kwargs→notify)`: `permission` keyword-only, NO `message` (è `body`), `kind` obbligatorio.
- AI handler firma = `(db: Session, data: dict) -> dict` (NO context). I `@ai_capability` DEVONO stare PRIMA di `_ACTION_HANDLERS = _registry_get_handlers()` (snapshot one-shot) altrimenti morti nel path "Applica" (Critical trovato in review). Handler fanno `db.flush()`, `apply_action` (ai.py) committa.
- `api()` global = `api(method, url, body, options)` NON `api(url,{method})`. i18n via `window.MF_I18N` flat dict + `applyI18n()`.
- `current_user_optional(request)` solo request. `build_context` in `ai_context.py` (var `overview`).
- `ensure_kdm_price_items(db, commit=False)` dentro la transition FSM per atomicità (non committare mid-transition).

**Stato:** working tree pulito, 874 test, NON pushato. Tutta i18n in [[feedback_i18n_always]]. Browser smoke Matteo pendente.
