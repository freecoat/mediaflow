---
name: project_session_23giu2026_kdm_i18n
description: "Sessione 23 giu 2026 — smoke KDM + fix i18n 42 chiavi, α.172.227 PUSHATO"
metadata: 
  node_type: memory
  type: project
  originSessionId: 79e5f868-d4e9-42f6-8f5b-784f2c5bbd64
---

α.172.227 PUSHATO (b91b929..ad4a08f) — include anche i 33 commit KDM .226 finora non pushati.

Ripresa da [[project_session_19giu2026_kdm]]: smoke browser KDM + tunnel cloudflare.

**Bug trovato allo smoke**: 40+ chiavi i18n `kdm.*` renderizzate GREZZE (es. `kdm.action.transition`/`kdm.action.delete` su ogni riga tab Richieste, idem modali + tab Cinema/Server + CPL). Causa: chiavi usate in `kdm.html`/`kdm.js` ma mai aggiunte a `i18n.js` → `applyI18n` sovrascrive il testo hardcoded col fallback key-letterale di `mfT`. Conferma [[feedback_i18n_always]]: l'i18n KDM era stato fatto solo a metà.

**Fix**: 42 chiavi in 5 lingue. Pulsante elimina (icona ✕) ora `data-i18n` + `data-i18n-attr="title"` → traduce il title, NON sovrascrive l'icona (pattern da ricordare per bottoni-icona con tooltip).

Smoke verde (Playwright, admin@mediaflow.it/admin123): 3 tab + modale nuova richiesta + form pubblico `/public/kdm/{token}` (standalone, no base.html/i18n.js → nessun bug chiavi lì), 0 chiavi grezze, 0 errori console. 56 test KDM pass.

Note:
- `topbar_title` block hardcoded IT su TUTTE le pagine (pattern app-wide non tradotto) → fuori scope, non regressione KDM.
- Hook blocca git heredoc → commit via file `git commit -F`.
- Token KDM link da DB: tabella `kdm_request_links`.

Backlog KDM invariato: generazione vera file KDM (Dolby/OpenDCP), upload KDM come Asset, download sicuro cinema.
