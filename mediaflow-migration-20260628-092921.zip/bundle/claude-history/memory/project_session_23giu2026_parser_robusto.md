---
name: project_session_23giu2026_parser_robusto
description: "Sessione 23 giu 2026 (pom) — parser capitolati robusto α.172.228 PUSHATO, subagent-driven"
metadata: 
  node_type: memory
  type: project
  originSessionId: 79e5f868-d4e9-42f6-8f5b-784f2c5bbd64
---

α.172.228 PUSHATO (main 0cefe2e). Merge no-ff di feat/capitolato-parser-robusto. Eseguito **subagent-driven** (11 task TDD + review per task + review finale opus). 903 test.

**Trigger**: Matteo ha importato "Paramount Scripted Episode Delivery 2023", parse allucinato (audio 16ch con M&E duplicati, note "not fully extracted"). Due cause: **troncamento 30k char** in `parse_delivery_template` + **modello debole** (deepseek-v4-flash era il provider attivo del copilot).

**Fix** (vedi `docs/superpowers/specs|plans/2026-06-23-capitolato-parser-robusto*`):
- `pick_parse_provider(user_id, db)` in `ai_provider.py`: sceglie SEMPRE il modello più forte configurato (tier strong/medium/weak via `parse_model_tier`/`rank_parse_models`), **ignora active_ai_provider del copilot**. Verificato: deepseek attivo → parser usa Claude Sonnet. Lockdown estratto in `_apply_content_lockdown` (riusato da get_provider_for_user). NB: tier match usa `-mini` non `mini` (sennò matcha "gemini").
- `parse_delivery_template`: 30k → **single-pass 150k** + fallback chunk (`split_into_chunks` confini-sezione + `merge_template_blocks`), hard cap 600k. Ritorna `parse_meta{model_tier,chunked,n_chunks,truncated,ai_confidence,warnings,merge_notes}`. Signature nuova: `(text, provider, model_tier="strong")`.
- `build_parse_warnings` → codici `weak_model_large_doc/low_confidence/truncated` → banner UI i18n 5 lingue (`dt.parse_warning.*`, `dt.reparse`).
- `capitolato_storage.py` (NUOVO): salva file sorgente in `data/capitolato_uploads/` (gitignored), `sweep_capitolato_uploads` orphan >24h non-referenziati (include_deleted=True), `read_capitolato_text` con **guard path-traversal** (→ValueError, reparse cattura come 404).
- `/api/parse` (strong provider + save + sweep + parse_meta + source_document_path), `/api/save` (Form source_document_path + _dt_dict), nuovo `POST /api/{id}/reparse`, bottone "Ri-analizza" sui template con sorgente. PUT `/api/{id}` non tocca source_document_path (pattern `if X is not None`) → edit non lo azzera.

**PENDENTE Matteo**: ri-carica il Paramount → verifica parse con Claude Sonnet (no allucinazioni) + bottone Ri-analizza.

Minor accettati (final review): nested video_specs list keys (resolution/fps/hdr) non concat-merged nel path chunk (raro), _dedupe O(n²), no spinner durante await reparse. CWD-dependency su path relativi (convenzione esistente del progetto).

Note processo: subagent-driven funziona bene su questo progetto. task-brief/review-package script in skill dir. Implementer haiku per pure-function con codice nel brief, sonnet per integration/router/UI, opus per review finale. KDM .226/.227 già pushati separatamente (ad4a08f).

## SEGUITO: α.172.229 — item-list parser robusto + auto-extract (PUSHATO 2d12718)
Matteo ha segnalato che Paramount NON aveva la lista item come gli altri capitolati. Causa: la "lista item" sta nella tabella `delivery_items`, popolata da un parser DIVERSO (`delivery_items_parser.parse_delivery_items_v2`, 2-pass) via endpoint `/delivery-templates/api/{tid}/items/ai-extract`. Tre bug: (1) ai-extract leggeva SOLO da `docs/capitolati_esempio/` (corpus legacy) → capitolati caricati da UI 404 → 0 item; gli altri avevano item perché erano nel corpus; (2) modello attivo debole (deepseek); (3) parse_delivery_items_v2 troncava a 30k + PASS1 max_tokens 4000.
Fix (spec/plan `docs/superpowers/.../2026-06-23-item-parser-robusto*`): parse_delivery_items_v2 single-pass 150k + chunk PASS1 + `_merge_items_by_name` (dedupe by name), PASS1 max_tokens→16000, PASS2 unico con ref text cap 150k. `resolve_capitolato_source(template)` in capitolato_storage (persistito-o-corpus, guard traversal, CORPUS_DIR module const). ai-extract usa resolver + pick_parse_provider. **Auto-extract best-effort dopo /api/save** (template già committato, except non rilancia, risposta `items_extracted`/`items_warning`). 920 test.
PENDENTE Matteo: **ri-caricare Paramount da UI** (il vecchio id 18 ha source_document_path=None e file non nel corpus → resta a 0 item finché non lo ri-carichi). Dopo re-upload+save → auto-extract popola delivery_items.
