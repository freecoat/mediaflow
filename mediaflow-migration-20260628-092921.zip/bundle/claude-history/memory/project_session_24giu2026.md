---
name: project_session_24giu2026
description: Sessione 24 giu 2026 — KDM redesign (α.230-232) + fix import capitolato (α.233). Domanda di ripresa per domani
metadata: 
  node_type: memory
  type: project
  originSessionId: 802ccdf3-eef2-42a2-921c-3e1181a9c46f
---

Sessione 24 giu 2026. Tutto PUSHATO (origin 52b0582). Versioni α.172.230→233.

**KDM redesign** (vedi [[project_kdm_redesign]]): Step1 (.230 detail editabile+filtri+azioni Emetti/Conferma+form pubblico picker+i18n), Step2 (.231 certificati multipli + obbligo emissione), batch (.232 link con nome/progetto/durata→scadenza + archivio + selezione multipla + CPL filtri/collegate + completate non cancellabili).

**Fix import capitolato** (.233, commit 52b0582, vedi [[feedback_ai_maxtokens_and_decouple]]): max_tokens 8000→32000 (parse troncava) + estrazione item disaccoppiata dal save (era ~7 min sincrona → timeout→409). Provato end-to-end UI col Paramount: parse 126s, save 0.0s, 35 item.

**RIAPERTURA DOMANI — promptare a Matteo testualmente:**
"Come facciamo a definire e rendere chiaro quale AI verrà usata per il parsing?"

Contesto della domanda: oggi `pick_parse_provider` sceglie automaticamente il modello più FORTE tra quelli configurati (ignora il provider attivo del copilot). Es: admin ha claude-sonnet-4-6 + deepseek-v4-flash, attivo=deepseek, ma il parsing usa Claude (forte). Questo non è visibile/chiaro all'utente. Tema: rendere esplicito/scegliibile quale AI fa il parsing (UI? badge nel modal preview? setting dedicato?).

**Follow-up aperti**: estrazione item ~7 min (ottimizzare chunk/parallelo/background); id18 leftover (0 item, cancellabile a mano).
