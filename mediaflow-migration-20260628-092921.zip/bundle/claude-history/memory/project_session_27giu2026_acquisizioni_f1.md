---
name: project_session_27giu2026_acquisizioni_f1
description: "27 giu — α.172.236 Acquisizioni Fase 1 (CRM pipeline) MERGED su main (b536f9a), NON pushato. 14 task subagent-driven TDD"
metadata: 
  node_type: memory
  type: project
  originSessionId: 2fcca778-cb61-4a08-bcb4-e2306f9b0bd1
---

α.172.236 — nuovo modulo **Acquisizioni** (CRM/pipeline vendite AI-assisted), Fase 1 di 3. MERGED su main (b536f9a), branch feat/acquisizioni-fase1 eliminato. NON pushato (bump minore, policy locale). 992 test. Spec+plan in docs/superpowers/ (2026-06-27-acquisizioni-fase1).

**Decomposizione 3 fasi**: F1 pipeline+attività+contatti+mini-agenda+capability AI (FATTA); F2 incolla-email→AI estrae+web (Tavily); F3 agenda piena + Google Calendar/ICS.

**Modelli**: `Acquisition` (trattativa, può precedere Progetto via prospect_name, 6 stadi lead→qualified→quoting→negotiation→won→lost, potenziale pesato=valore×prob%, prob default-da-stadio override, tag reparti M:N, owner, next_action). `Contact` (multipli/cliente, is_primary→sync Client.contact_*). `Activity` (log email/call/meeting/note/task). Permessi `view/manage_acquisitions` (preset manager/producer/accounting).

**Decisioni** (brainstorm con Matteo): lead vaghi → entità separata Acquisition (non riuso Project); prospect nome libero+converti dopo; potenziale pesato; tag reparti €-a-livello-trattativa (no allocazione); layout ibrido kanban⇄tabella; owner=project owner/accounting.

**Servizio** acquisition_service.py: effective_probability/weighted_value/pipeline_summary/upcoming_actions/apply_stage_change(sync Project.status)/convert_to_project. **4 capability** propose_acquisition/activity/contact/acquisition_stage (gancio F2).

**Fix bug "non posso modificare stato progetto"**: duplice — (a) debito i18n opzioni stato (chiavi errate on_hold/cancelled, mancanti); (b) bottone Modifica gated su view_finance invece di edit_projects → nuovo Jinja global `can_edit_projects`. Verificato browser. Collega [[feedback_jinja_shadow_globals]].

**Trappole subagent-driven confermate**: reviewer haiku ha dato 1 FALSO POSITIVO (allucinato righe inesistenti) → usare sonnet per reviewer. effective_probability serializzato STRING ("70.0") rompe asserzioni `==70`. Fixture auth-middleware: monkeypatch database.engine+SessionLocal, non solo get_db (pattern test_kdm_router). Department fixture serve code= (NOT NULL).

**Merge-gate fix (review opus)**: middleware /clients/api bypass esponeva TUTTA l'API clienti (mutators no-gate) a view_clients → ristretto regex ^/clients/api/\d+/contacts$. Opzione UI tipo-attività 'proposal' non in enum→422, rimossa.

**FOLLOW-UP F2/Matteo**: KPI summary non reagisce ai filtri attivi (spec criterion 3); filtri owner/cliente mancanti in UI (backend ok); won contato 100% in total_weighted (domanda prodotto); Quote.total_with_vat float; client_id FK non tenant-validato (Fase 7).
