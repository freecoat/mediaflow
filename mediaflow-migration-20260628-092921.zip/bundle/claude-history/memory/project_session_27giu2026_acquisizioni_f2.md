---
name: project_session_27giu2026_acquisizioni_f2
description: "27 giu — α.172.237 Acquisizioni Fase 2 (email→AI + incrocio web) MERGED main (eddc5ed), NON pushato. 8 task subagent-driven TDD"
metadata: 
  node_type: memory
  type: project
  originSessionId: 2fcca778-cb61-4a08-bcb4-e2306f9b0bd1
---

α.172.237 — Acquisizioni **Fase 2** (estrazione email + incrocio web nel copilot). MERGED su main (eddc5ed), branch feat/acquisizioni-fase2 eliminato. NON pushato (bump minore, policy locale). 1004 test. Spec+plan in docs/superpowers/ (2026-06-27-acquisizioni-fase2).

**Decisioni** (brainstorm): entry = copilot ESISTENTE (no pagina nuova, sfrutta context-detection + flusso AIAction propose→apply); estrazioni email = log attività(email salvata)+contatto firma+update_client+avanza stadio; incrocio web = step ESPLICITO ("🔎 Cerca sul web"); modello = provider attivo copilot; **fonti web configurabili in Impostazioni** (aggiunta Matteo).

**Implementato**:
- `Tenant.web_sources` (JSON domini) + migrazione/seed (`migrate_web_sources.py`, seed filmitalia/cinema.cultura/imdb/mymovies). Auto-migrate boot SOLO aggiunge colonna (no seed) → tenant esistenti NULL→ricerca non ristretta finché non eseguono script o impostano UI.
- `web_search` capability ora passa `include_domains = tenant.web_sources` ([] /NULL→None, egress-gated invariato).
- Capability **`update_client`** (aggiorna cliente ESISTENTE, solo campi forniti; propose_client resta per creare) + **`propose_client_work`** (filmografia ai_imported).
- System prompt **EMAIL_EXTRACTION_GUIDANCE** appeso in build_system_prompt (entrambe modalità). db=None guard (test-only).
- Drawer copilot: bottoni 📥 incolla-email + 🔎 cerca-web → wired a `copilotSend()` reale (legge #cp-input; NON copilotSendOrStop che aborta se typing).
- Impostazioni: sezione Fonti web + `GET/POST /settings/api/web-sources` (POST gate manage_settings_global).

**Trappole confermate**: applyI18n supporta `data-i18n` + `data-i18n-attr="placeholder/title"` — NON `data-i18n-placeholder` (no-op). ai_loop.py:370 instrada non-readonly tool al propose-and-confirm (category facoltativa). Collega [[feedback_i18n_always]], [[feedback_copilot_more_capabilities]], [[project_session_27giu2026_acquisizioni_f1]].

**Step web = turno copilot** (non mega-capability annidata): bottone invia messaggio mirato → web_search + update_client/project_metadata/client_work come card singole.

**FOLLOW-UP Fase 3**: agenda piena + Google Calendar (OAuth)/ICS. Minori: settings GET 404 vs 401; _parse_sources no cap; notes non in descriptor; seed web_sources al boot.
