---
name: project_session_27giu2026_kdm_ui
description: "27 giu — α.172.238 KDM UI (tab Link, edit, filtri, multiselect cinema) MERGED main (45bf651), NON pushato. 6 task subagent-driven TDD"
metadata: 
  node_type: memory
  type: project
  originSessionId: 2fcca778-cb61-4a08-bcb4-e2306f9b0bd1
---

α.172.238 — 5 miglioramenti UI pagina `/kdm`. MERGED main (45bf651), branch feat/kdm-ui eliminato. NON pushato (bump minore). 1013 test. Spec+plan in docs/superpowers/ (2026-06-27-kdm-ui-improvements).

**5 modifiche** (richiesta Matteo): (1) tab "🔗 Link" dedicata (link separati da richieste; barra genera-link + lista spostate, toggle "Link attivi" rimosso); (2) link editabili `PUT /api/links/{id}` + modal ✎ (revocati bloccati); (3) filtri link (stato/progetto/cliente/ricerca; `GET /api/links` ora include revocati con flag `revoked` + `client_name`/`requested_title`); (4) select-all link (pilota bulk-revoke esistente); (5) multiselect Cinema/Server + `POST /api/facilities/bulk-delete` (soft-delete cinema+server cascata).

**Fatti modello**: "revoca link" = `is_active=False` (NIENTE campo `revoked`; revoked=not is_active). `Project` NON ha broadcaster/emittente → filtro link solo per **cliente** (project.client); emittente fuori scope. `CinemaFacility.servers` cascade ORM ma `delete_facility` singolo è soft-delete SENZA cascata server (solo il bulk cascata). Convenzione clear-field: frontend manda sentinel `'0'` per pulire campo Optional ([[feedback_empty_multipart_is_none]]).

**Trappole sessione**: TEST-POLLUTION — i fixture KDM facevano `database.engine = e; database.SessionLocal = S` assegnazione diretta SENZA ripristino → rompevano test_kdm_public nella suite completa (passavano da soli). Fix: usare pytest `monkeypatch.setattr` (auto-restore). Reviewer haiku inaffidabile → sonnet. Critical intercettato: rimuovere filtro is_active da list_links ruppe 2 test esistenti kdm_router (asserivano sparizione revocati). Final review (opus): edit_link non validava tenant del project_id (IDOR-write, create_link sì) + sentinel '0' non decodificato (svuotare nome salvava "0").

**FOLLOW-UP**: single delete_facility senza cascata server (asimmetria vs bulk); duration select edit non round-trip valori custom. Collega [[project_session_24giu2026_kdm]], [[project_kdm_redesign]].
