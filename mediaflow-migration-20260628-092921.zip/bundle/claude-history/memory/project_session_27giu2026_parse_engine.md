---
name: project_session_27giu2026_parse_engine
description: 27 giu — α.234 motore parsing esplicito + α.235 estrazione item background + delete item. NON pushati
metadata: 
  node_type: memory
  type: project
  originSessionId: 2fcca778-cb61-4a08-bcb4-e2306f9b0bd1
---

## α.172.235 (commit 7a27a6c, NON pushato) — estrazione item background + delete item
Richieste Matteo: (1) estrazione item AI in background (prima sincrona = confusione + timeout tunnel); (2) impossibile eliminare item da template (delete sepolto nell'editor).
- **Background**: `ai-extract` pre-check sincroni (404/503/409) poi `threading.Thread` con `SessionLocal()` propria + `set_tenant_id`, risponde 202 running. Stato su `delivery_templates.items_extraction_status/msg/at`. `GET .../items/extract-status` polling. `_run_item_extraction_bg` worker. UI badge live nel pane + badge ⏳ riga lista + poller DOMContentLoaded `dtPollRowExtractions`. Save-flow fire-and-forget. Auto-resume se template aperto è running.
- **Delete**: 🗑 per-riga su card + multiselect (checkbox + `_dtSelectedItems` Set + bulk bar) → `POST /delivery-items/api/bulk-delete` (CSV id, soft-delete). Allinea [[feedback_multiselect_multidrag]].
- 3 colonne + auto-migrate + `migrate_items_extraction_bg.py`. i18n 17 chiavi. 950 test. Smoke verde.
- Pattern thread+status+polling riusabile per altri task AI lunghi (SQLite ok: check_same_thread=False + WAL serializza writer).

PENDENTE α.235: Matteo testa estrazione reale background + delete singolo/multiplo.

---

## α.172.234 (commit 3170172) — motore parsing esplicito

α.172.234 (commit 3170172, NON pushato — bump minore, sessione locale). Chiude il nodo riaperto da [[project_session_24giu2026]]: "come definiamo/rendiamo chiaro quale AI parsa i capitolati".

Pacchetto completo (3 pezzi):
1. **Badge**: `/api/parse`+`/reparse` ritornano `parse_model_label`/`parse_tier`/`parse_provider` → "🤖 Analizzato con X · tier" nel preview.
2. **Override**: dropdown "Motore di parsing" nel modal import (default Automatico=strongest). Persistito su `users.parse_ai_provider` (NULL=auto).
3. **Settings → AI**: card con selector + "Modello usato dal parser" live.

Backend: `ai_provider.list_parse_models()` + `parse_model_human_label()`; `pick_parse_provider(..., override_provider=)` ordine arg>pref>auto, fallback se pref non configurata; `GET/POST /settings/api/parse-model`; `/api/ai` esteso. Migrazione `scripts/migrate_parse_provider.py` + auto-migrate boot. i18n 16 chiavi. 946 test (+9). Smoke browser verde (persistenza set deepseek→eff deepseek / reset auto→eff claude).

Collega: [[feedback_ai_maxtokens_and_decouple]] (parser usa modello forte via pick_parse_provider), [[project_session_23giu2026_parser_robusto]].

PENDENTE: Matteo ri-carica Paramount → verifica parse Claude Sonnet ora che motore è esplicito. Push quando Matteo lo decide.
