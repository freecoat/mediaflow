#!/usr/bin/env bash
# ============================================================
# MediaFlow — installazione plugin Claude Code su nuova macchina (Mac)
# Ricrea marketplace + plugin identici alla macchina Windows di origine.
# Richiede: Claude Code CLI gia' installato e loggato (`claude`).
# Uso:   bash install-plugins.sh
# ============================================================
set -uo pipefail

echo ">>> MediaFlow — setup plugin Claude Code"
echo ">>> Verifico CLI..."
command -v claude >/dev/null 2>&1 || { echo "ERRORE: 'claude' non trovato. Installa Claude Code prima."; exit 1; }

# --- 1. Marketplace ---
echo ">>> Aggiungo marketplace..."
add_mp () { echo "  + $1"; claude plugin marketplace add "$1" 2>&1 | sed 's/^/    /' || true; }

add_mp "anthropics/claude-plugins-official"
add_mp "FlineDev/Marketplace"
add_mp "juliusbrussee/caveman"
add_mp "obra/superpowers-marketplace"
add_mp "VoltAgent/awesome-claude-code-subagents"
add_mp "josstei/maestro-orchestrate"
add_mp "https://github.com/ccplugins/awesome-claude-code-plugins.git"

# --- 2. Plugin (name@marketplace) ---
echo ">>> Installo plugin..."
inst () { echo "  + $1"; claude plugin install "$1" 2>&1 | sed 's/^/    /' || true; }

# official
inst "claude-code-setup@claude-plugins-official"
inst "superpowers@claude-plugins-official"
inst "frontend-design@claude-plugins-official"
inst "code-review@claude-plugins-official"
inst "skill-creator@claude-plugins-official"
inst "feature-dev@claude-plugins-official"
inst "claude-md-management@claude-plugins-official"
inst "typescript-lsp@claude-plugins-official"
inst "security-guidance@claude-plugins-official"
inst "pyright-lsp@claude-plugins-official"
inst "code-simplifier@claude-plugins-official"
inst "serena@claude-plugins-official"
inst "supabase@claude-plugins-official"
inst "playwright@claude-plugins-official"
# altri marketplace
inst "recall@FlineDev"
inst "caveman@caveman"
inst "maestro@maestro-orchestrator"
inst "test-writer-fixer@awesome-claude-code-plugins"

echo ""
echo ">>> FATTO. Verifica con:  claude plugin list"
echo ">>> Nota: skill custom 'graphify' va copiata a mano (vedi README)."
echo ">>> Nota: MCP fattura-elettronica-it usa uvx -> installa 'uv' (brew install uv)."
